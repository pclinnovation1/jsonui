import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Sample data setup
np.random.seed(42)
data = [
    {'person_name': 'Mika Aalto', 'effective_start_date': '2014-09-19', 'effective_end_date': '', 'location': 'Helsinki'},
    {'person_name': 'Minna Aalto', 'effective_start_date': '2010-05-24', 'effective_end_date': '', 'location': 'Tampere'},
    {'person_name': 'John Smith', 'effective_start_date': '2022-03-15', 'effective_end_date': '', 'location': 'Oulu'},
    {'person_name': 'Jane Doe', 'effective_start_date': '2021-06-30', 'effective_end_date': '2023-04-15', 'location': 'Helsinki'},
    {'person_name': 'Emily Johnson', 'effective_start_date': '2015-09-01', 'effective_end_date': '', 'location': 'Tampere'},
    # Additional sample data...
]

# Convert JSON to DataFrame
df = pd.DataFrame(data)

# Parse dates
df['effective_start_date'] = pd.to_datetime(df['effective_start_date'], errors='coerce')
df['effective_end_date'] = pd.to_datetime(df['effective_end_date'], errors='coerce')

# Handling missing `effective_end_date` (assuming still employed)
df['effective_end_date'].fillna(pd.Timestamp.today(), inplace=True)

# Filter based on Year-to-Date (YTD) condition
current_year = pd.Timestamp.now().year
df_ytd = df[df['effective_start_date'].dt.year <= current_year]

# Group by location to get headcount
headcount_by_location_report = df_ytd.groupby('location').size().reset_index(name='employee_count')

# Saving the headcount by location report to a CSV file
output_file = 'employee_headcount_by_location_ytd.csv'
headcount_by_location_report.to_csv(output_file, index=False)

# Optional: Plotting the headcount by location as a bar graph
plt.figure(figsize=(10, 6))
plt.bar(headcount_by_location_report['location'], headcount_by_location_report['employee_count'], color='skyblue')
plt.title('Employee Headcount by Location (YTD)')
plt.xlabel('Location')
plt.ylabel('Employee Count')
plt.xticks(rotation=45)
plt.tight_layout()

# Show the plot
plt.show()