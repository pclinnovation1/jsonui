# import ast
# import os
# from pprint import pprint
# import re
# from langchain.chat_models import ChatOpenAI
# from langchain.prompts import PromptTemplate
# from typing import List
# from langchain.chains import LLMChain
# import openai
# import os
# import getpass
 
 
# # openaiclient = OpenAI()
# # Setup environment
# secret_api_key="sk-H2g59JtdvH7shdqBrjNHdG95IJ90q0-pZKkrQv4yJxT3BlbkFJ6P7x7o_eq8Ddo9dpxXnmRZBQev_mAxySNemmlNr1YA"
# OPENAI_LLM = ChatOpenAI(model="chatgpt-4o-latest", temperature=0.0, openai_api_key = secret_api_key)
 
       
# # Prompts Defination
# base_prompt = """
# You're an intelligent assistant who can read and analyze completely the prompt given by user and providing user with required field names.
# Salaries schema:
#     AssignmentId: A unique identifier assigned to a specific job or role assignment within an organization.
#     SalaryId: A unique identifier for a specific salary record.
#     SalaryBasisId: A unique identifier representing the basis on which the salary is calculated (e.g., annual, hourly).
#     SalaryFrequencyCode: A code indicating the frequency of salary payment (e.g., monthly, weekly).
#     SalaryBasisType: The type or structure of the salary basis (e.g., fixed, variable).
#     CurrencyCode: The currency in which the salary is paid (e.g., USD, EUR).
#     DateFrom: The start date from which the salary or assignment becomes effective.
#     DateTo: The end date for the salary or assignment period.
#     SalaryAmount: The actual amount of salary for the given period or assignment.
#     AdjustmentAmount: The amount by which the salary has been adjusted.
#     AdjustmentPercentage: The percentage by which the salary has been adjusted.
#     AnnualSalary: The total salary amount calculated on an annual basis.
#     AnnualFullTimeSalary: The annual salary equivalent for a full-time position, regardless of the actual hours worked.
#     Quartile: A numeric representation of which quartile the salary falls into within the pay range for similar roles.
#     Quintile: A numeric representation of which quintile the salary falls into within the pay range for similar roles.
#     CompaRatio: A comparison ratio that measures the employee’s salary in relation to the market midpoint for similar roles.
#     RangePosition: The position of the salary within a defined salary range.
#     SalaryRangeMinimum: The minimum salary allowed in the salary range for the specific role or grade.
#     SalaryRangeMidPoint: The midpoint salary in the defined salary range.
#     SalaryRangeMaximum: The maximum salary allowed in the salary range for the specific role or grade.
#     SearchDate: The date used to search or retrieve specific salary or assignment information.
#     FrequencyName: The name or description of the salary frequency (e.g., monthly, weekly).
#     AssignmentNumber: A unique number assigned to the employee's assignment within the organization.
#     DisplayName: The full display name of the employee or person associated with the assignment.
#     ActionId: A unique identifier for a specific action related to salary or job assignments.
#     ActionReasonId: A unique identifier for the reason associated with the action taken (e.g., promotion, salary adjustment).
#     ActionCode: A code representing the type of action performed on the salary or assignment (e.g., hire, promotion).
#     ActionReasonCode: A code representing the reason behind the action taken (e.g., merit increase, cost-of-living adjustment).
#     ActionReason: A description of the reason for the action taken on salary or assignment.
#     ActionName: The name or description of the action performed (e.g., salary review, assignment change).
#     Code: A general code that may refer to different types of system or business-related codes.
#     LegalEmployerName: The name of the legal employer associated with the assignment or salary.
#     GradeLadderName: The name of the grade ladder, which represents a progression of grades within the organization.
#     GradeName: The specific grade or level assigned to the employee based on job classification.
#     GradeStepName: The step within the grade ladder, indicating incremental progress or position within the grade.
#     GeographyName: The name of the geographic location associated with the assignment or salary (e.g., region, city).
#     GeographyTypeName: The type or classification of the geography (e.g., country, region).
#     GradeId: A unique identifier representing the grade assigned to the employee.
#     LastUpdateDate: The date when the record was last updated.
#     LastUpdatedBy: The user or system that last updated the record.
#     CreatedBy: The user or system that created the record.
#     CreationDate: The date when the record was first created.
#     FTEValue: Full-time equivalent value, which indicates the proportion of full-time hours worked by the employee.
#     NextSalReviewDate: The date for the next scheduled salary review.
#     AssignmentType: The type of assignment for the employee (e.g., full-time, part-time, temporary).
#     SalaryBasisName: The name or description of the salary basis (e.g., annual salary, hourly wage).
#     AmountDecimalPrecision: The number of decimal places used to represent the salary amount.
#     SalaryAmountScale: The scaling factor used in salary calculations.
#     AmountRoundingCode: A code that defines how salary amounts should be rounded.
#     AnnualRoundingCode: A code that defines how annual salary amounts should be rounded.
#     RangeRoundingCode: A code that defines how salary range values should be rounded.
#     WorkAtHome: Indicates whether the employee works remotely or from home.
#     QuartileMeaning: The meaning or interpretation of the quartile in the salary range (e.g., low, median, high).
#     QuintileMeaning: The meaning or interpretation of the quintile in the salary range.
#     LegislativeDataGroupId: A unique identifier for the legislative data group that governs the employee's pay.
#     hasFutureSalary: Indicates whether there is a future-dated salary record for the employee.
#     MultipleComponents: Indicates if the salary consists of multiple components (e.g., base salary, bonuses).
#     ComponentUsage: Describes how salary components are used or allocated.
#     PendingTransactionExists: Indicates whether there is a pending transaction related to salary or assignment.
#     RangeErrorWarning: An error or warning indicating that the salary is outside of the defined salary range.
#     PayrollFactor: A factor used in payroll calculations (e.g., for prorating salary).
#     SalaryFactor: A factor applied to adjust salary calculations.
#     PayrollFrequencyCode: A code representing the payroll frequency (e.g., weekly, biweekly, monthly).
#     PersonId: A unique identifier for the person or employee associated with the salary or assignment.
#     BusinessTitle: The business or job title of the person within the organization.
#     PersonNumber: A unique number assigned to the person or employee.
#     PersonDisplayName: The display name or full name of the person or employee.
#     GradeCode: A unique code representing the employee’s grade within the organization.
 
# employees schema:
#     Salutation: The title or form of address used (e.g., Mr., Mrs., Dr.).
#     FirstName: The first or given name of the person.
#     MiddleName: The middle name or additional given name of the person.
#     LastName: The family name or surname of the person.
#     PreviousLastName: The previous family name or surname, if applicable.
#     NameSuffix: A suffix added to the person's name (e.g., Jr., Sr., III).
#     DisplayName: The preferred format of the person's name to be displayed.
#     PreferredName: The name by which the person prefers to be called.
#     Honors: Any honorary titles or awards associated with the person.
#     CorrespondenceLanguage: The language in which the person prefers to receive correspondence.
#     PersonNumber: A unique identification number assigned to the person.
#     WorkPhoneCountryCode: The country code for the person's work phone number.
#     WorkPhoneAreaCode: The area code for the person's work phone number.
#     WorkPhoneNumber: The person's primary work phone number.
#     WorkPhoneExtension: The extension for the work phone number, if applicable.
#     WorkPhoneLegislationCode: Code indicating the legal regulations associated with the work phone.
#     WorkFaxCountryCode: The country code for the person's work fax number.
#     WorkFaxAreaCode: The area code for the person's work fax number.
#     WorkFaxNumber: The person's work fax number.
#     WorkFaxExtension: The extension for the work fax number, if applicable.
#     WorkFaxLegislationCode: Code indicating the legal regulations associated with the work fax.
#     WorkMobilePhoneCountryCode: The country code for the person's work mobile phone.
#     WorkMobilePhoneAreaCode: The area code for the person's work mobile phone.
#     WorkMobilePhoneNumber: The person's work mobile phone number.
#     WorkMobilePhoneExtension: The extension for the work mobile phone number, if applicable.
#     WorkMobilePhoneLegislationCode: Code indicating the legal regulations associated with the work mobile phone.
#     HomePhoneCountryCode: The country code for the person's home phone number.
#     HomePhoneAreaCode: The area code for the person's home phone number.
#     HomePhoneNumber: The person's primary home phone number.
#     HomePhoneExtension: The extension for the home phone number, if applicable.
#     HomePhoneLegislationCode: Code indicating the legal regulations associated with the home phone.
#     HomeFaxCountryCode: The country code for the person's home fax number.
#     HomeFaxAreaCode: The area code for the person's home fax number.
#     HomeFaxNumber: The person's home fax number.
#     HomeFaxExtension: The extension for the home fax number, if applicable.
#     WorkEmail: The email address associated with the person's work.
#     HomeFaxLegislationCode: Code indicating the legal regulations associated with the home fax.
#     AddressLine1: The first line of the person's home or mailing address.
#     AddressLine2: The second line of the person's home or mailing address, if applicable.
#     AddressLine3: The third line of the person's home or mailing address, if applicable.
#     City: The city where the person resides or works.
#     Region: The primary region, such as a state or province, where the person resides or works.
#     Region2: A secondary region, if applicable, for the person's address.
#     Country: The country of the person's residence or work.
#     PostalCode: The postal or ZIP code associated with the person's address.
#     DateOfBirth: The person's date of birth.
#     Ethnicity: The person's ethnicity or racial background, if applicable.
#     ProjectedTerminationDate: The anticipated date when the person's employment will end.
#     LegalEntityId: A unique identifier for the legal entity or employer the person is associated with.
#     HireDate: The date the person was hired or joined the organization.
#     TerminationDate: The date when the person's employment was terminated, if applicable.
#     Gender: The gender of the person (e.g., M for male, F for female).
#     MaritalStatus: The marital status of the person (e.g., S for single, M for married).
#     NationalIdType: The type of national identification (e.g., SSN, passport).
#     NationalId: The national identification number assigned to the person.
#     NationalIdCountry: The country that issued the national identification.
#     NationalIdExpirationDate: The expiration date of the national identification, if applicable.
#     NationalIdPlaceOfIssue: The location where the national identification was issued.
#     PersonId: A unique identifier for the person in the system.
#     EffectiveStartDate: The start date when the person's record becomes effective.
#     UserName: The person's username for the organization's system or portal.
#     CitizenshipId: A unique identifier for the person's citizenship record.
#     CitizenshipStatus: The person's citizenship status (e.g., A for active).
#     CitizenshipLegislationCode: Code associated with the legislation for citizenship.
#     CitizenshipToDate: The date until which the person's citizenship is valid, if applicable.
#     Religion: The person's religion or belief system, if applicable.
#     ReligionId: A unique identifier for the person's religion record.
#     PassportIssueDate: The date the person's passport was issued.
#     PassportNumber: The person's passport number.
#     PassportIssuingCountry: The country that issued the person's passport.
#     PassportId: A unique identifier for the person's passport record.
#     PassportExpirationDate: The expiration date of the person's passport.
#     LicenseNumber: The person's driver's license number, if applicable.
#     DriversLicenseExpirationDate: The expiration date of the person's driver's license.
#     DriversLicenseIssuingCountry: The country that issued the person's driver's license.
#     DriversLicenseId: A unique identifier for the person's driver's license record.
#     MilitaryVetStatus: Indicates whether the person is a military veteran (Y for yes, N for no).
#     CreationDate: The date when the person's record was created in the system.
#     LastUpdateDate: The most recent date when the person's record was updated.
#     WorkerType: The type of worker the person is (e.g., employee, contractor).
   
# workers schema:
#     PersonId: A unique identifier for the individual in the system, typically assigned by the organization.
#     PersonNumber: A unique identification number assigned to the person, often used for tracking within the organization.
#     CorrespondenceLanguage: The preferred language the person uses for official communications and correspondence.
#     BloodType: The blood group of the person (e.g., A, B, AB, O), often used for medical or emergency purposes.
#     DateOfBirth: The date when the person was born, formatted as YYYY-MM-DD.
#     DateOfDeath: The date when the person passed away, if applicable.
#     CountryOfBirth: The country where the person was born, represented by a country code or full name.
#     RegionOfBirth: The state, province, or region within the country where the person was born.
#     TownOfBirth: The specific town or city where the person was born.
#     ApplicantNumber: A unique identifier assigned to the person during the application process (if applicable).
#     CreatedBy: The user or system that initially created the person's record in the database.
#     CreationDate: The date and time when the person's record was created in the system.
#     LastUpdatedBy: The user or system that most recently updated the person's record.
#     LastUpdateDate: The date and time when the person's record was last updated.
 
 
# Key Instructions to Strictly Follow:
# - Always narrow down your research for fields and keep minimum fields as possible.
# - User may use some other words which is not present in our schemas but you need to understand them respond on the meaning of those words.  For example, 'compensation' refers to monetary payment given to an individual in exchange for their services.
# - User prompt must be similar to something showing, creating graphs or charts.
# - Always use same field names as mention in schemas.
# - Analyze the user's prompt and provide required field names strictly from schemas (salary schema, employees schema and workers schema).
# - If you find any related word that is present in user prompt and as well in our schemas then always add such fields.
 
# input:{user_prompt}
# response: Provide only a valid Python list of field names, nothing else.
# """
# # Create a LangChain prompt template
# prompt_template = PromptTemplate(input_variables=["user_prompt"], template=base_prompt)
 
# # Function to generate report fields using the AI agent
# def generate_graph_fields(user_prompt):
#     # Setup the LLMChain with the prompt template and the OpenAI model
#     llm_chain = LLMChain(llm=OPENAI_LLM, prompt=prompt_template)
   
#     # Run the chain and return the AI agent's response
#     response = llm_chain.run({"user_prompt": user_prompt})
   
#     # Clean the response and convert it to a valid Python list
#     try:
#         # Remove any extraneous text like ```python ... ```
#         code_match = re.search(r"```python(.*?)```", response, re.DOTALL)
#         if code_match:
#             response = code_match.group(1).strip()  # Extract the inner code block
 
#         # Use ast.literal_eval to safely evaluate the string as a Python list
#         fields = ast.literal_eval(response)
       
#         if isinstance(fields, list):
#             print("fields:", fields)
#             return fields
#         else:
#             raise ValueError("Response is not a valid list")
#     except (ValueError, SyntaxError) as e:
#         print(f"Error parsing AI response: {e}")
#         return []










import ast
import os
from pprint import pprint
import re
from langchain_community.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate  # Correct import for PromptTemplate
from langchain.chains import LLMChain  # Correct import for LLMChain
# Suppress Deprecation Warnings
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)


# Prompts Definition
base_prompt = """
You are an intelligent assistant responsible for analyzing user prompts and generating relevant field names for various HR reports. Your job is to understand the user's prompt and provide only the relevant field names from the schemas listed below.

Here are the available schemas and fields you can work with:

HRM_employee_details schema:
    person_number: Unique ID assigned to the employee.
    person_name: Full name of the employee.
    organization_unit: The unit or department the employee belongs to.
    position: Job position or title of the employee.
    manager_name: Name of the employee's direct manager.
    employment_status: Current employment status (e.g., Active, Terminated).
    effective_start_date: Date the employee started in the current role.
    effective_end_date: Date the employee’s role or employment ended.
    business_unit: Business unit the employee belongs to.
    department: Department the employee is part of.
    working_hours: Number of hours worked per week.
    full_time_or_part_time: Indicates if the employee is full-time or part-time.
    fte: Full-time equivalent value.
    retirement_date: The employee's anticipated or actual retirement date.
    location: Physical location of the employee.
    working_as_manager: Indicates if the employee works as a manager.
    working_from_home: Indicates if the employee works remotely.

HRM_personal_details schema:
    person_number: Unique ID assigned to the employee.
    person_name: Full name of the employee.
    date_of_birth: Birthdate of the employee.
    home_country: Country where the employee resides.
    citizenship_status: Citizenship status of the employee.
    nationality: Nationality of the employee.
    gender: Gender of the employee.

HRM_salary_details schema:
    person_number: Unique ID assigned to the employee.
    person_name: Full name of the employee.
    base_salary: The employee's base salary.
    compensation: Total compensation for the employee, including base salary and benefits.
    salary_effective_date: The date the current salary took effect.
    currency: The currency in which the salary is paid.
    fte: Full-time equivalent value.

JRN_journey schema:
    - `name`: The title or name of the journey (e.g., "Badge Request").
    - `category`: The category or type of the journey (e.g., "Badge_R").
    
    - `users`: A list of users associated with the journey. For each user, the following fields are included:
        - `person_name`: The name of the person participating in the journey.
        - `status`: The current status of the person in the journey (e.g., "In Progress", "Completed").

        - `tasks`: A list of tasks assigned to the user as part of the journey. For each task, the following fields are included:
            - `task_name`: The name or title of the task (e.g., "Request a Badge").
            - `status`: The current status of the task (e.g., "Not Started", "In Progress").
            - `task_start_date`: The date when the task started.
            - `task_due_date`: The date by which the task is due.


JRN_task schema:
    task_name: The name of the task.
    task_type: The type of task (e.g., Process Automation).
    performer: The role responsible for completing the task (e.g., Manager, Employee).
    owner: The owner of the task.
    description: A description of the task.
    task_link: A link to the task.
    duration: The task's duration.
    time_unit: The unit of time for the task (e.g., days, hours).

ABS_daily_leave_details schema:
    person_name: Name of the person taking leave.
    leave_type: The type of leave (e.g., Study Leave, Sick Leave).
    date: The date when the leave occurred.
    days: Number of leave days taken.

ABS_leave_application schema:
    person_name: Name of the person applying for leave.
    leave_type: The type of leave requested (e.g., Sick Leave, Vacation).
    start_date: Start date of the leave period.
    end_date: End date of the leave period.
    duration: Total duration of the leave.
    status: The current status of the leave application (e.g., approval required, approved).

ABS_leave_balance schema:
    person_name: Name of the person for whom leave balance is being tracked.
    leave_type: The type of leave (e.g., Sick Leave, Study Leave).
    leave_balance: The remaining balance of leave days.

TBI_workforce_data schema
    person_name: Name of the worker,
    email: E-mail of the worker,
    country_region: Country where the worker is located,
    processing_status: Whether the allocation has been processed or not,
    eligibility_status: Whether the worker is eligible for the compensation plan or not,
    date_of_birth: Date of birth in format YYYY-MM-DD,
    work_phone: Work phone number of worker,
    department: Department of the worker,
    location: City where the worker is located,
    job: Job profile of the worker,
    years_in_job: Time duration in years for which the worker has been working on the job profile,
    grade: Grade currently assigned to the worker,
    original_hire_date: Date on which the worker was hired in the company,
    primary_manager: Current primary manager of the worker,
    review_manager: Current manager who reviews the worker's tasks,
    secondary_manager: Current secondary manager of the worker,
    current_assignment_name: Currently assigned team of the worker,
    ars_employed: Years for which the worker has been working in the company,
    direct_manager: Current direct manager of the company,
    hierarchy_level: Hierarchy status of the worker,
    years_in_grade: Years for which the worker has been working in the grade,
    business_unit: Currently assigned business unit name of the worker,
    normal_hours: Normal working hours of the worker in a week,
    worker_number: A unique number/id assigned to the worker,
    position_change_date: Date on which the worker's position was changed,
    years_in_position: Years for which the worker has been working in the current position,
    position: The current job title of the worker.
    job_code: The code associated with the worker's current job.
    position_code: The unique code identifying the worker's position.
    working_hours: The number of hours the worker is expected to work per week.
    manager: The worker's direct manager or supervisor (if any).
    person_number: A unique identifier assigned to the worker.
    grade_code: The code representing the worker's grade within the organization.
    reassignment_date: The date on which the worker was reassigned to the current role.
    job_attribute_1: An additional attribute or characteristic related to the worker's job.
    assignment_status: The current status of the worker's assignment (e.g., Active, Inactive).
    assignment_category: The classification of the worker’s assignment (e.g., Full-Time, Part-Time).
    payroll: The frequency at which the worker receives their salary (e.g., Bi-Weekly).
    hire_date: The date the worker was originally hired by the company.
    reassigned_by: The person or department responsible for reassigning the worker.
    job_attribute_4: Another job-related attribute or characteristic.
    job_attribute_2: A second additional attribute or characteristic related to the worker's job.
    legal_employer: The legal entity that employs the worker.
    job_attribute_3: A third additional attribute or characteristic related to the worker's job.
    job_history: A list of previous jobs held by the worker within the organization.
    job_attribute_5: A fifth job-related attribute or characteristic.
    grade_change_date: The date on which the worker's grade was last changed.
    job_change_date: The date the worker's job role was last updated.
    job_attribute_6: A sixth job-related attribute or characteristic.
    base_salary_current: The worker's current base salary.
    base_salary_percentage_change: The percentage change in the worker's base salary.
    adjusted_salary_current: The current adjusted salary of the worker.
    adjusted_salary_new: The new adjusted salary proposed for the worker.
    adjusted_salary_change_amount: The difference in the worker's adjusted salary after the change.
    full_time_equivalent: A value representing the worker’s full-time equivalent status
    annualized_full_time_salary_current: The current annualized full-time salary of the worker.
    annualized_full_time_salary_new: The proposed new annualized full-time salary.
    annualized_full_time_salary_change_amount: The amount of change in the annualized full-time salary.
    salary_range_low_current: The current lowest value of the salary range for the worker's position.
    salary_range_high_current: The current highest value of the salary range for the worker's position.
    salary_range_quartile_current: The worker's current salary position within the salary range quartiles.
    salary_range_quartile_new: The proposed salary position within the salary range quartiles after change.
    base_salary_frequency: The frequency with which the base salary is paid (e.g., Bi-Weekly).
    salary_range_compa_ratio_current: The current comparison ratio of the worker’s salary to the midpoint of the range.
    salary_range_compa_ratio_new: The proposed new comparison ratio of the salary to the range midpoint.
    base_salary_new: The proposed new base salary for the worker.
    base_salary_currency: The currency in which the worker's base salary is paid.
    salary_range_position_current: The worker’s current position within the salary range.
    salary_range_position_new: The worker’s new position within the salary range.
    salary_range_midpoint_current: The current midpoint of the salary range for the worker's role.
    salary_range_decile_new: The proposed new decile of the worker’s salary range.
    annualized_full_time_salary_factor: A factor representing the worker’s status relative to full-time work.
    salary_range_decile_current: The worker’s current decile in the salary range.
    base_salary_change_amount: The amount of change in the base salary.
    salary_range_quintile_current: The current quintile in which the worker’s salary falls.
    prior_salary_change_date: The date on which the worker's salary was last changed.
    adjusted_salary_frequency: The frequency at which the adjusted salary is paid.
    prior_salary_change_amount: The amount of the previous salary change.
    adjusted_salary_factor: The factor applied to adjust the worker's salary.
    salary_range_quintile_new: The new quintile for the worker's salary after adjustment.
    prior_salary_change_percentage: The percentage of the previous salary change.
    proposed_assignment_name: The name of the proposed new assignment for the worker.
    promotion_effective_date: The date on which the worker’s promotion becomes effective.
    salary_range_high_new: The proposed new highest value in the salary range.
    salary_range_midpoint_new: The new midpoint of the salary range.
    salary_range_low_new: The proposed new lowest value in the salary range.
    promotion_fields_last_update_date: The last date when promotion-related fields were updated.
    promotion_fields_last_updated_by: The person or entity that last updated the promotion fields.
    promotion_fields_originally_updated_by: The original person or entity that updated the promotion fields.
    proposed_grade: The new grade proposed for the worker.
    proposed_grade_code: The code associated with the proposed new grade.
    proposed_job: The new job role proposed for the worker.
    proposed_job_code: The code associated with the proposed new job.
    proposed_position: The new position proposed for the worker.
    proposed_position_code: The code associated with the proposed position.
    grade_ladder: The career progression ladder for the worker's current grade.
    grade_step: The worker’s current step within their grade.
    proposed_grade_step: The proposed new step within the worker’s grade.
    compensation_performance_rating_current: The worker’s current compensation performance rating.
    performance_management_calculated_performance_goal_rating: The calculated rating for performance goals.
    performance_management_overall_performance_goal_rating: The overall rating for performance goals.
    calibration_status: The status indicating whether performance ratings have been calibrated.
    performance_management_overall_development_goal_rating: The overall rating for development goals.
    performance_management_calculated_development_goal_rating: The calculated rating for development goals.
    compensation_performance_rating_update_date: The date on which the compensation performance rating was last updated.
    compensation_performance_rating_updated_by: The person or entity that last updated the compensation performance rating.
    performance_management_calculated_competency_rating: The calculated rating for the worker's competencies.
    performance_management_calculated_overall_rating: The calculated overall performance rating.
    performance_management_overall_competency_rating: The overall rating for the worker's competencies.
    performance_management_overall_rating: The overall performance rating of the worker.
    performance_management_rating_date: The date on which the overall performance rating was recorded.
    original_compensation_performance_rating_updated_by: The original person who updated the compensation performance rating.
    performance_document: A document that contains the worker’s performance review.
    performance_history: A list of past performance reviews for the worker.
    compensation_performance_rating_prior: The worker's prior compensation performance rating.
    compensation_performance_rating_date_prior: The date of the prior compensation performance rating.
    ranking: The worker’s relative ranking within their team or company.
    risk_of_loss: The assessed risk of the worker leaving the company.
    full_ranking: The worker's overall ranking across the entire company.
    worker_potential: The assessed potential of the worker for growth or promotion.
    compensation_history: A list of the worker's previous compensation amounts.
    notes: Any additional notes regarding the worker.
    attachments: Files or documents attached to the worker’s record.
    absence_history: A list of the worker's previous absences.
    market_composites: Market data relevant to the worker's compensation or position.
    assignment_segments: Segments or components of the worker’s current assignment.
    ui_trigger_for_individual_worker: A flag indicating whether an individual UI action was triggered for the worker.

    
disciplinary_actions schema:
    - `person_name`: The name of the employee involved in the disciplinary action.
    - `action`: The type of disciplinary action taken (e.g., "Verbal Warning", "Written Warning").
    - `reason`: The reason for the disciplinary action (e.g., "Late submission of project reports").
    - `status`: The current status of the disciplinary action (e.g., "resolved", "pending").
    - `event_date`: The date of the incident or event that triggered the disciplinary action.
    - `action_date`: The date the disciplinary action was implemented.
    - `action_by`: The name of the person (e.g., manager, HR) who took the disciplinary action.
    - `severity`: The severity of the action (e.g., "minor", "major").
    - `manager_name`: The name of the manager responsible for handling the disciplinary action.
    
    - `followup_tasks`: A list of tasks assigned as follow-up actions related to the disciplinary event. For each task, the following fields are included:
        - `task_description`: A description of the follow-up task.
        - `due_date`: The date by which the follow-up task is due.
        - `status`: The current status of the task (e.g., "pending", "completed").
    
    - `appeal_status`: The status of the appeal, if any (e.g., "accepted", "rejected").
    - `acknowledged_at`: The date and time when the employee acknowledged the disciplinary action.
    - `created_at`: The timestamp when the disciplinary action was created (to track when the process was initiated).
    - `updated_at`: The timestamp when the disciplinary action was last updated (to track changes in status, comments, or follow-ups).


Instructions:
- Analyze the user's prompt and select the appropriate field names from the provided schemas.
- If the user request is ambiguous or general (e.g., "Turnover report"), infer the most relevant fields.
- Provide the field names as a Python dictionary with schema names as keys, and a list of relevant field names as values.
- Map synonyms and related terms used by the user to the correct field name. For example:
    - "compensation" refers to "base_salary" and "compensation" fields.
    - "department" refers to "organization_unit" and "business_unit."
    - "demographics" refers to fields like "date_of_birth", "gender", "nationality."
-Always include person_name for all schema.
- Always narrow down the selection to the minimum required fields based on the query.
- If the user asks for common HR reports (e.g., headcount, diversity, compensation analysis, turnover), include typical fields for those report types even if the user doesn't specify them.

input:{user_prompt}
response: Provide the fields as a Python dictionary with collection names and field lists.
"""

# Create a LangChain prompt template
prompt_template = PromptTemplate(input_variables=["user_prompt"], template=base_prompt)

# Function to get the raw response from the LLM
def get_raw_response(user_prompt):
    # Setup the LLMChain with the prompt template and the OpenAI model
    llm_chain = LLMChain(llm=OPENAI_LLM, prompt=prompt_template)
    
    # Run the chain and return the AI agent's raw response
    response = llm_chain.run({"user_prompt": user_prompt})
    return response

# Function to format the response into a dictionary with schema names
def format_response_as_dictionary(response):
    # Clean the response and convert it to a valid Python dictionary
    try:
        # Remove any extraneous text like ```python ... ```
        code_match = re.search(r"```python(.*?)```", response, re.DOTALL)
        if code_match:
            response = code_match.group(1).strip()  # Extract the inner code block

        # Use ast.literal_eval to safely evaluate the string as a Python dictionary
        fields_by_schema = ast.literal_eval(response)
        
        if isinstance(fields_by_schema, dict):
            print("Formatted response:", fields_by_schema)
            return fields_by_schema
        else:
            raise ValueError("Response is not a valid dictionary")
    except (ValueError, SyntaxError) as e:
        print(f"Error parsing AI response: {e}")
        return {}

# Main function to generate and format report fields
def generate_graph_fields(user_prompt):
    # Get the raw response from the LLM
    raw_response = get_raw_response(user_prompt)
    print("*"*25)
    print("raw_response : ",raw_response)
    # Format the response into a dictionary
    formatted_response = format_response_as_dictionary(raw_response)
    return formatted_response

# # Example Usage
# user_prompt = "Generate a headcount report showing employee names, departments, and employment status."
# fields_by_schema = generate_graph_fields(user_prompt)
# pprint(fields_by_schema)