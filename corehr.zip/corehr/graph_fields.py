import ast
import os
from pprint import pprint
import re
from langchain.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from typing import List
from langchain.chains import LLMChain
import openai
import os
import getpass
 
 
# openaiclient = OpenAI()
# Setup environment
secret_api_key="sk-H2g59JtdvH7shdqBrjNHdG95IJ90q0-pZKkrQv4yJxT3BlbkFJ6P7x7o_eq8Ddo9dpxXnmRZBQev_mAxySNemmlNr1YA"
OPENAI_LLM = ChatOpenAI(model="chatgpt-4o-latest", temperature=0.0, openai_api_key = secret_api_key)
 
       
# Prompts Defination
base_prompt = """
You're an intelligent assistant who can read and analyze completely the prompt given by user and providing user with required field names.
Salaries schema:
    AssignmentId: A unique identifier assigned to a specific job or role assignment within an organization.
    SalaryId: A unique identifier for a specific salary record.
    SalaryBasisId: A unique identifier representing the basis on which the salary is calculated (e.g., annual, hourly).
    SalaryFrequencyCode: A code indicating the frequency of salary payment (e.g., monthly, weekly).
    SalaryBasisType: The type or structure of the salary basis (e.g., fixed, variable).
    CurrencyCode: The currency in which the salary is paid (e.g., USD, EUR).
    DateFrom: The start date from which the salary or assignment becomes effective.
    DateTo: The end date for the salary or assignment period.
    SalaryAmount: The actual amount of salary for the given period or assignment.
    AdjustmentAmount: The amount by which the salary has been adjusted.
    AdjustmentPercentage: The percentage by which the salary has been adjusted.
    AnnualSalary: The total salary amount calculated on an annual basis.
    AnnualFullTimeSalary: The annual salary equivalent for a full-time position, regardless of the actual hours worked.
    Quartile: A numeric representation of which quartile the salary falls into within the pay range for similar roles.
    Quintile: A numeric representation of which quintile the salary falls into within the pay range for similar roles.
    CompaRatio: A comparison ratio that measures the employee’s salary in relation to the market midpoint for similar roles.
    RangePosition: The position of the salary within a defined salary range.
    SalaryRangeMinimum: The minimum salary allowed in the salary range for the specific role or grade.
    SalaryRangeMidPoint: The midpoint salary in the defined salary range.
    SalaryRangeMaximum: The maximum salary allowed in the salary range for the specific role or grade.
    SearchDate: The date used to search or retrieve specific salary or assignment information.
    FrequencyName: The name or description of the salary frequency (e.g., monthly, weekly).
    AssignmentNumber: A unique number assigned to the employee's assignment within the organization.
    DisplayName: The full display name of the employee or person associated with the assignment.
    ActionId: A unique identifier for a specific action related to salary or job assignments.
    ActionReasonId: A unique identifier for the reason associated with the action taken (e.g., promotion, salary adjustment).
    ActionCode: A code representing the type of action performed on the salary or assignment (e.g., hire, promotion).
    ActionReasonCode: A code representing the reason behind the action taken (e.g., merit increase, cost-of-living adjustment).
    ActionReason: A description of the reason for the action taken on salary or assignment.
    ActionName: The name or description of the action performed (e.g., salary review, assignment change).
    Code: A general code that may refer to different types of system or business-related codes.
    LegalEmployerName: The name of the legal employer associated with the assignment or salary.
    GradeLadderName: The name of the grade ladder, which represents a progression of grades within the organization.
    GradeName: The specific grade or level assigned to the employee based on job classification.
    GradeStepName: The step within the grade ladder, indicating incremental progress or position within the grade.
    GeographyName: The name of the geographic location associated with the assignment or salary (e.g., region, city).
    GeographyTypeName: The type or classification of the geography (e.g., country, region).
    GradeId: A unique identifier representing the grade assigned to the employee.
    LastUpdateDate: The date when the record was last updated.
    LastUpdatedBy: The user or system that last updated the record.
    CreatedBy: The user or system that created the record.
    CreationDate: The date when the record was first created.
    FTEValue: Full-time equivalent value, which indicates the proportion of full-time hours worked by the employee.
    NextSalReviewDate: The date for the next scheduled salary review.
    AssignmentType: The type of assignment for the employee (e.g., full-time, part-time, temporary).
    SalaryBasisName: The name or description of the salary basis (e.g., annual salary, hourly wage).
    AmountDecimalPrecision: The number of decimal places used to represent the salary amount.
    SalaryAmountScale: The scaling factor used in salary calculations.
    AmountRoundingCode: A code that defines how salary amounts should be rounded.
    AnnualRoundingCode: A code that defines how annual salary amounts should be rounded.
    RangeRoundingCode: A code that defines how salary range values should be rounded.
    WorkAtHome: Indicates whether the employee works remotely or from home.
    QuartileMeaning: The meaning or interpretation of the quartile in the salary range (e.g., low, median, high).
    QuintileMeaning: The meaning or interpretation of the quintile in the salary range.
    LegislativeDataGroupId: A unique identifier for the legislative data group that governs the employee's pay.
    hasFutureSalary: Indicates whether there is a future-dated salary record for the employee.
    MultipleComponents: Indicates if the salary consists of multiple components (e.g., base salary, bonuses).
    ComponentUsage: Describes how salary components are used or allocated.
    PendingTransactionExists: Indicates whether there is a pending transaction related to salary or assignment.
    RangeErrorWarning: An error or warning indicating that the salary is outside of the defined salary range.
    PayrollFactor: A factor used in payroll calculations (e.g., for prorating salary).
    SalaryFactor: A factor applied to adjust salary calculations.
    PayrollFrequencyCode: A code representing the payroll frequency (e.g., weekly, biweekly, monthly).
    PersonId: A unique identifier for the person or employee associated with the salary or assignment.
    BusinessTitle: The business or job title of the person within the organization.
    PersonNumber: A unique number assigned to the person or employee.
    PersonDisplayName: The display name or full name of the person or employee.
    GradeCode: A unique code representing the employee’s grade within the organization.
 
employees schema:
    Salutation: The title or form of address used (e.g., Mr., Mrs., Dr.).
    FirstName: The first or given name of the person.
    MiddleName: The middle name or additional given name of the person.
    LastName: The family name or surname of the person.
    PreviousLastName: The previous family name or surname, if applicable.
    NameSuffix: A suffix added to the person's name (e.g., Jr., Sr., III).
    DisplayName: The preferred format of the person's name to be displayed.
    PreferredName: The name by which the person prefers to be called.
    Honors: Any honorary titles or awards associated with the person.
    CorrespondenceLanguage: The language in which the person prefers to receive correspondence.
    PersonNumber: A unique identification number assigned to the person.
    WorkPhoneCountryCode: The country code for the person's work phone number.
    WorkPhoneAreaCode: The area code for the person's work phone number.
    WorkPhoneNumber: The person's primary work phone number.
    WorkPhoneExtension: The extension for the work phone number, if applicable.
    WorkPhoneLegislationCode: Code indicating the legal regulations associated with the work phone.
    WorkFaxCountryCode: The country code for the person's work fax number.
    WorkFaxAreaCode: The area code for the person's work fax number.
    WorkFaxNumber: The person's work fax number.
    WorkFaxExtension: The extension for the work fax number, if applicable.
    WorkFaxLegislationCode: Code indicating the legal regulations associated with the work fax.
    WorkMobilePhoneCountryCode: The country code for the person's work mobile phone.
    WorkMobilePhoneAreaCode: The area code for the person's work mobile phone.
    WorkMobilePhoneNumber: The person's work mobile phone number.
    WorkMobilePhoneExtension: The extension for the work mobile phone number, if applicable.
    WorkMobilePhoneLegislationCode: Code indicating the legal regulations associated with the work mobile phone.
    HomePhoneCountryCode: The country code for the person's home phone number.
    HomePhoneAreaCode: The area code for the person's home phone number.
    HomePhoneNumber: The person's primary home phone number.
    HomePhoneExtension: The extension for the home phone number, if applicable.
    HomePhoneLegislationCode: Code indicating the legal regulations associated with the home phone.
    HomeFaxCountryCode: The country code for the person's home fax number.
    HomeFaxAreaCode: The area code for the person's home fax number.
    HomeFaxNumber: The person's home fax number.
    HomeFaxExtension: The extension for the home fax number, if applicable.
    WorkEmail: The email address associated with the person's work.
    HomeFaxLegislationCode: Code indicating the legal regulations associated with the home fax.
    AddressLine1: The first line of the person's home or mailing address.
    AddressLine2: The second line of the person's home or mailing address, if applicable.
    AddressLine3: The third line of the person's home or mailing address, if applicable.
    City: The city where the person resides or works.
    Region: The primary region, such as a state or province, where the person resides or works.
    Region2: A secondary region, if applicable, for the person's address.
    Country: The country of the person's residence or work.
    PostalCode: The postal or ZIP code associated with the person's address.
    DateOfBirth: The person's date of birth.
    Ethnicity: The person's ethnicity or racial background, if applicable.
    ProjectedTerminationDate: The anticipated date when the person's employment will end.
    LegalEntityId: A unique identifier for the legal entity or employer the person is associated with.
    HireDate: The date the person was hired or joined the organization.
    TerminationDate: The date when the person's employment was terminated, if applicable.
    Gender: The gender of the person (e.g., M for male, F for female).
    MaritalStatus: The marital status of the person (e.g., S for single, M for married).
    NationalIdType: The type of national identification (e.g., SSN, passport).
    NationalId: The national identification number assigned to the person.
    NationalIdCountry: The country that issued the national identification.
    NationalIdExpirationDate: The expiration date of the national identification, if applicable.
    NationalIdPlaceOfIssue: The location where the national identification was issued.
    PersonId: A unique identifier for the person in the system.
    EffectiveStartDate: The start date when the person's record becomes effective.
    UserName: The person's username for the organization's system or portal.
    CitizenshipId: A unique identifier for the person's citizenship record.
    CitizenshipStatus: The person's citizenship status (e.g., A for active).
    CitizenshipLegislationCode: Code associated with the legislation for citizenship.
    CitizenshipToDate: The date until which the person's citizenship is valid, if applicable.
    Religion: The person's religion or belief system, if applicable.
    ReligionId: A unique identifier for the person's religion record.
    PassportIssueDate: The date the person's passport was issued.
    PassportNumber: The person's passport number.
    PassportIssuingCountry: The country that issued the person's passport.
    PassportId: A unique identifier for the person's passport record.
    PassportExpirationDate: The expiration date of the person's passport.
    LicenseNumber: The person's driver's license number, if applicable.
    DriversLicenseExpirationDate: The expiration date of the person's driver's license.
    DriversLicenseIssuingCountry: The country that issued the person's driver's license.
    DriversLicenseId: A unique identifier for the person's driver's license record.
    MilitaryVetStatus: Indicates whether the person is a military veteran (Y for yes, N for no).
    CreationDate: The date when the person's record was created in the system.
    LastUpdateDate: The most recent date when the person's record was updated.
    WorkerType: The type of worker the person is (e.g., employee, contractor).
   
workers schema:
    PersonId: A unique identifier for the individual in the system, typically assigned by the organization.
    PersonNumber: A unique identification number assigned to the person, often used for tracking within the organization.
    CorrespondenceLanguage: The preferred language the person uses for official communications and correspondence.
    BloodType: The blood group of the person (e.g., A, B, AB, O), often used for medical or emergency purposes.
    DateOfBirth: The date when the person was born, formatted as YYYY-MM-DD.
    DateOfDeath: The date when the person passed away, if applicable.
    CountryOfBirth: The country where the person was born, represented by a country code or full name.
    RegionOfBirth: The state, province, or region within the country where the person was born.
    TownOfBirth: The specific town or city where the person was born.
    ApplicantNumber: A unique identifier assigned to the person during the application process (if applicable).
    CreatedBy: The user or system that initially created the person's record in the database.
    CreationDate: The date and time when the person's record was created in the system.
    LastUpdatedBy: The user or system that most recently updated the person's record.
    LastUpdateDate: The date and time when the person's record was last updated.
 
 
Key Instructions to Strictly Follow:
- Always narrow down your research for fields and keep minimum fields as possible.
- User may use some other words which is not present in our schemas but you need to understand them respond on the meaning of those words.  For example, 'compensation' refers to monetary payment given to an individual in exchange for their services.
- User prompt must be similar to something showing, creating graphs or charts.
- Always use same field names as mention in schemas.
- Analyze the user's prompt and provide required field names strictly from schemas (salary schema, employees schema and workers schema).
- If you find any related word that is present in user prompt and as well in our schemas then always add such fields.
 
input:{user_prompt}
response: Provide only a valid Python list of field names, nothing else.
"""
# Create a LangChain prompt template
prompt_template = PromptTemplate(input_variables=["user_prompt"], template=base_prompt)
 
# Function to generate report fields using the AI agent
def generate_graph_fields(user_prompt):
    # Setup the LLMChain with the prompt template and the OpenAI model
    llm_chain = LLMChain(llm=OPENAI_LLM, prompt=prompt_template)
   
    # Run the chain and return the AI agent's response
    response = llm_chain.run({"user_prompt": user_prompt})
   
    # Clean the response and convert it to a valid Python list
    try:
        # Remove any extraneous text like ```python ... ```
        code_match = re.search(r"```python(.*?)```", response, re.DOTALL)
        if code_match:
            response = code_match.group(1).strip()  # Extract the inner code block
 
        # Use ast.literal_eval to safely evaluate the string as a Python list
        fields = ast.literal_eval(response)
       
        if isinstance(fields, list):
            print("fields:", fields)
            return fields
        else:
            raise ValueError("Response is not a valid list")
    except (ValueError, SyntaxError) as e:
        print(f"Error parsing AI response: {e}")
        return []