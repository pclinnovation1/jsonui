
import json

# Provided data examples
data = [
     {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates reports and visualizations based on user requests."},
            {"role": "user", "content": "Generate a Salary Distribution report, broken down by department and gender, without applying any filters or specific date range."},
            {"role": "assistant", "content": "import pandas as pd\nimport numpy as np\nimport seaborn as sns\nimport matplotlib.pyplot as plt\n\n# Sample data creation for salary distribution\nnp.random.seed(42)\ndepartments = ['Manufacturing', 'Sales', 'Engineering', 'HR', 'Marketing', 'Product Management']\ngenders = ['Male', 'Female']\nemployee_data_salary = pd.DataFrame({\n    'Employee Name': [f'Employee {i}' for i in range(1, 301)],\n    'Department': np.random.choice(departments, 300),\n    'Gender': np.random.choice(genders, 300),\n    'Salary': np.random.normal(60000, 15000, 300)  # Generating salaries with a mean of 60000 and std deviation of 15000\n})\n\n# Generating the Salary Distribution Report, broken down by department and gender\nsalary_distribution_report = employee_data_salary.groupby(['Department', 'Gender'])['Salary'].describe().reset_index()\n\n# Plotting the salary distribution using a boxplot for visualization\nplt.figure(figsize=(14, 8))\nsns.boxplot(data=employee_data_salary, x='Department', y='Salary', hue='Gender', palette='Set3')\nplt.title('Salary Distribution by Department and Gender')\nplt.xlabel('Department')\nplt.ylabel('Salary')\nplt.xticks(rotation=45)\nplt.tight_layout()\n\n# Show the plot\nplt.show()"}
        ]
    },
    {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates reports and visualizations based on user requests."},
            {"role": "user", "content": "Generate a report on Employee Headcount by department, covering YTD, without applying any filters."},
            {"role": "assistant", "content": "import pandas as pd\nimport seaborn as sns\nimport matplotlib.pyplot as plt\nfrom datetime import datetime\n\n# Sample data setup\nnp.random.seed(42)\ndata = [\n    {'person_name': 'Mika Aalto', 'effective_start_date': '2024-09-19', 'effective_end_date': '', 'department': 'Manufacturing technology'},\n    {'person_name': 'Minna Aalto', 'effective_start_date': '2010-05-24', 'effective_end_date': '', 'department': 'Manufacturing - assembly'},\n    # Additional sample data...\n]\n\n# Convert JSON to DataFrame\ndf = pd.DataFrame(data)\n\n# Parse dates\ndf['effective_start_date'] = pd.to_datetime(df['effective_start_date'], errors='coerce')\ndf['effective_end_date'] = pd.to_datetime(df['effective_end_date'], errors='coerce')\n\n# Handling missing `effective_end_date` (assuming still employed)\ndf['effective_end_date'].fillna(pd.Timestamp.today(), inplace=True)\n\n# Filter based on Year-to-Date (YTD) condition\ncurrent_year = pd.Timestamp.now().year\ndf_ytd = df[(df['effective_start_date'].dt.year <= current_year) & (df['effective_end_date'].dt.year >= current_year)]\n\n# Aggregating headcount by department\nheadcount_by_department_report = df_ytd.groupby('department').size().reset_index(name='employee_count')\n\n# Plotting the headcount by department\nplt.figure(figsize=(10, 6))\nsns.barplot(data=headcount_by_department_report, x='department', y='employee_count', palette='Blues_d')\nplt.title('Employee Headcount by Department (YTD)')\nplt.xlabel('Department')\nplt.ylabel('Employee Count')\nplt.xticks(rotation=45)\nplt.tight_layout()\n\n# Show the plot\nplt.show()"}
        ]
    },
    {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates reports and visualizations based on user requests."},
            {"role": "user", "content": "Generate a report on Employee Satisfaction Score, broken down by department and location, filtered for full-time employees, covering the last 12 months."},
            {"role": "assistant", "content": "import pandas as pd\nimport matplotlib.pyplot as plt\nimport seaborn as sns\nfrom datetime import datetime, timedelta\n\n# Sample data setup\nnp.random.seed(42)\n# Assuming employee satisfaction data is loaded into 'satisfaction_data'\ndf = pd.DataFrame(satisfaction_data)\n\n# Filter full-time employees within the last 12 months\nlast_year = datetime.now() - timedelta(days=365)\ndf_filtered = df[(df['employment_status'] == 'Active') & (df['full_time_or_part_time'] == 'Full-Time') & (df['review_date'] >= last_year)]\n\n# Group by department and location to calculate satisfaction scores\nsatisfaction_report = df_filtered.groupby(['department', 'location'])['satisfaction_score'].mean().reset_index()\n\n# Plotting the satisfaction scores\nplt.figure(figsize=(14, 8))\nsns.barplot(data=satisfaction_report, x='department', y='satisfaction_score', hue='location')\nplt.title('Employee Satisfaction Score by Department and Location (Last 12 Months)')\nplt.xticks(rotation=45)\nplt.xlabel('Department')\nplt.ylabel('Average Satisfaction Score')\nplt.tight_layout()\n\n# Show plot\nplt.show()"}
        ]
    },
    {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates reports and visualizations based on user requests."},
            {"role": "user", "content": "Generate a Workers Compensated report, broken down by business unit and department, filtered by active employees only, covering the year-to-date (YTD)."},
            {"role": "assistant", "content": "import pandas as pd\nimport matplotlib.pyplot as plt\nimport seaborn as sns\nfrom datetime import datetime\n\n# Sample data setup\nnp.random.seed(42)\n# Assuming data is loaded into 'compensation_data' with relevant fields\ndf = pd.DataFrame(compensation_data)\n\n# Filter active employees\ncurrent_year = datetime.now().year\ndf_ytd = df[(df['employment_status'] == 'Active') & (df['compensation_date'].dt.year == current_year)]\n\n# Group by business unit and department\ncompensated_report = df_ytd.groupby(['business_unit', 'department'])['compensation_amount'].sum().reset_index()\n\n# Plotting the compensated report\nplt.figure(figsize=(14, 8))\nsns.barplot(data=compensated_report, x='business_unit', y='compensation_amount', hue='department')\nplt.title('Workers Compensated by Business Unit and Department (YTD)')\nplt.xticks(rotation=45)\nplt.xlabel('Business Unit')\nplt.ylabel('Total Compensation')\nplt.tight_layout()\n\n# Show plot\nplt.show()"}
        ]
    },
     {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates reports and visualizations based on user requests."},
            {"role": "user", "content": "Generate a Salary Distribution report, broken down by department and gender, without applying any filters or specific date range."},
            {"role": "assistant", "content": "import pandas as pd\nimport numpy as np\nimport seaborn as sns\nimport matplotlib.pyplot as plt\n\n# Sample data creation for salary distribution\nnp.random.seed(42)\ndepartments = ['Manufacturing', 'Sales', 'Engineering', 'HR', 'Marketing', 'Product Management']\ngenders = ['Male', 'Female']\nemployee_data_salary = pd.DataFrame({\n    'Employee Name': [f'Employee {i}' for i in range(1, 301)],\n    'Department': np.random.choice(departments, 300),\n    'Gender': np.random.choice(genders, 300),\n    'Salary': np.random.normal(60000, 15000, 300)  # Generating salaries with a mean of 60000 and std deviation of 15000\n})\n\n# Generating the Salary Distribution Report, broken down by department and gender\nsalary_distribution_report = employee_data_salary.groupby(['Department', 'Gender'])['Salary'].describe().reset_index()\n\n# Plotting the salary distribution using a boxplot for visualization\nplt.figure(figsize=(14, 8))\nsns.boxplot(data=employee_data_salary, x='Department', y='Salary', hue='Gender', palette='Set3')\nplt.title('Salary Distribution by Department and Gender')\nplt.xlabel('Department')\nplt.ylabel('Salary')\nplt.xticks(rotation=45)\nplt.tight_layout()\n\n# Show the plot\nplt.show()"}
        ]
    },
    {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates reports and visualizations based on user requests."},
            {"role": "user", "content": "Generate a report on Employee Headcount by department, covering YTD, without applying any filters."},
            {"role": "assistant", "content": "import pandas as pd\nimport seaborn as sns\nimport matplotlib.pyplot as plt\nfrom datetime import datetime\n\n# Sample data setup\nnp.random.seed(42)\ndata = [\n    {'person_name': 'Mika Aalto', 'effective_start_date': '2024-09-19', 'effective_end_date': '', 'department': 'Manufacturing technology'},\n    {'person_name': 'Minna Aalto', 'effective_start_date': '2010-05-24', 'effective_end_date': '', 'department': 'Manufacturing - assembly'},\n    # Additional sample data...\n]\n\n# Convert JSON to DataFrame\ndf = pd.DataFrame(data)\n\n# Parse dates\ndf['effective_start_date'] = pd.to_datetime(df['effective_start_date'], errors='coerce')\ndf['effective_end_date'] = pd.to_datetime(df['effective_end_date'], errors='coerce')\n\n# Handling missing `effective_end_date` (assuming still employed)\ndf['effective_end_date'].fillna(pd.Timestamp.today(), inplace=True)\n\n# Filter based on Year-to-Date (YTD) condition\ncurrent_year = pd.Timestamp.now().year\ndf_ytd = df[(df['effective_start_date'].dt.year <= current_year) & (df['effective_end_date'].dt.year >= current_year)]\n\n# Aggregating headcount by department\nheadcount_by_department_report = df_ytd.groupby('department').size().reset_index(name='employee_count')\n\n# Plotting the headcount by department\nplt.figure(figsize=(10, 6))\nsns.barplot(data=headcount_by_department_report, x='department', y='employee_count', palette='Blues_d')\nplt.title('Employee Headcount by Department (YTD)')\nplt.xlabel('Department')\nplt.ylabel('Employee Count')\nplt.xticks(rotation=45)\nplt.tight_layout()\n\n# Show the plot\nplt.show()"}
        ]
    },
    {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates reports and visualizations based on user requests."},
            {"role": "user", "content": "Generate a report on Employee Satisfaction Score, broken down by department and location, filtered for full-time employees, covering the last 12 months."},
            {"role": "assistant", "content": "import pandas as pd\nimport matplotlib.pyplot as plt\nimport seaborn as sns\nfrom datetime import datetime, timedelta\n\n# Sample data setup\nnp.random.seed(42)\n# Assuming employee satisfaction data is loaded into 'satisfaction_data'\ndf = pd.DataFrame(satisfaction_data)\n\n# Filter full-time employees within the last 12 months\nlast_year = datetime.now() - timedelta(days=365)\ndf_filtered = df[(df['employment_status'] == 'Active') & (df['full_time_or_part_time'] == 'Full-Time') & (df['review_date'] >= last_year)]\n\n# Group by department and location to calculate satisfaction scores\nsatisfaction_report = df_filtered.groupby(['department', 'location'])['satisfaction_score'].mean().reset_index()\n\n# Plotting the satisfaction scores\nplt.figure(figsize=(14, 8))\nsns.barplot(data=satisfaction_report, x='department', y='satisfaction_score', hue='location')\nplt.title('Employee Satisfaction Score by Department and Location (Last 12 Months)')\nplt.xticks(rotation=45)\nplt.xlabel('Department')\nplt.ylabel('Average Satisfaction Score')\nplt.tight_layout()\n\n# Show plot\nplt.show()"}
        ]
    },
    {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates reports and visualizations based on user requests."},
            {"role": "user", "content": "Generate a Workers Compensated report, broken down by business unit and department, filtered by active employees only, covering the year-to-date (YTD)."},
            {"role": "assistant", "content": "import pandas as pd\nimport matplotlib.pyplot as plt\nimport seaborn as sns\nfrom datetime import datetime\n\n# Sample data setup\nnp.random.seed(42)\n# Assuming data is loaded into 'compensation_data' with relevant fields\ndf = pd.DataFrame(compensation_data)\n\n# Filter active employees\ncurrent_year = datetime.now().year\ndf_ytd = df[(df['employment_status'] == 'Active') & (df['compensation_date'].dt.year == current_year)]\n\n# Group by business unit and department\ncompensated_report = df_ytd.groupby(['business_unit', 'department'])['compensation_amount'].sum().reset_index()\n\n# Plotting the compensated report\nplt.figure(figsize=(14, 8))\nsns.barplot(data=compensated_report, x='business_unit', y='compensation_amount', hue='department')\nplt.title('Workers Compensated by Business Unit and Department (YTD)')\nplt.xticks(rotation=45)\nplt.xlabel('Business Unit')\nplt.ylabel('Total Compensation')\nplt.tight_layout()\n\n# Show plot\nplt.show()"}
        ]
    },
     {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates reports and visualizations based on user requests."},
            {"role": "user", "content": "Generate a Salary Distribution report, broken down by department and gender, without applying any filters or specific date range."},
            {"role": "assistant", "content": "import pandas as pd\nimport numpy as np\nimport seaborn as sns\nimport matplotlib.pyplot as plt\n\n# Sample data creation for salary distribution\nnp.random.seed(42)\ndepartments = ['Manufacturing', 'Sales', 'Engineering', 'HR', 'Marketing', 'Product Management']\ngenders = ['Male', 'Female']\nemployee_data_salary = pd.DataFrame({\n    'Employee Name': [f'Employee {i}' for i in range(1, 301)],\n    'Department': np.random.choice(departments, 300),\n    'Gender': np.random.choice(genders, 300),\n    'Salary': np.random.normal(60000, 15000, 300)  # Generating salaries with a mean of 60000 and std deviation of 15000\n})\n\n# Generating the Salary Distribution Report, broken down by department and gender\nsalary_distribution_report = employee_data_salary.groupby(['Department', 'Gender'])['Salary'].describe().reset_index()\n\n# Plotting the salary distribution using a boxplot for visualization\nplt.figure(figsize=(14, 8))\nsns.boxplot(data=employee_data_salary, x='Department', y='Salary', hue='Gender', palette='Set3')\nplt.title('Salary Distribution by Department and Gender')\nplt.xlabel('Department')\nplt.ylabel('Salary')\nplt.xticks(rotation=45)\nplt.tight_layout()\n\n# Show the plot\nplt.show()"}
        ]
    },
    {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates reports and visualizations based on user requests."},
            {"role": "user", "content": "Generate a report on Employee Headcount by department, covering YTD, without applying any filters."},
            {"role": "assistant", "content": "import pandas as pd\nimport seaborn as sns\nimport matplotlib.pyplot as plt\nfrom datetime import datetime\n\n# Sample data setup\nnp.random.seed(42)\ndata = [\n    {'person_name': 'Mika Aalto', 'effective_start_date': '2024-09-19', 'effective_end_date': '', 'department': 'Manufacturing technology'},\n    {'person_name': 'Minna Aalto', 'effective_start_date': '2010-05-24', 'effective_end_date': '', 'department': 'Manufacturing - assembly'},\n    # Additional sample data...\n]\n\n# Convert JSON to DataFrame\ndf = pd.DataFrame(data)\n\n# Parse dates\ndf['effective_start_date'] = pd.to_datetime(df['effective_start_date'], errors='coerce')\ndf['effective_end_date'] = pd.to_datetime(df['effective_end_date'], errors='coerce')\n\n# Handling missing `effective_end_date` (assuming still employed)\ndf['effective_end_date'].fillna(pd.Timestamp.today(), inplace=True)\n\n# Filter based on Year-to-Date (YTD) condition\ncurrent_year = pd.Timestamp.now().year\ndf_ytd = df[(df['effective_start_date'].dt.year <= current_year) & (df['effective_end_date'].dt.year >= current_year)]\n\n# Aggregating headcount by department\nheadcount_by_department_report = df_ytd.groupby('department').size().reset_index(name='employee_count')\n\n# Plotting the headcount by department\nplt.figure(figsize=(10, 6))\nsns.barplot(data=headcount_by_department_report, x='department', y='employee_count', palette='Blues_d')\nplt.title('Employee Headcount by Department (YTD)')\nplt.xlabel('Department')\nplt.ylabel('Employee Count')\nplt.xticks(rotation=45)\nplt.tight_layout()\n\n# Show the plot\nplt.show()"}
        ]
    },
    {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates reports and visualizations based on user requests."},
            {"role": "user", "content": "Generate a report on Employee Satisfaction Score, broken down by department and location, filtered for full-time employees, covering the last 12 months."},
            {"role": "assistant", "content": "import pandas as pd\nimport matplotlib.pyplot as plt\nimport seaborn as sns\nfrom datetime import datetime, timedelta\n\n# Sample data setup\nnp.random.seed(42)\n# Assuming employee satisfaction data is loaded into 'satisfaction_data'\ndf = pd.DataFrame(satisfaction_data)\n\n# Filter full-time employees within the last 12 months\nlast_year = datetime.now() - timedelta(days=365)\ndf_filtered = df[(df['employment_status'] == 'Active') & (df['full_time_or_part_time'] == 'Full-Time') & (df['review_date'] >= last_year)]\n\n# Group by department and location to calculate satisfaction scores\nsatisfaction_report = df_filtered.groupby(['department', 'location'])['satisfaction_score'].mean().reset_index()\n\n# Plotting the satisfaction scores\nplt.figure(figsize=(14, 8))\nsns.barplot(data=satisfaction_report, x='department', y='satisfaction_score', hue='location')\nplt.title('Employee Satisfaction Score by Department and Location (Last 12 Months)')\nplt.xticks(rotation=45)\nplt.xlabel('Department')\nplt.ylabel('Average Satisfaction Score')\nplt.tight_layout()\n\n# Show plot\nplt.show()"}
        ]
    },
    {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant that generates reports and visualizations based on user requests."},
            {"role": "user", "content": "Generate a Workers Compensated report, broken down by business unit and department, filtered by active employees only, covering the year-to-date (YTD)."},
            {"role": "assistant", "content": "import pandas as pd\nimport matplotlib.pyplot as plt\nimport seaborn as sns\nfrom datetime import datetime\n\n# Sample data setup\nnp.random.seed(42)\n# Assuming data is loaded into 'compensation_data' with relevant fields\ndf = pd.DataFrame(compensation_data)\n\n# Filter active employees\ncurrent_year = datetime.now().year\ndf_ytd = df[(df['employment_status'] == 'Active') & (df['compensation_date'].dt.year == current_year)]\n\n# Group by business unit and department\ncompensated_report = df_ytd.groupby(['business_unit', 'department'])['compensation_amount'].sum().reset_index()\n\n# Plotting the compensated report\nplt.figure(figsize=(14, 8))\nsns.barplot(data=compensated_report, x='business_unit', y='compensation_amount', hue='department')\nplt.title('Workers Compensated by Business Unit and Department (YTD)')\nplt.xticks(rotation=45)\nplt.xlabel('Business Unit')\nplt.ylabel('Total Compensation')\nplt.tight_layout()\n\n# Show plot\nplt.show()"}
        ]
    },
    
  

]

# Save as JSONL
file_path = "/Users/vishalmeena/Downloads/vishal.jsonl"
with open(file_path, 'w') as f:
    for entry in data:
        f.write(json.dumps(entry) + '\n')

file_path





# To generate the graph and report on Employee Headcount broken down by department, we will:

# 1. Load the provided JSON data into a pandas DataFrame.
# 2. Clean the data by handling missing values.
# 3. Group the data by department and count how many employees exist in each department.
# 4. Visualize the data using seaborn and matplotlib, customizing the graph with titles, labels, and a consistent color palette.

# Here's a Python script that follows these steps:

# ```python
# import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn as sns

# # Assuming the provided data is saved in the variable 'data':
# data = [
#     {'person_name': 'Mika Aalto', 'department': 'Manufacturing technology'},
#     {'person_name': 'Minna Aalto', 'department': 'Manufacturing - assembly'},
#     {'person_name': 'Jenni Aalto', 'department': 'Warehouse'},
#     # Add more data...
#     # Complete the data from the provided JSON
# ]

# # Convert JSON data to a pandas DataFrame
# df = pd.DataFrame(data)

# # Data Cleaning: Replace empty or None values in 'department' and 'person_name' with NaN and drop missing data
# df.replace('', pd.NA, inplace=True)
# df.dropna(subset=['department', 'person_name'], inplace=True)

# # Count the number of employees in each department
# department_counts = df.groupby('department').size().reset_index(name='employee_count')

# # Setting up the color palette
# sns.set_palette("Set2")

# # Plotting the employee headcount by department using seaborn
# plt.figure(figsize=(10, 8))
# ax = sns.barplot(x='employee_count', y='department', data=department_counts, ci=None)

# # Adding title and labels
# ax.set_title('Employee Headcount by Department (YTD)', fontsize=16)
# ax.set_xlabel('Number of Employees', fontsize=12)
# ax.set_ylabel('Department', fontsize=12)

# # Showing the exact count on the bar
# for index, value in enumerate(department_counts['employee_count']):
#     ax.text(value, index, str(value), color='black', va="center")

# # Improving the layout and showing the plot
# plt.tight_layout()
# plt.show()
# ```

# ### Explanation:
# 1. **Data Cleaning:**
#    - We replace any empty strings or missing values (like `None`) with pandas' `pd.NA`.
#    - Rows with missing `department` or `person_name` values are dropped.

# 2. **Grouping and Counting:**
#    - The data is grouped by the `'department'` column, and the number of employees in each department is computed using `size()`.

# 3. **Plotting:**
#    - We use `seaborn.barplot()` to visualize the employee headcount for each department.
#    - The y-axis shows the department names, while the x-axis shows the count of employees.
#    - The `text()` function is used to annotate the exact number of employees on each bar.

# ### Libraries used:
# - **pandas** for data manipulation and cleaning.
# - **matplotlib** and **seaborn** for data visualization.

# Replace the data with your actual JSON data, and this script will generate the required bar chart report.