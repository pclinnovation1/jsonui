# import openai
# import matplotlib.pyplot as plt
# from flask import Blueprint, request, send_file, jsonify, url_for, render_template
# from pymongo import MongoClient
# from reporting_and_analytics.report_mapping import report_fields_mapping
# import re
# import os
# import uuid
# # Set your OpenAI API key
# openai.api_key = 'sk-proj-hNNETxDof1nhmOdNKYPUT3BlbkFJ92wbDui4EAGztVMtA7Lv'  # Replace with your actual OpenAI API key
 
# generate_report = Blueprint('generate_report', __name__)

# # Directory where images will be saved temporarily
# TEMP_IMAGE_FOLDER = "static/temp_images"

# if not os.path.exists(TEMP_IMAGE_FOLDER):
#     os.makedirs(TEMP_IMAGE_FOLDER)
 
# client = MongoClient('mongodb://oras_user:oras_pass@172.191.245.199:27017/oras')  # Modify according to your MongoDB setup
# db = client['oras']
 
 
# def get_dynamic_graph_code(report_type, data, description):
#     print("get_dynamic_graph_code called ")
#     """
#     Generates Python code to create a graph based on the report type, user description, and data using OpenAI.
 
#     Args:
#     - report_type (str): The type of report for which the graph should be generated.
#     - data (list): The data for creating the graph.
#     - description (str): The user-provided description of the graph.
 
#     Returns:
#     - str: Python code that generates a graph.
#     """
    
#     prompt = f"""
#     You are a Python coding assistant. Based on the graph tdescription and the provided JSON data, generate Python code to create a suitable graph using matplotlib and pandas.
    
#     Here is the user-provided description of the graph:
#     "{description}"
    
#     JSON Data:
#     {data}

#     Instructions: 
#     - Please not truncated data for simplicity. You can use the full data to generate the graph because you are intelligent and can handle large datasets.
#     - This is not for demonstration purposes, so you can use the full data to generate the graph.
#     - You doesn't make any assumptions about the data that i will replace sample data with actual data. You can use the data as it is to generate the graph.
#     - Generate Python code that perform data cleaning, handle missing values, and create graphs for data analysis using seaborn and matplotlib.
#     - Create graphs according to the {report_type} and {description}. 
#     - Customize the graphs with titles, labels, and a consistent color palette. Use approiate libraries and functions to create the graphs.
#     """

#     response = openai.ChatCompletion.create(
#         model="chatgpt-4o-latest",
#         messages=[
#             {"role": "system", "content": "You are a helpful assistant for generating Python code for data visualization."},
#             {"role": "user", "content": prompt}
#         ],
#         max_tokens=16384
#     )
 
#     # Extract the generated code from the response
#     graph_code = response['choices'][0]['message']['content']
    
#     # Use regex to remove unwanted parts and only get the Python code
#     # We're looking for anything between ```python and ```
#     code_match = re.search(r"```python(.*?)```", graph_code, re.DOTALL)
#     if code_match:
#         graph_code = code_match.group(1).strip()  # Get the Python code block without the backticks
#     else:
#         print("Error: Could not extract valid Python code from the response.")
#         return None
    
#     return graph_code
 
 
 
# def replace_data_with_full_dataset(generated_code, full_data):
#     """
#     Replaces the subset data in the generated code with the full dataset.
 
#     Args:
#     - generated_code (str): The generated Python code from OpenAI.
#     - full_data (list): The full dataset for 500+ employees.
 
#     Returns:
#     - str: The modified Python code with full dataset.
#     """
#     # Extract the data section from the generated code using regex
#     data_pattern = re.compile(r'data = \[.*?\]', re.DOTALL)
   
#     # Prepare the full dataset in the same format as the subset data
#     full_data_str = f"data = {full_data}"
   
#     # Replace the subset data with the full dataset
#     modified_code = re.sub(data_pattern, full_data_str, generated_code)
   
#     return modified_code
 
 
 
 
# @generate_report.route('/generate-report', methods=['POST'])
# def generate_report1():
#     request_data = request.get_json()
#     report_name = request_data.get('report_name')
#     user_description = request_data.get('description')  # User-provided description
 
#     # Fetch the report info from the report_fields_mapping1
#     report_info = report_fields_mapping.get(report_name)
#     if not report_info:
#         return jsonify({"error": "Invalid report name provided."}), 400
 
#     # Initialize full_data
#     full_data = []
 
#     # Fetch full data from all collections (without limiting to 50 employees)
#     for idx, (collection_name, field_names) in enumerate(report_info.items()):
#         projection = {field: 1 for field in field_names}
#         projection.update({'_id': 0})
 
#         # Fetch full dataset from each collection
#         collection_data = list(db[collection_name].find({}, projection).limit(100))
 
#         if idx == 0:
#             # Initialize full_data with the first collection
#             full_data = collection_data
#         else:
#             # Merge this collection's data with the full_data based on 'person_name'
#             collection_data_dict = {employee['person_name']: employee for employee in collection_data}
 
#             for employee in full_data:
#                 person_name = employee.get('person_name')
#                 if person_name and person_name in collection_data_dict:
#                     # Merge fields from this collection's data into full_data
#                     for key in field_names:
#                         employee[key] = collection_data_dict[person_name].get(key, None)
                        
#     # Get dynamic graph code from OpenAI using the full data and the user description
#     graph_code = get_dynamic_graph_code(report_name, full_data, user_description)
    
#     if graph_code is None:
#         # Return an error response if the graph_code could not be generated
#         return jsonify({"error": "Failed to generate graph code from OpenAI."}), 500
 
#     print('Graph Code:', graph_code)
 
#     # Replace the fukk data with the full dataset in the generated code because openai doesn't support large data
#     modified_code = replace_data_with_full_dataset(graph_code, full_data)
 
#     # print('Modified Code:', modified_code)
    
    # # Generate a unique filename to save the image
    # image_filename = f"{uuid.uuid4().hex}.png"
    # image_path = os.path.join(TEMP_IMAGE_FOLDER, image_filename)
 
    # # Execute the dynamically generated and modified code
    # local_scope = {}
    # exec(modified_code, {"plt": plt}, local_scope)
    
    # # Save the graph to the image path
    # plt.savefig(image_path)
    # plt.close()

    # # Generate a URL to access the image in a temporary UI
    # image_url = url_for('generate_report.show_image', image_filename=image_filename, _external=True)
    # view_image_url = url_for('generate_report.view_image', image_filename=image_filename, _external=True)

    # # Return a link to view the image in the frontend
    # return jsonify({
    #     "view_image_url": view_image_url
    # })
 
# # Route to show the image directly (you can access this from the URL)
# @generate_report.route('/image/<image_filename>')
# def show_image(image_filename):
#     image_path = os.path.join(TEMP_IMAGE_FOLDER, image_filename)
#     return send_file(image_path, mimetype='image/png')

# # Route to display the image in a temporary UI
# @generate_report.route('/view-image/<image_filename>')
# def view_image(image_filename):
#     image_url = url_for('generate_report.show_image', image_filename=image_filename, _external=True)
#     return render_template('view_image.html', image_url=image_url)

 
# #All graph generation on bigger data(more than 100 employee) use this approach until find any better approach. If anyone find any better approach then notify.
 
 
 
 
 

 
# #All graph generation on bigger data(more than 100 employee) use this approach until find any better approach. If anyone find any better approach then notify.
import openai
import pandas as pd
import matplotlib.pyplot as plt
from flask import Blueprint, request, send_file, jsonify, url_for, render_template,Flask
from io import BytesIO
from pymongo import MongoClient
from HR_graph_fields import generate_graph_fields
import re
import os
import uuid
import openai
import json
# Use only this correct import statement:
from langchain_community.chat_models import ChatOpenAI

import openai
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Set the backend to 'Agg' before importing pyplot
import matplotlib.pyplot as plt
import seaborn as sns
from flask import Blueprint, request, send_file, jsonify, url_for, render_template, Flask
from pymongo import MongoClient
from HR_graph_fields import generate_graph_fields
import re
import os
import uuid


 
# Set your OpenAI API key
openai.api_key = 'sk-NxUOgf2v9s8a5-ixe6ZGdXz89zfG7A4Xpio91Yk2ehT3BlbkFJ8XJgrEFPwx-F1YFoqAGdYWYxyUMcNFbDgOtwm2TaYA'  # Replace with your actual OpenAI API key
app = Flask(__name__)
generate_report = Blueprint('generate_report', __name__)
 
# Directory where images will be saved temporarily
TEMP_IMAGE_FOLDER = "static/temp_images"
 
if not os.path.exists(TEMP_IMAGE_FOLDER):
    os.makedirs(TEMP_IMAGE_FOLDER)
 
client = MongoClient('mongodb://oras_user:oras_pass@172.191.245.199:27017/oras')  # Modify according to your MongoDB setup
db = client['oras']
 

def get_dynamic_graph_code(report_type, data, description):
    print("get_dynamic_graph_code called ")
   
    """
    Generates Python code to create a graph based on the report type, user description, and data using OpenAI.
 
    Args:
    - report_type (str): The type of report for which the graph should be generated.
    - data (list): The data for creating the graph.
    - description (str): The user-provided description of the graph.
 
    Returns:
    - str: Python code that generates a graph.
    """
    
    prompt = f"""
    You are a Python coding assistant. Based on the graph tdescription and the provided JSON data, generate Python code to create a suitable graph using matplotlib and pandas.
    
    Here is the user-provided description of the graph:
    "{description}"
    
    

    Instructions: 
    - Please not truncated data for simplicity. You can use the full data to generate the graph because you are intelligent and can handle large datasets.
    - This is not for demonstration purposes, so you can use the full data to generate the graph.
    - You doesn't make any assumptions about the data that i will replace sample data with actual data. You can use the data as it is to generate the graph.
    - Generate Python code that perform data cleaning, handle missing values, and create graphs for data analysis using seaborn and matplotlib.
    - Create graphs according to the {report_type} and {description}. 
    - Customize the graphs with titles, labels, and a consistent color palette. Use approiate libraries and functions to create the graphs.
    - Assume that I will upload same data as given in the JSON data. and you can use the same data to generate the graph. And it will be "data = given data".\
    - also check any syntax error in code before gioving it run it on you side 
   JSON Data
    {data}
 
   """
    
    

    response = openai.ChatCompletion.create(
        model="ft:gpt-4o-mini-2024-07-18:algonxai::AC6Iikxr",
        messages=[
            {"role": "system", "content": "You are a helpful assistant for generating Python code for data visualization."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=16384
    )
 
    # Extract the generated code from the response
    graph_code = response['choices'][0]['message']['content']
    print(graph_code)
    # Use regex to remove unwanted parts and only get the Python code
    # We're looking for anything between ```python and ```
    code_match = re.search(r"```python(.*?)```", graph_code, re.DOTALL)
    if code_match:
        graph_code = code_match.group(1).strip()  # Get the Python code block without the backticks
    else:
        print("Error: Could not extract valid Python code from the response.")
        return None
    
    return graph_code
 
 
def replace_data_with_full_dataset(generated_code, full_data):
    """
    Replaces the subset data in the generated code with the full dataset.
 
    Args:
    - generated_code (str): The generated Python code from OpenAI.
    - full_data (list): The full dataset for 500+ employees.
 
    Returns:
    - str: The modified Python code with full dataset.
    """
    # Extract the data section from the generated code using regex
    data_pattern = re.compile(r'data = \[.*?\]', re.DOTALL)
   
    # Prepare the full dataset in the same format as the subset data
    full_data_str = f"data = {full_data}"
   
    # Replace the subset data with the full dataset
    modified_code = re.sub(data_pattern, full_data_str, generated_code)
   
    return modified_code
 


 
 
@generate_report.route('/generate-report', methods=['POST'])
def generate_report2():
    request_data = request.get_json()
    report_name = request_data.get('report_name')
    print("report name : ", report_name)
    print("*"*25)
    user_description = request_data.get('description')  # User-provided description
 
    # Fetch the report info from the report_fields_mapping1
    #report_info = report_fields_mapping.get(report_name)
    report_info = generate_graph_fields(user_description)
    if not report_info:
        return jsonify({"error": "Invalid report name pr.ovided."}), 400
 
    # Initialize full_data
    full_data = []
 
    # Fetch full data from all collections (without limiting to 50 employees)
    for idx, (collection_name, field_names) in enumerate(report_info.items()):
        projection = {field: 1 for field in field_names}
        projection.update({'_id': 0})

        print("collection name : ", collection_name)
        print("*"*25)
        # Fetch full dataset from each collection
        collection_data = list(db[collection_name].find({}, projection).limit(150))
        # collection_data = list(db[collection_name].find({}, projection))
        
        print('collection name : ',collection_data)
        print("*"*25)
        print()

        if idx == 0:
            # Initialize full_data with the first collection
            full_data = collection_data
        else:
            # Merge this collection's data with the full_data based on 'person_name'
            collection_data_dict = {employee.get('person_name', 'Unknown'): employee for employee in collection_data}
            for employee in full_data:
                person_name = employee.get('person_name')
                if person_name and person_name in collection_data_dict:
                    # Merge fields from this collection's data into full_data
                    for key in field_names:
                        employee[key] = collection_data_dict[person_name].get(key, None)

    print("Full data : ",full_data)
                       
    # Get dynamic graph code from OpenAI using the full data and the user description
    graph_code = get_dynamic_graph_code(report_name, full_data, user_description)

    if graph_code is None:
        # Return an error response if the graph_code could not be generated
        return jsonify({"error": "Failed to generate graph code from OpenAI."}), 500
 
    print('Graph Code:', graph_code)
 
    # Replace the fukk data with the full dataset in the generated code because openai doesn't support large data
    modified_code = replace_data_with_full_dataset(graph_code, full_data)
 
    print('Modified Code:', modified_code)
   
        # Generate a unique filename to save the image
    image_filename = f"{uuid.uuid4().hex}.png"
    image_path = os.path.join(TEMP_IMAGE_FOLDER, image_filename)
 
    # Execute the dynamically generated and modified code
    local_scope = {}
    exec(modified_code, {"plt": plt, "pd": pd, "sns": sns}, local_scope)    
    # Save the graph to the image path
    plt.savefig(image_path)
    plt.close()

    # Generate a URL to access the image in a temporary UI
    image_url = url_for('generate_report.show_image', image_filename=image_filename, _external=True)
    view_image_url = url_for('generate_report.view_image', image_filename=image_filename, _external=True)

    # Return a link to view the image in the frontend
    return jsonify({
        "view_image_url": view_image_url
    })
 
# Route to show the image directly (you can access this from the URL)
@generate_report.route('/image/<image_filename>')
def show_image(image_filename):
    image_path = os.path.join(TEMP_IMAGE_FOLDER, image_filename)
    return send_file(image_path, mimetype='image/png')
 
# Route to display the image in a temporary UI
@generate_report.route('/view-image/<image_filename>')
def view_image(image_filename):
    image_url = url_for('generate_report.show_image', image_filename=image_filename, _external=True)
    return render_template('view_image.html', image_url=image_url)


@generate_report.route('/generate-report2', methods=['POST'])
def generate_report3():
    request_data = request.get_json()
    report_name = request_data.get('report_name')
    print("report name : ", report_name)
    print("*" * 25)
    user_description = request_data.get('description')  # User-provided description

    # Fetch the report info from the report_fields_mapping1
    report_info = generate_graph_fields(user_description)
    print(report_info)
    if not report_info:
        return jsonify({"error": "Invalid report name provided."}), 400

    # Initialize full_data
    full_data = []

    # Fetch full data from all collections (without limiting to 50 employees)
    for idx, (collection_name, field_names) in enumerate(report_info.items()):
        projection = {field: 1 for field in field_names}
        projection.update({'_id': 0})

        print("collection name : ", collection_name)
        print("*" * 25)
        # Fetch full dataset from each collection
        collection_data = list(db[collection_name].find({}, projection).limit(50))

        print('collection name : ', collection_data)
        print("*" * 25)
        
        collection_data2 = list(db[collection_name].find({}, projection).limit(1500))
        print()
        if idx == 0:
            # Initialize full_data with the first collection
            full_data = collection_data
        else:
            # Merge this collection's data with the full_data based on 'person_name'
            collection_data_dict = {employee.get('person_name', 'Unknown'): employee for employee in collection_data}

            for employee in full_data:
                person_name = employee.get('person_name')
                if person_name and person_name in collection_data_dict:
                    # Merge fields from this collection's data into full_data
                    for key in field_names:
                        employee[key] = collection_data_dict[person_name].get(key, None)

        if idx == 0:
            # Initialize full_data with the first collection
            full_data2 = collection_data2
        else:
            # Merge this collection's data with the full_data based on 'person_name'
            collection_data_dict2 = {employee.get('person_name', 'Unknown'): employee for employee in collection_data2}

            for employee in full_data2:
                person_name = employee.get('person_name')
                if person_name and person_name in collection_data_dict2:
                    # Merge fields from this collection's data into full_data
                    for key in field_names:
                        employee[key] = collection_data_dict2[person_name].get(key, None)

    print("Full data : /n", full_data)
    print("colection 2 data :/n",full_data2)
    # Get dynamic graph code from OpenAI using the full data and the user description



    custom_code = """
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
 
# Provided JSON data
data = [{'person_name': 'Mika Aalto', 'department': 'Manufacturing technology', 'base_salary': 3215.39, 'currency': 'EUR'}, {'person_name': 'Minna Aalto', 'department': 'Manufacturing - assembly', 'base_salary': 2939.19, 'currency': 'EUR'}, {'person_name': 'Jenni Aalto', 'department': 'Sales network', 'base_salary': 2342.35, 'currency': 'EUR'}, {'person_name': 'Ossi Aalto', 'department': 'Product Management', 'base_salary': 4949.53, 'currency': 'EUR'}, {'person_name': 'Katja Aaltonen', 'department': 'Manufacturing', 'base_salary': 3773.18, 'currency': 'EUR'}, {'person_name': 'Marja Aaltonen', 'department': 'Warehouse', 'base_salary': 2846.7, 'currency': 'EUR'}, {'person_name': 'Eirik HaralDirect AmunDirectsen AaneruDirect', 'department': 'Sales network', 'base_salary': 51223, 'currency': 'NOK'}, {'person_name': 'Jacek ADirectamczak', 'department': 'Manufacturing', 'base_salary': 4700, 'currency': 'PLN'}, {'person_name': 'Marek Adamčík', 'department': 'Sales network', 'base_salary': 196546, 'currency': 'CZK'}, {'person_name': 'Mats ADirectolfsson', 'department': 'Sales network', 'base_salary': 49820.26, 'currency': 'SEK'}, {'person_name': 'Sakari Aho', 'department': 'Sales Controlling', 'base_salary': 5979.49, 'currency': 'EUR'}, {'person_name': 'Laura Aho', 'department': 'Manufacturing - chrome plating', 'base_salary': 2249.74, 'currency': 'EUR'}, {'person_name': 'Niko Ala-Pappila', 'department': 'Manufacturing - assembly', 'base_salary': 2141.6, 'currency': 'EUR'}, {'person_name': 'Jukka Alhola', 'department': 'Product Management', 'base_salary': 4596.96, 'currency': 'EUR'}, {'person_name': 'Tom AnDirectersen', 'department': 'Sales network', 'base_salary': 55592, 'currency': 'NOK'}, {'person_name': 'Maria AnDirectersson', 'department': 'Sales network', 'base_salary': 46115.27, 'currency': 'SEK'}, {'person_name': 'Janne Antola', 'department': 'Project Management', 'base_salary': 7715.81, 'currency': 'EUR'}, {'person_name': 'Erja Anturamäki', 'department': 'Manufacturing - injection molDirecting', 'base_salary': 2453.95, 'currency': 'EUR'}, {'person_name': 'Jari Aro-Heinilä', 'department': 'Manufacturing', 'base_salary': 3082.72, 'currency': 'EUR'}, {'person_name': 'Toni Arvela', 'department': 'Warehouse', 'base_salary': 2788.19, 'currency': 'EUR'}, {'person_name': 'Siw AsplunDirect', 'department': 'Sales network', 'base_salary': 66301, 'currency': 'NOK'}, {'person_name': 'Katarzyna Augustyniak', 'department': 'Manufacturing - assembly', 'base_salary': 2349.06, 'currency': 'EUR'}, {'person_name': 'Virpi Autio', 'department': 'Logistics', 'base_salary': 4944.35, 'currency': 'EUR'}, {'person_name': 'Petra Baborová', 'department': 'Manufacturing', 'base_salary': 43789, 'currency': 'CZK'}, {'person_name': 'Agnieszka Bachórz', 'department': 'Export', 'base_salary': 7850, 'currency': 'PLN'}, {'person_name': 'Joanna Barbacka', 'department': 'Customer service & Sales support', 'base_salary': 8850, 'currency': 'PLN'}, {'person_name': 'Piotr BarDirectosz', 'department': 'Manufacturing', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Ewa BarDirectosz', 'department': 'Manufacturing', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Renata Baros', 'department': 'Manufacturing', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Directorota Barowska', 'department': 'Manufacturing', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Kamil Barowski', 'department': 'Logistics', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Zygmunt Barowski', 'department': 'Manufacturing', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Sebastian Barszczewski', 'department': 'Quality', 'base_salary': 5145, 'currency': 'PLN'}, {'person_name': 'AnDirectrzej Bartoszek', 'department': 'Manufacturing', 'base_salary': 6800, 'currency': 'PLN'}, {'person_name': 'Václav Baum', 'department': 'Logistic', 'base_salary': 18700, 'currency': 'CZK'}, {'person_name': 'Katarzyna Bawej', 'department': 'Production scheduling', 'base_salary': 5009, 'currency': 'PLN'}, {'person_name': 'Roman Bawej', 'department': 'Manufacturing - assembly', 'base_salary': 6000, 'currency': 'PLN'}, {'person_name': 'Renata Belka', 'department': 'Quality', 'base_salary': 5541, 'currency': 'PLN'}, {'person_name': 'Aleksandra Bensz', 'department': 'Customer service & Sales support', 'base_salary': 7996, 'currency': 'PLN'}, {'person_name': 'Arne Berentsen', 'department': 'Sales network', 'base_salary': 58789, 'currency': 'NOK'}, {'person_name': 'Monika Bernaś', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'DirectavIndirecte Berni', 'department': 'Sales network', 'base_salary': 2512.29, 'currency': 'EUR'}, {'person_name': 'Jaroslava Bihariová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Directominika Biskup', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Kjetil Bjerkeset', 'department': 'Sales network', 'base_salary': 58789, 'currency': 'NOK'}, {'person_name': 'Marzena Blabuś', 'department': 'Manufacturing', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Franciszek Blaszczok', 'department': 'Manufacturing', 'base_salary': 6200, 'currency': 'PLN'}, {'person_name': 'Laura Blomster', 'department': 'Customer service & Sales support', 'base_salary': 3498.61, 'currency': 'EUR'}, {'person_name': 'Milan Bláha', 'department': 'Manufacturing - assembly', 'base_salary': 21300, 'currency': 'CZK'}, {'person_name': 'Krzysztof Bomba', 'department': 'Manufacturing', 'base_salary': 6664, 'currency': 'PLN'}, {'person_name': 'Thomas Boochs', 'department': 'Manufacturing', 'base_salary': 5704.4, 'currency': 'CZK'}, {'person_name': 'Ron BouDirectestijn', 'department': 'Sales network', 'base_salary': 6063.35, 'currency': 'EUR'}, {'person_name': 'Directana Brabcová', 'department': 'Customer service & Sales support', 'base_salary': 88000, 'currency': 'CZK'}, {'person_name': 'Kamil BroDirectacki', 'department': 'Manufacturing', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Walenty BroDirectacki', 'department': 'Manufacturing', 'base_salary': 6664, 'currency': 'PLN'}, {'person_name': 'Bernard Brodacki', 'department': 'Manufacturing', 'base_salary': 6800, 'currency': 'PLN'}, {'person_name': 'Oleksii Brunko', 'department': 'Sales network', 'base_salary': 10400, 'currency': 'PLN'}, {'person_name': 'Alicja Brycka', 'department': 'Manufacturing - chrome plating', 'base_salary': 7056, 'currency': 'PLN'}, {'person_name': 'Tiina Bryggare', 'department': 'Manufacturing - assembly', 'base_salary': 2576.47, 'currency': 'EUR'}, {'person_name': 'Anna Brzenska', 'department': 'Manufacturing', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Adam Brzuchnalski', 'department': 'Manufacturing Technology', 'base_salary': 10396, 'currency': 'PLN'}, {'person_name': 'Anna Bubrowska', 'department': 'Customer service & Sales support', 'base_salary': 8542, 'currency': 'PLN'}, {'person_name': 'Henryk BurDirecta', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'ADirectéla Bílková', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Natalia Bębenek', 'department': 'Manufacturing - chrome plating', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Jaroslava Běláčová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Ivana Březinová', 'department': 'Quality', 'base_salary': 16800, 'currency': 'CZK'}, {'person_name': 'Ian Cemann', 'department': 'Marketing', 'base_salary': 63300, 'currency': 'DKK'}, {'person_name': 'Łukasz ChenDirectyński', 'department': 'Manufacturing', 'base_salary': 5700, 'currency': 'PLN'}, {'person_name': 'Paweł Chlastała', 'department': 'Manufacturing - chrome plating', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Natalia Chmiel', 'department': 'Manufacturing', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Patrycja Chrapek', 'department': 'Customer service & Sales support', 'base_salary': 10650, 'currency': 'PLN'}, {'person_name': 'Krzysztof Chrobok', 'department': 'Manufacturing', 'base_salary': 6664, 'currency': 'PLN'}, {'person_name': 'Iwona Chyra', 'department': 'Customer service & Sales support', 'base_salary': 7900, 'currency': 'PLN'}, {'person_name': 'Directorota Cichoń', 'department': 'Manufacturing - chrome plating', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Marian Cichoń', 'department': 'Manufacturing', 'base_salary': 5700, 'currency': 'PLN'}, {'person_name': 'Marcin Cieślak', 'department': 'Manufacturing', 'base_salary': 7036, 'currency': 'PLN'}, {'person_name': 'Tomasz Czernek', 'department': 'Quality', 'base_salary': 12480, 'currency': 'PLN'}, {'person_name': 'Filip Czyrny', 'department': 'Manufacturing', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Ewelina Czyż', 'department': 'Customer service & Sales support', 'base_salary': 9256, 'currency': 'PLN'}, {'person_name': 'Duilio Daniele', 'department': 'Sales network', 'base_salary': 6615.5, 'currency': 'EUR'}, {'person_name': 'Rikard Danielsson', 'department': 'Sales network', 'base_salary': 48558.06, 'currency': 'SEK'}, {'person_name': 'Wolfgang Degen', 'department': 'Sales network', 'base_salary': 6151.57, 'currency': 'EUR'}, {'person_name': 'Agnieszka Deinhard', 'department': 'Manufacturing', 'base_salary': 4816, 'currency': 'PLN'}, {'person_name': 'Didier Denis', 'department': 'Customer service & Sales support', 'base_salary': 4289.3, 'currency': 'EUR'}, {'person_name': 'Martina Deverová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Richard Dietz', 'department': 'Technical Communication', 'base_salary': 5603.19, 'currency': 'EUR'}, {'person_name': 'Ron Dijkmans', 'department': 'Sales network', 'base_salary': 6528.33, 'currency': 'EUR'}, {'person_name': 'Sonja Doering', 'department': 'Purchasing', 'base_salary': 4168.14, 'currency': 'EUR'}, {'person_name': 'Knut Dokken', 'department': 'Customer service & Sales support', 'base_salary': 44280, 'currency': 'NOK'}, {'person_name': 'Magdalena Drab', 'department': 'Quality', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Zdzisław Drab', 'department': 'Manufacturing', 'base_salary': 5415, 'currency': 'PLN'}, {'person_name': 'Marcin Dragan', 'department': 'Manufacturing', 'base_salary': 5700, 'currency': 'PLN'}, {'person_name': 'Ralf Drees', 'department': 'Sales network', 'base_salary': 4615.37, 'currency': 'EUR'}, {'person_name': 'Dawid Dreja', 'department': 'Manufacturing', 'base_salary': 4300, 'currency': 'PLN'}, {'person_name': 'Aleksander Drewicz', 'department': 'Manufacturing', 'base_salary': 5359, 'currency': 'PLN'}, {'person_name': 'Gerald Droese', 'department': 'Sales management', 'base_salary': 4615.37, 'currency': 'EUR'}, {'person_name': 'Ewelina Drożdżyk', 'department': 'Customer service & Sales support', 'base_salary': 8750, 'currency': 'PLN'}, {'person_name': 'Ulrike Dubarry', 'department': 'Product Management', 'base_salary': 3886.5, 'currency': 'EUR'}, {'person_name': 'Marek Dubiel', 'department': 'Manufacturing', 'base_salary': 5393, 'currency': 'PLN'}, {'person_name': 'Julia Duda', 'department': 'Manufacturing - assembly', 'base_salary': 4737, 'currency': 'PLN'}, {'person_name': 'Tomasz Dudek', 'department': 'Quality', 'base_salary': 5636, 'currency': 'PLN'}, {'person_name': 'Rafał Dyderski', 'department': 'Manufacturing', 'base_salary': 4631, 'currency': 'PLN'}, {'person_name': 'Karolina Dydyk', 'department': 'Controlling and Finance', 'base_salary': 9833, 'currency': 'PLN'}, {'person_name': 'Krzysztof Dąbrowski', 'department': 'Manufacturing', 'base_salary': 6800, 'currency': 'PLN'}, {'person_name': 'Martyna Edelman', 'department': 'Quality', 'base_salary': 5409, 'currency': 'PLN'}, {'person_name': 'Esa Eeva', 'department': 'Manufacturing - chrome plating', 'base_salary': 3255.84, 'currency': 'EUR'}, {'person_name': 'Uwe Eichelberg', 'department': 'Sales network', 'base_salary': 5079.58, 'currency': 'EUR'}, {'person_name': 'Zdeněk Eisenhammer', 'department': 'Manufacturing', 'base_salary': 63862, 'currency': 'CZK'}, {'person_name': 'Annastiina Elonen', 'department': 'IT', 'base_salary': 3817.11, 'currency': 'EUR'}, {'person_name': 'Sari Elonen', 'department': 'Manufacturing - assembly', 'base_salary': 2676.03, 'currency': 'EUR'}, {'person_name': 'Annika Englund', 'department': 'Warehouse', 'base_salary': 2459.41, 'currency': 'EUR'}, {'person_name': 'Toni Englund', 'department': 'Warehouse', 'base_salary': 3255.84, 'currency': 'EUR'}, {'person_name': 'Tomi Eskola', 'department': 'Manufacturing', 'base_salary': 4203.56, 'currency': 'EUR'}, {'person_name': 'Heidi Evilampi', 'department': 'IT', 'base_salary': 5880.44, 'currency': 'EUR'}, {'person_name': 'Christa Evomaa', 'department': 'Manufacturing', 'base_salary': 3033.79, 'currency': 'EUR'}, {'person_name': 'Jan Falkenberg', 'department': 'Purchasing', 'base_salary': 9720, 'currency': 'EUR'}, {'person_name': 'Zuzanna Feliks', 'department': 'Manufacturing - assembly', 'base_salary': 4919, 'currency': 'PLN'}, {'person_name': 'Paweł Felke', 'department': 'Manufacturing', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Ralf Fels', 'department': 'Manufacturing', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Adam Fiączek', 'department': 'Manufacturing - assembly', 'base_salary': 6781, 'currency': 'PLN'}, {'person_name': 'Lesław Fiączek', 'department': 'Manufacturing', 'base_salary': 5600, 'currency': 'PLN'}, {'person_name': 'Kaj Forsell', 'department': 'Manufacturing - assembly', 'base_salary': 3437.4, 'currency': 'EUR'}, {'person_name': 'Kateřina Fraňková', 'department': 'Controlling and Finance', 'base_salary': 26950, 'currency': 'CZK'}, {'person_name': 'Georg Friedrichs', 'department': 'Sales network', 'base_salary': 5276.83, 'currency': 'EUR'}, {'person_name': 'Sabine Fromkorth', 'department': 'Purchasing', 'base_salary': 5315.84, 'currency': 'EUR'}, {'person_name': 'Katja Früh', 'department': 'Sales management', 'base_salary': 1943.25, 'currency': 'EUR'}, {'person_name': 'Paweł Frąckiewicz', 'department': 'Controlling and Finance', 'base_salary': 35438, 'currency': 'PLN'}, {'person_name': 'Ewa Gagat', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Piotr Gajdecki', 'department': 'Supply chain management', 'base_salary': 6171, 'currency': 'PLN'}, {'person_name': 'Ewa Galant', 'department': 'Supply chain management', 'base_salary': 5033, 'currency': 'PLN'}, {'person_name': 'Grzegorz Galant', 'department': 'Supply chain management', 'base_salary': 6807, 'currency': 'PLN'}, {'person_name': 'Marian Gallus', 'department': 'IT', 'base_salary': 7283, 'currency': 'PLN'}, {'person_name': 'Grażyna Gambka', 'department': 'Manufacturing - assembly', 'base_salary': 4830, 'currency': 'PLN'}, {'person_name': 'Tomasz Gatnar', 'department': 'Supply chain management', 'base_salary': 7300, 'currency': 'PLN'}, {'person_name': 'Anna Gburek', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Patrick Gerdon', 'department': 'Sales network', 'base_salary': 7666.78, 'currency': 'EUR'}, {'person_name': 'Cédric Gilbert', 'department': 'Sales network', 'base_salary': 5396.82, 'currency': 'EUR'}, {'person_name': 'Tomasz Gliński', 'department': 'Supply chain management', 'base_salary': 6800, 'currency': 'PLN'}, {'person_name': 'Jarosław Grabarek', 'department': 'Supply chain management', 'base_salary': 5700, 'currency': 'PLN'}, {'person_name': 'Simen Grong', 'department': 'Customer service & Sales support', 'base_salary': 43942, 'currency': 'NOK'}, {'person_name': 'Joanna Gruca', 'department': 'Manufacturing - assembly', 'base_salary': 4830, 'currency': 'PLN'}, {'person_name': 'Patrycja Gruca', 'department': 'Production scheduling', 'base_salary': 6350, 'currency': 'PLN'}, {'person_name': 'Sławomir Gruca', 'department': 'Logistics', 'base_salary': 5500, 'currency': 'PLN'}, {'person_name': 'Edward Grus', 'department': 'Supply chain management', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Katarzyna Grzegorzewicz', 'department': 'Customer service & Sales support', 'base_salary': 10088, 'currency': 'PLN'}, {'person_name': 'Rafał Grzeliński', 'department': 'Supply chain management', 'base_salary': 4988, 'currency': 'PLN'}, {'person_name': 'Emilia Grzemba', 'department': 'Supply chain management', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Laura Gręda', 'department': 'Marketing', 'base_salary': 2500, 'currency': 'PLN'}, {'person_name': 'Joanna Gręda', 'department': 'Customer service & Sales support', 'base_salary': 9093, 'currency': 'PLN'}, {'person_name': 'Anna Gręda-Pankosz', 'department': 'Controlling and Finance', 'base_salary': 8699, 'currency': 'PLN'}, {'person_name': 'Jerzy Gärtner', 'department': 'Supply chain management', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Przemysław Górnicki', 'department': 'Supply chain management', 'base_salary': 6664, 'currency': 'PLN'}, {'person_name': 'Ines Götter', 'department': 'Purchasing', 'base_salary': 3591.79, 'currency': 'EUR'}, {'person_name': 'Marcin Gąsiorowski', 'department': 'Supply chain management', 'base_salary': 5800, 'currency': 'PLN'}, {'person_name': 'Anna Gęsikowska', 'department': 'Manufacturing - assembly', 'base_salary': 4830, 'currency': 'PLN'}, {'person_name': 'Agnieszka Głuch', 'department': 'Supply chain management', 'base_salary': 11196, 'currency': 'PLN'}, {'person_name': 'Tanja Haanpää', 'department': 'Manufacturing - chrome plating', 'base_salary': 2615.85, 'currency': 'EUR'}, {'person_name': 'Susanna Haapala', 'department': 'Quality', 'base_salary': 2775.58, 'currency': 'EUR'}, {'person_name': 'Tuike Haavisto', 'department': 'Manufacturing - assembly', 'base_salary': 2523.29, 'currency': 'EUR'}, {'person_name': 'Anna Habrajska', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Christian Hack', 'department': 'Sales network', 'base_salary': 5365.2, 'currency': 'EUR'}, {'person_name': 'Daniel Haglund', 'department': 'Customer service & Sales support', 'base_salary': 49319.99, 'currency': 'SEK'}, {'person_name': 'Susanne Halck', 'department': 'Marketing', 'base_salary': 64793.75, 'currency': 'NOK'}, {'person_name': 'Andrzej Hanas', 'department': 'Supply chain management', 'base_salary': 6000, 'currency': 'PLN'}, {'person_name': 'Daniel Heeren', 'department': 'Sales network', 'base_salary': 6634.41, 'currency': 'EUR'}, {'person_name': 'Jukka Heikkinen', 'department': 'Supply chain management', 'base_salary': 4691.71, 'currency': 'EUR'}, {'person_name': 'Katja Heinonen', 'department': 'Manufacturing - assembly', 'base_salary': 2515.21, 'currency': 'EUR'}, {'person_name': 'Emmi Heinonen', 'department': 'Supply chain management', 'base_salary': 2609.29, 'currency': 'EUR'}, {'person_name': 'Anne Helin', 'department': 'Manufacturing - chrome plating', 'base_salary': 2763.55, 'currency': 'EUR'}, {'person_name': 'Saara Helkama', 'department': 'Logistics', 'base_salary': 3628.83, 'currency': 'EUR'}, {'person_name': 'Reija Helkkula', 'department': 'Product Management', 'base_salary': 3061.95, 'currency': 'EUR'}, {'person_name': 'Sini Helleaho', 'department': 'Warehouse', 'base_salary': 2403.51, 'currency': 'EUR'}, {'person_name': 'Leila Hiekkanen', 'department': 'Manufacturing - assembly', 'base_salary': 2808.41, 'currency': 'EUR'}, {'person_name': 'Heli Hiekkanen', 'department': 'Manufacturing - assembly', 'base_salary': 2537.39, 'currency': 'EUR'}, {'person_name': 'Teemu Hietikko', 'department': 'Technical Communication', 'base_salary': 3204.09, 'currency': 'EUR'}, {'person_name': 'Manu Hietikko', 'department': 'Manufacturing - injection molding', 'base_salary': 2936.41, 'currency': 'EUR'}, {'person_name': 'Konsta Hiltunen', 'department': 'Quality', 'base_salary': 2815.2, 'currency': 'EUR'}, {'person_name': 'Gabriela Hoffmann', 'department': 'Quality', 'base_salary': 5145, 'currency': 'PLN'}, {'person_name': 'Jukka Hokkanen', 'department': 'Technology', 'base_salary': 8014.25, 'currency': 'EUR'}, {'person_name': 'Ann-Kathrin Holder', 'department': 'Product Management', 'base_salary': 5944.71, 'currency': 'EUR'}, {'person_name': 'Samuli Holmala', 'department': 'Technical Communication', 'base_salary': 5085.11, 'currency': 'EUR'}, {'person_name': 'Pär Holmgren', 'department': 'Sales network', 'base_salary': 53299.52, 'currency': 'SEK'}, {'person_name': 'Timo Honkapää', 'department': 'Sales network', 'base_salary': 5392.33, 'currency': 'EUR'}, {'person_name': 'Blanka Hronová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Jiří Hudousek', 'department': 'Manufacturing - assembly', 'base_salary': 21300, 'currency': 'CZK'}, {'person_name': 'Maarit Huovilainen', 'department': 'Customer service & Sales support', 'base_salary': 3118.58, 'currency': 'EUR'}, {'person_name': 'Mari Huppunen', 'department': 'Quality', 'base_salary': 2815.27, 'currency': 'EUR'}, {'person_name': 'Olli Huunonen', 'department': 'Supply chain management', 'base_salary': 3031.04, 'currency': 'EUR'}, {'person_name': 'Stefania Huć', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Ivana Hynková', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Jyrki Hynninen', 'department': 'Supply chain management', 'base_salary': 2403.83, 'currency': 'EUR'}, {'person_name': 'Johanna Hämäläinen', 'department': 'Warehouse', 'base_salary': 2688.07, 'currency': 'EUR'}, {'person_name': 'Ralf Hörtz', 'department': 'Supply chain management', 'base_salary': 10625.26, 'currency': 'CZK'}, {'person_name': 'Thomas Icking', 'department': 'Technology', 'base_salary': 5404.08, 'currency': 'EUR'}, {'person_name': 'Anne-Maj Iltanen', 'department': 'Manufacturing Technology', 'base_salary': 2836.88, 'currency': 'EUR'}, {'person_name': 'Taneli Imppu', 'department': 'Manufacturing - chrome plating', 'base_salary': 2584.84, 'currency': 'EUR'}, {'person_name': 'Soile Isokytö', 'department': 'Warehouse', 'base_salary': 2519.57, 'currency': 'EUR'}, {'person_name': 'Rafał Iwan', 'department': 'Manufacturing Technology', 'base_salary': 8150, 'currency': 'PLN'}, {'person_name': 'Krzysztof Izdebski', 'department': 'Supply chain management', 'base_salary': 4741, 'currency': 'PLN'}, {'person_name': 'Sanna Jalonen', 'department': 'Manufacturing - assembly', 'base_salary': 2364.55, 'currency': 'EUR'}, {'person_name': 'Niina Jalonen', 'department': 'Manufacturing - assembly', 'base_salary': 2516.3, 'currency': 'EUR'}, {'person_name': 'Zbyněk Janda', 'department': 'Manufacturing - assembly', 'base_salary': 21300, 'currency': 'CZK'}, {'person_name': 'Renata Jandová', 'department': 'Controlling and Finance', 'base_salary': 33967, 'currency': 'CZK'}, {'person_name': 'Joanna Janik', 'department': 'Manufacturing - assembly', 'base_salary': 4830, 'currency': 'PLN'}, {'person_name': 'Klára Janská', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Ireneusz Jaroń', 'department': 'Supply chain management', 'base_salary': 6627, 'currency': 'PLN'}, {'person_name': 'Grzegorz Jasiniak', 'department': 'Sales network', 'base_salary': 9670, 'currency': 'PLN'}, {'person_name': 'Ewelina Jasińska', 'department': 'Manufacturing - assembly', 'base_salary': 5126, 'currency': 'PLN'}, {'person_name': 'Johanna Jasu', 'department': 'Manufacturing - assembly', 'base_salary': 2378.47, 'currency': 'EUR'}, {'person_name': 'Minna Javanainen', 'department': 'Manufacturing - assembly', 'base_salary': 2337.86, 'currency': 'EUR'}, {'person_name': 'Jaana Javanainen', 'department': 'Quality', 'base_salary': 2597.26, 'currency': 'EUR'}, {'person_name': 'Mateusz Jendrzej', 'department': 'Supply chain management', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Krystian Jendrzej', 'department': 'Supply chain management', 'base_salary': 6511, 'currency': 'PLN'}, {'person_name': 'Waldemar Jendrzej', 'department': 'Supply chain management', 'base_salary': 5700, 'currency': 'PLN'}, {'person_name': 'Erik Jensen', 'department': 'Sales network', 'base_salary': 58789, 'currency': 'NOK'}, {'person_name': 'Antoni Jezela', 'department': 'Manufacturing - assembly', 'base_salary': 5292, 'currency': 'PLN'}, {'person_name': 'Patrycja Jeziorowska', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Andrzej Jeziorowski', 'department': 'Controlling and Finance', 'base_salary': 8999, 'currency': 'PLN'}, {'person_name': 'Tom Kristian Johannesen', 'department': 'Sales network', 'base_salary': 58789, 'currency': 'NOK'}, {'person_name': 'Tuija Jokela', 'department': 'Manufacturing - assembly', 'base_salary': 3101.65, 'currency': 'EUR'}, {'person_name': 'Pia Jokela', 'department': 'Manufacturing - assembly', 'base_salary': 2551.5, 'currency': 'EUR'}, {'person_name': 'Tero Jokinen', 'department': 'Project Management', 'base_salary': 5169.21, 'currency': 'EUR'}, {'person_name': 'Jussi Jokinen', 'department': 'Quality', 'base_salary': 3758.99, 'currency': 'EUR'}, {'person_name': 'Anna Jolkina', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Tiina Juhola', 'department': 'Manufacturing - assembly', 'base_salary': 2345.63, 'currency': 'EUR'}, {'person_name': 'Juha Juhola', 'department': 'Supply chain management', 'base_salary': 3406.85, 'currency': 'EUR'}, {'person_name': 'Henna Juhola', 'department': 'Manufacturing - assembly', 'base_salary': 2292.1, 'currency': 'EUR'}, {'person_name': 'Ingela Jung', 'department': 'Sales network', 'base_salary': 48710.67, 'currency': 'SEK'}, {'person_name': 'Riina Juntti', 'department': 'Manufacturing - injection molding', 'base_salary': 2368.62, 'currency': 'EUR'}, {'person_name': 'Roope Juntti', 'department': 'Manufacturing - assembly', 'base_salary': 3055.69, 'currency': 'EUR'}, {'person_name': 'Jenni Jussila', 'department': 'Logistics', 'base_salary': 3665.25, 'currency': 'EUR'}, {'person_name': 'Agnieszka Juszczak', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Sari Juutilainen', 'department': 'Manufacturing - assembly', 'base_salary': 2322.65, 'currency': 'EUR'}, {'person_name': 'Tuija Juvonen', 'department': 'Warehouse', 'base_salary': 2470.4, 'currency': 'EUR'}, {'person_name': 'Petri Järvinen', 'department': 'Warehouse', 'base_salary': 2366.87, 'currency': 'EUR'}, {'person_name': 'Petr Jícha', 'department': 'Manufacturing - assembly', 'base_salary': 51940, 'currency': 'CZK'}, {'person_name': 'Sanna Kaarno', 'department': 'Quality', 'base_salary': 2732.6, 'currency': 'EUR'}, {'person_name': 'Jitka Kabelková', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Krzysztof Kaczmarek', 'department': 'Supply chain management', 'base_salary': 5023, 'currency': 'PLN'}, {'person_name': 'Aneta Kaczmarek', 'department': 'Logistics', 'base_salary': 5733, 'currency': 'PLN'}, {'person_name': 'Tuike Kaiku', 'department': 'Manufacturing - injection molding', 'base_salary': 2517.39, 'currency': 'EUR'}, {'person_name': 'Maarit Kaitila', 'department': 'Manufacturing - chrome plating', 'base_salary': 2503.17, 'currency': 'EUR'}, {'person_name': 'Justyna Kaleja', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Wioleta Kalemba', 'department': 'Manufacturing - assembly', 'base_salary': 4830, 'currency': 'PLN'}, {'person_name': 'Reima Kallio', 'department': 'Product Management', 'base_salary': 4583.58, 'currency': 'EUR'}, {'person_name': 'Lenka Kalová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Wioletta Kandziora', 'department': 'Quality', 'base_salary': 5083, 'currency': 'PLN'}, {'person_name': 'Dawid Kandziora', 'department': 'Supply chain management', 'base_salary': 5700, 'currency': 'PLN'}, {'person_name': 'Tapani Kangas', 'department': 'Manufacturing - injection molding', 'base_salary': 3240.08, 'currency': 'EUR'}, {'person_name': 'Joel Kangas', 'department': 'Manufacturing - injection molding', 'base_salary': 2483.14, 'currency': 'EUR'}, {'person_name': 'Katarzyna Kania', 'department': 'Controlling and Finance', 'base_salary': 8844, 'currency': 'PLN'}, {'person_name': 'Piotr Kansy', 'department': 'Manufacturing - chrome plating', 'base_salary': 5378, 'currency': 'PLN'}, {'person_name': 'Tomasz Kapała', 'department': 'Supply chain management', 'base_salary': 18103, 'currency': 'PLN'}, {'person_name': 'Tuija Kares', 'department': 'Manufacturing - assembly', 'base_salary': 2424.41, 'currency': 'EUR'}, {'person_name': 'Juhani Karhula', 'department': 'Sales network', 'base_salary': 5156.17, 'currency': 'EUR'}, {'person_name': 'Paweł Karpiński', 'department': 'Manufacturing - brass', 'base_salary': 10383, 'currency': 'PLN'}, {'person_name': 'Izabela Karpusiewicz', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Iveta Karpíšková', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Klaudia Karsznia', 'department': 'Customer service & Sales support', 'base_salary': 8800, 'currency': 'PLN'}, {'person_name': 'Mari Kartano', 'department': 'Warehouse', 'base_salary': 2562.25, 'currency': 'EUR'}, {'person_name': 'Petri Karvonen', 'department': 'Quality', 'base_salary': 4893.06, 'currency': 'EUR'}, {'person_name': 'Paula Katavisto', 'department': 'Manufacturing - injection molding', 'base_salary': 2758.08, 'currency': 'EUR'}, {'person_name': 'Rene Kathe', 'department': 'Sales network', 'base_salary': 5806.51, 'currency': 'EUR'}, {'person_name': 'Raija Kauppi', 'department': 'Manufacturing - injection molding', 'base_salary': 2492.24, 'currency': 'EUR'}, {'person_name': 'Dana Kazilová', 'department': 'Customer service & Sales support', 'base_salary': 53694, 'currency': 'CZK'}, {'person_name': 'Ludmila Kašíková', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Thomas Kempf', 'department': 'Product Management', 'base_salary': 7364.6, 'currency': 'EUR'}, {'person_name': 'Emilia Ketola', 'department': 'Warehouse', 'base_salary': 3279.72, 'currency': 'EUR'}, {'person_name': 'Merja Kettunen', 'department': 'Customer service & Sales support', 'base_salary': 4463.49, 'currency': 'EUR'}, {'person_name': 'Bronisław Kiedrzyn', 'department': 'Supply chain management', 'base_salary': 6664, 'currency': 'PLN'}, {'person_name': 'Päivi Kiela', 'department': 'Quality', 'base_salary': 2833.5, 'currency': 'EUR'}, {'person_name': 'Sylwia Kiepura', 'department': 'Manufacturing - assembly', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Anastasiia Kinaci', 'department': 'Customer service & Sales support', 'base_salary': 7900, 'currency': 'PLN'}, {'person_name': 'Markus Kirvesoja', 'department': 'Sales network', 'base_salary': 4979.85, 'currency': 'EUR'}, {'person_name': 'Heidi Kivelä', 'department': 'Manufacturing - assembly', 'base_salary': 2513.78, 'currency': 'EUR'}, {'person_name': 'Arttu Kivirauma', 'department': 'Technical Communication', 'base_salary': 4570.92, 'currency': 'EUR'}, {'person_name': 'Iwona Klabis', 'department': 'Controlling and Finance', 'base_salary': 8256, 'currency': 'PLN'}, {'person_name': 'Grzegorz Klamecki', 'department': 'Supply chain management', 'base_salary': 5634, 'currency': 'PLN'}, {'person_name': 'Jana Klausová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Radoslaw Klein', 'department': 'Supply chain management', 'base_salary': 5700, 'currency': 'PLN'}, {'person_name': 'Jaroslava Kletečková', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Kordian Kluzowski', 'department': 'Supply chain management', 'base_salary': 6300, 'currency': 'PLN'}, {'person_name': 'Milena Kmiecik', 'department': 'Manufacturing - assembly', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Gregor Knerr', 'department': 'Sales network', 'base_salary': 6550.8, 'currency': 'EUR'}, {'person_name': 'Klaudiusz Kochanowski', 'department': 'Sales management', 'base_salary': 11440, 'currency': 'PLN'}, {'person_name': 'Laura-Maarit Koivisto', 'department': 'Manufacturing - assembly', 'base_salary': 2643.21, 'currency': 'EUR'}, {'person_name': 'Anne-Marie Koivuluoma', 'department': 'Manufacturing - assembly', 'base_salary': 3244.29, 'currency': 'EUR'}, {'person_name': 'Arja Koivunen', 'department': 'Supply chain management', 'base_salary': 2665.1, 'currency': 'EUR'}, {'person_name': 'Kadi Koivunen', 'department': 'Manufacturing - assembly', 'base_salary': 2613.67, 'currency': 'EUR'}, {'person_name': 'Juha Kokkonen', 'department': 'Manufacturing Technology', 'base_salary': 4478.67, 'currency': 'EUR'}, {'person_name': 'Tomasz Kokoszka', 'department': 'Supply chain management', 'base_salary': 5023, 'currency': 'PLN'}, {'person_name': 'Rumyana Koleva', 'department': 'Manufacturing - assembly', 'base_salary': 2250.9, 'currency': 'EUR'}, {'person_name': 'Gerard Koloch', 'department': 'Logistics', 'base_salary': 5500, 'currency': 'PLN'}, {'person_name': 'Tapio Komulainen', 'department': 'Product Management', 'base_salary': 5002.28, 'currency': 'EUR'}, {'person_name': 'Katarzyna Konieczna', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Marek Konieczny', 'department': 'Logistics', 'base_salary': 5176, 'currency': 'PLN'}, {'person_name': 'Arnold Kontny', 'department': 'Supply chain management', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Leevi Kontto', 'department': 'Manufacturing - assembly', 'base_salary': 2251.75, 'currency': 'EUR'}, {'person_name': 'Łukasz Kopacz', 'department': 'Supply chain management', 'base_salary': 6300, 'currency': 'PLN'}, {'person_name': 'Ari Korhonen', 'department': 'Sales network', 'base_salary': 4879.49, 'currency': 'EUR'}, {'person_name': 'Monika Korzekwa', 'department': 'Manufacturing - assembly', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Iwona Korzekwa', 'department': 'Supply chain management', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Mirosław Korzekwa', 'department': 'Supply chain management', 'base_salary': 6204, 'currency': 'PLN'}, {'person_name': 'Juho Koskinen', 'department': 'Supply chain management', 'base_salary': 2904.88, 'currency': 'EUR'}, {'person_name': 'Sari Koskinen', 'department': 'Logistics', 'base_salary': 3188.4, 'currency': 'EUR'}, {'person_name': 'Michaela Koubová', 'department': 'Process engineering', 'base_salary': 35469, 'currency': 'CZK'}, {'person_name': 'Hana Koudelová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Hanna Kovalenko', 'department': 'Manufacturing - assembly', 'base_salary': 4830, 'currency': 'PLN'}, {'person_name': 'Wioletta Kowal', 'department': 'Customer service & Sales support', 'base_salary': 8350, 'currency': 'PLN'}, {'person_name': 'Krzysztof Kowalczuk', 'department': 'Supply chain management', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Aleksandra Kowalczyk', 'department': 'Environment', 'base_salary': 8750, 'currency': 'PLN'}, {'person_name': 'Andrzej Kowalczyk', 'department': 'Supply chain management', 'base_salary': 5700, 'currency': 'PLN'}, {'person_name': 'Tomasz Kowalski', 'department': 'Supply chain management', 'base_salary': 15591, 'currency': 'PLN'}, {'person_name': 'Katarzyna Kozak', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Sabrina Kozicka', 'department': 'Sales network', 'base_salary': 12012, 'currency': 'PLN'}, {'person_name': 'Ondřej Kozler', 'department': 'Quality', 'base_salary': 37286, 'currency': 'CZK'}, {'person_name': 'Dorota Krajcer', 'department': 'Customer service & Sales support', 'base_salary': 8200, 'currency': 'PLN'}, {'person_name': 'Pekka Krappe', 'department': 'Supply chain management', 'base_salary': 3439.67, 'currency': 'EUR'}, {'person_name': 'Tomasz Kraska', 'department': 'Supply chain management', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Krzysztof Krawczyk', 'department': 'Manufacturing - assembly', 'base_salary': 5634, 'currency': 'PLN'}, {'person_name': 'Petras Krivelis', 'department': 'Sales network', 'base_salary': 4263, 'currency': 'EUR'}, {'person_name': 'Rafał Krohn', 'department': 'Supply chain management', 'base_salary': 5900, 'currency': 'PLN'}, {'person_name': 'Lucie Kronďáková', 'department': 'Manufacturing - assembly', 'base_salary': 10500, 'currency': 'CZK'}, {'person_name': 'Ewelina Krupa', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Marcelina Krupa', 'department': 'Manufacturing - assembly', 'base_salary': 4830, 'currency': 'PLN'}, {'person_name': 'Marcin Krupa', 'department': 'Supply chain management', 'base_salary': 5186, 'currency': 'PLN'}, {'person_name': 'Michał Krupicki', 'department': 'Supply chain management', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Piotr Krzemiński', 'department': 'Supply chain management', 'base_salary': 7409, 'currency': 'PLN'}, {'person_name': 'Krzysztof Krzemiński', 'department': 'Supply chain management', 'base_salary': 6664, 'currency': 'PLN'}, {'person_name': 'Beata Krzykawiak', 'department': 'Supply chain management', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Hana Králová', 'department': 'Controlling and Finance', 'base_salary': 40384, 'currency': 'CZK'}, {'person_name': 'Regina Król', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Jolanta Królewicz', 'department': 'Logistic', 'base_salary': 5200, 'currency': 'PLN'}, {'person_name': 'Beata Kubacka', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Adam Kuc', 'department': 'Supply chain management', 'base_salary': 6387, 'currency': 'PLN'}, {'person_name': 'Wojciech Kuc', 'department': 'Supply chain management', 'base_salary': 5700, 'currency': 'PLN'}, {'person_name': 'Dawid Kucharczyk', 'department': 'Supply chain management', 'base_salary': 5600, 'currency': 'PLN'}, {'person_name': 'Marek Kucharczyk', 'department': 'Supply chain management', 'base_salary': 5125, 'currency': 'PLN'}, {'person_name': 'Krzysztof Kuczkowski', 'department': 'Sales network', 'base_salary': 9169, 'currency': 'PLN'}, {'person_name': 'Maria Kuivamäki', 'department': 'Product Management', 'base_salary': 7818.13, 'currency': 'EUR'}, {'person_name': 'Jacek Kujawa', 'department': 'Customer service & Sales support', 'base_salary': 12794, 'currency': 'PLN'}, {'person_name': 'Sami Kukkaro', 'department': 'Manufacturing - injection molding', 'base_salary': 3186.95, 'currency': 'EUR'}, {'person_name': 'Marcin Kulej', 'department': 'Quality', 'base_salary': 6022, 'currency': 'PLN'}, {'person_name': 'Przemysław Kulik', 'department': 'Supply chain management', 'base_salary': 7300, 'currency': 'PLN'}, {'person_name': 'Fabian Kumberger', 'department': 'Sales management', 'base_salary': 4142, 'currency': 'EUR'}, {'person_name': 'Helmut Kumpfmüller', 'department': 'Sales management', 'base_salary': 2459.51, 'currency': 'EUR'}, {'person_name': 'Grzegorz Kuna', 'department': 'Supply chain management', 'base_salary': 6000, 'currency': 'PLN'}, {'person_name': 'Mika Kuokkanen', 'department': 'Warehouse', 'base_salary': 2522.07, 'currency': 'EUR'}, {'person_name': 'Stefan Kupczyk', 'department': 'Supply chain management', 'base_salary': 6140, 'currency': 'PLN'}, {'person_name': 'Marek Kupski', 'department': 'Supply chain management', 'base_salary': 5164, 'currency': 'PLN'}, {'person_name': 'Juha Kurka', 'department': 'Supply chain management', 'base_salary': 3205.67, 'currency': 'EUR'}, {'person_name': 'Nita Kurki', 'department': 'Purchasing', 'base_salary': 3474.2, 'currency': 'EUR'}, {'person_name': 'Pasi Kuromaa', 'department': 'Supply chain management', 'base_salary': 3214.3, 'currency': 'EUR'}, {'person_name': 'Leena Kurumaa', 'department': 'Manufacturing - chrome plating', 'base_salary': 2921.09, 'currency': 'EUR'}, {'person_name': 'Taru Kuusikorpi', 'department': 'Manufacturing - chrome plating', 'base_salary': 2520.28, 'currency': 'EUR'}, {'person_name': 'Juha Kuusio', 'department': 'Manufacturing Technology', 'base_salary': 3209.92, 'currency': 'EUR'}, {'person_name': 'Anna Kuzaj', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Lenka Kučírková', 'department': 'Manufacturing - assembly', 'base_salary': 25599, 'currency': 'CZK'}, {'person_name': 'Piotr Kuś', 'department': 'Supply chain management', 'base_salary': 5232, 'currency': 'PLN'}, {'person_name': 'Beata Kweczke', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Mirva Kykkänen', 'department': 'Quality', 'base_salary': 2626.47, 'currency': 'EUR'}, {'person_name': 'Markus Käfer', 'department': 'Product Management', 'base_salary': 5944.71, 'currency': 'EUR'}, {'person_name': 'Susanna Käri', 'department': 'Manufacturing - chrome plating', 'base_salary': 3143.87, 'currency': 'EUR'}, {'person_name': 'Karina Kępa', 'department': 'Production scheduling', 'base_salary': 4928, 'currency': 'PLN'}, {'person_name': 'Mika Laakso', 'department': 'Supply chain management', 'base_salary': 2596.17, 'currency': 'EUR'}, {'person_name': 'Teppo Laaksonen', 'department': 'Manufacturing - assembly', 'base_salary': 3263.81, 'currency': 'EUR'}, {'person_name': 'Mira Laaksonen', 'department': 'Manufacturing - assembly', 'base_salary': 2249.66, 'currency': 'EUR'}, {'person_name': 'Tommi Laaksonen', 'department': 'Warehouse', 'base_salary': 2902.38, 'currency': 'EUR'}, {'person_name': 'Miia Laanti', 'department': 'Customer service & Sales support', 'base_salary': 3214.62, 'currency': 'EUR'}, {'person_name': 'Niina Lahti', 'department': 'Manufacturing - injection molding', 'base_salary': 2659.62, 'currency': 'EUR'}, {'person_name': 'Lassi Lahti', 'department': 'Sales network', 'base_salary': 4858.04, 'currency': 'EUR'}, {'person_name': 'Jouni Laine', 'department': 'Manufacturing - chrome plating', 'base_salary': 2911.08, 'currency': 'EUR'}, {'person_name': 'Satu Laine', 'department': 'Manufacturing - assembly', 'base_salary': 2332.5, 'currency': 'EUR'}, {'person_name': 'Mika Laine', 'department': 'Manufacturing - chrome plating', 'base_salary': 3191.41, 'currency': 'EUR'}, {'person_name': 'Jyrki Laine', 'department': 'Supply chain management', 'base_salary': 2640, 'currency': 'EUR'}, {'person_name': 'Anne Laine', 'department': 'Manufacturing - assembly', 'base_salary': 2324.85, 'currency': 'EUR'}, {'person_name': 'Heli Laine', 'department': 'Warehouse', 'base_salary': 2633.63, 'currency': 'EUR'}, {'person_name': 'Jani Laine', 'department': 'Manufacturing - chrome plating', 'base_salary': 2911.08, 'currency': 'EUR'}, {'person_name': 'Mira Lainio', 'department': 'Manufacturing - assembly', 'base_salary': 2698.94, 'currency': 'EUR'}, {'person_name': 'Riitta Laito', 'department': 'Manufacturing - chrome plating', 'base_salary': 2926.57, 'currency': 'EUR'}, {'person_name': 'Juha Laksi', 'department': 'Supply chain management', 'base_salary': 3143.19, 'currency': 'EUR'}, {'person_name': 'Jyri Lamminen', 'department': 'Manufacturing - assembly', 'base_salary': 2921.09, 'currency': 'EUR'}, {'person_name': 'Marjo Lastikka', 'department': 'Manufacturing - assembly', 'base_salary': 2269.05, 'currency': 'EUR'}, {'person_name': 'Karri Lattu', 'department': 'Manufacturing - injection molding', 'base_salary': 2905.79, 'currency': 'EUR'}, {'person_name': 'Pavla Lavičková', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Odysseus Lazos', 'department': 'Marketing', 'base_salary': 4919.01, 'currency': 'EUR'}, {'person_name': 'Jacek Lech', 'department': 'Manufacturing - brass', 'base_salary': 9223, 'currency': 'PLN'}, {'person_name': 'Jenni Lehtinen', 'department': 'Controlling and Finance', 'base_salary': 3577.3, 'currency': 'EUR'}, {'person_name': 'Vuokko Lehtinen', 'department': 'Manufacturing - assembly', 'base_salary': '', 'currency': 'EUR'}, {'person_name': 'Raija Lehtinen', 'department': 'Manufacturing - assembly', 'base_salary': 2429.17, 'currency': 'EUR'}, {'person_name': 'Jere Lehtinen', 'department': 'Manufacturing - chrome plating', 'base_salary': 2440.78, 'currency': 'EUR'}, {'person_name': 'Heli Lehtiniemi', 'department': 'Manufacturing - assembly', 'base_salary': 2393.77, 'currency': 'EUR'}, {'person_name': 'Minna Lehtola', 'department': 'Manufacturing - injection molding', 'base_salary': 2379.55, 'currency': 'EUR'}, {'person_name': 'Päivi Lehtonen', 'department': 'Manufacturing - injection molding', 'base_salary': 2949.82, 'currency': 'EUR'}, {'person_name': 'Kirsi-Marja Lehtonen', 'department': 'Manufacturing - assembly', 'base_salary': 2880.07, 'currency': 'EUR'}, {'person_name': 'Jani Leino', 'department': 'Warehouse', 'base_salary': 2532.71, 'currency': 'EUR'}, {'person_name': 'Kristiina Leivo', 'department': 'Purchasing', 'base_salary': 4782.51, 'currency': 'EUR'}, {'person_name': 'Juhani Lempinen', 'department': 'Digital Services', 'base_salary': 8578.05, 'currency': 'EUR'}, {'person_name': 'Jean-Pierre Levert', 'department': 'Sales network', 'base_salary': 5388.79, 'currency': 'EUR'}, {'person_name': 'Veronika Levá', 'department': 'Supply Chain development', 'base_salary': 38259, 'currency': 'CZK'}, {'person_name': 'Edyta Lewandowska', 'department': 'Controlling and Finance', 'base_salary': 10400, 'currency': 'PLN'}, {'person_name': 'Paweł Lewandowski', 'department': 'Technical Communication', 'base_salary': 6617, 'currency': 'PLN'}, {'person_name': 'Marcin Leś', 'department': 'Supply Chain development', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Agnieszka Liberka', 'department': 'Logistics', 'base_salary': 8350, 'currency': 'PLN'}, {'person_name': 'Sybilla Lichtfeld', 'department': 'Supply Chain development', 'base_salary': 4300, 'currency': 'PLN'}, {'person_name': 'Tarja Lindvall', 'department': 'Supply Chain development', 'base_salary': 2788.72, 'currency': 'EUR'}, {'person_name': 'Gabriela Liwowska', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Beata Lizurej', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Ebe Loorits', 'department': 'Sales network', 'base_salary': 2654, 'currency': 'EUR'}, {'person_name': 'Joanna Lotz', 'department': 'Controlling and Finance', 'base_salary': 6350, 'currency': 'PLN'}, {'person_name': 'Alex Loutti', 'department': 'Manufacturing - injection molding', 'base_salary': 2545.84, 'currency': 'EUR'}, {'person_name': 'Ivana Lukáčová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Tomasz Lupa', 'department': 'Supply Chain development', 'base_salary': 5700, 'currency': 'PLN'}, {'person_name': 'Seija Luukkonen', 'department': 'Customer service & Sales support', 'base_salary': 3113.58, 'currency': 'EUR'}, {'person_name': 'Mathias Lösle', 'department': 'Product Management', 'base_salary': 5944.71, 'currency': 'EUR'}, {'person_name': 'Ewa Madalska', 'department': 'Customer service & Sales support', 'base_salary': 10511, 'currency': 'PLN'}, {'person_name': 'Teppo Maihikoski', 'department': 'Safety', 'base_salary': 3355.42, 'currency': 'EUR'}, {'person_name': 'Janne Maijala', 'department': 'Product Management', 'base_salary': 5187.41, 'currency': 'EUR'}, {'person_name': 'Jaana Maikola', 'department': 'Manufacturing - chrome plating', 'base_salary': 2452.85, 'currency': 'EUR'}, {'person_name': 'Sari Maikola', 'department': 'Warehouse', 'base_salary': 2536, 'currency': 'EUR'}, {'person_name': 'Jenni Maikola', 'department': 'Customer service & Sales support', 'base_salary': 3322.83, 'currency': 'EUR'}, {'person_name': 'Petri Maikola', 'department': 'Manufacturing Technology', 'base_salary': 4338.59, 'currency': ''}, {'person_name': 'Grzegorz Majchrzyk', 'department': 'Sales network', 'base_salary': 10982, 'currency': 'PLN'}, {'person_name': 'Oksana Makar', 'department': 'Customer service & Sales support', 'base_salary': 9256, 'currency': 'PLN'}, {'person_name': 'Joanna Makles', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Maciej Makles', 'department': 'Supply chain management', 'base_salary': 6800, 'currency': 'PLN'}, {'person_name': 'Stanislava Malcová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Dita Malichová', 'department': 'Supply Chain development', 'base_salary': 43006, 'currency': 'CZK'}, {'person_name': 'Johanna Malmsten', 'department': 'Technical Communication', 'base_salary': 3130.92, 'currency': 'EUR'}, {'person_name': 'Mika Malo', 'department': 'Technical Communication', 'base_salary': 6616.54, 'currency': 'EUR'}, {'person_name': 'Alina Maniak', 'department': 'Controlling and Finance', 'base_salary': 15080, 'currency': 'PLN'}, {'person_name': 'Milena Mann', 'department': 'Manufacturing - assembly', 'base_salary': 4909, 'currency': 'PLN'}, {'person_name': 'Szymon Mann', 'department': 'IT', 'base_salary': 6650, 'currency': 'PLN'}, {'person_name': 'Piotr Marchewka', 'department': 'Logistics', 'base_salary': 5400, 'currency': 'PLN'}, {'person_name': 'Marek Marchewka', 'department': 'Supply Chain development', 'base_salary': 6664, 'currency': 'PLN'}, {'person_name': 'Vasile Marchis', 'department': 'Manufacturing - chrome plating', 'base_salary': 2705.57, 'currency': 'EUR'}, {'person_name': 'Katja Marttila', 'department': 'Manufacturing - assembly', 'base_salary': 2202.3, 'currency': 'EUR'}, {'person_name': 'Antonio Masullo', 'department': 'Sales management', 'base_salary': 4919.01, 'currency': 'EUR'}, {'person_name': 'Monika Matulová', 'department': 'Quality', 'base_salary': 31720, 'currency': 'CZK'}, {'person_name': 'Bartłomiej Matuszczyk', 'department': 'Supply Chain development', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Anna Maślankowska', 'department': 'Customer service & Sales support', 'base_salary': 7900, 'currency': 'PLN'}, {'person_name': 'Andrzej Mendel', 'department': 'Supply Chain development', 'base_salary': 5209, 'currency': 'PLN'}, {'person_name': 'Mirva Meriluoto', 'department': 'Quality', 'base_salary': 2764.67, 'currency': 'EUR'}, {'person_name': 'Taina Merimaa', 'department': 'Production scheduling', 'base_salary': 3326.42, 'currency': 'EUR'}, {'person_name': 'Kirsi Merimaa-Laaksonen', 'department': 'Manufacturing - assembly', 'base_salary': 2584.29, 'currency': 'EUR'}, {'person_name': 'Marko Metsänvirta', 'department': 'Warehouse', 'base_salary': 2564.43, 'currency': 'EUR'}, {'person_name': 'Barbara Michalczyk', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Katarzyna Mierzwiak', 'department': 'Controlling and Finance', 'base_salary': 33352, 'currency': 'PLN'}, {'person_name': 'Ireneusz Misiak', 'department': 'Manufacturing Technology', 'base_salary': 24736, 'currency': 'PLN'}, {'person_name': 'Hanne Moell', 'department': 'Customer service & Sales support', 'base_salary': 39843.82, 'currency': 'DKK'}, {'person_name': 'Oliver Moosmann', 'department': 'Sales management', 'base_salary': 4219.63, 'currency': 'EUR'}, {'person_name': 'Václav Mour', 'department': 'Logistic', 'base_salary': 18700, 'currency': 'CZK'}, {'person_name': 'Michal Mrazko', 'department': 'Sales network', 'base_salary': 2379, 'currency': 'CZK'}, {'person_name': 'Sari Mäenpää', 'department': 'Supply Chain development', 'base_salary': 2403.83, 'currency': 'EUR'}, {'person_name': 'Olli Mäkilä', 'department': 'Logistics', 'base_salary': 5392.95, 'currency': 'EUR'}, {'person_name': 'Markus Mäkinen', 'department': 'Manufacturing - assembly', 'base_salary': 3350.37, 'currency': 'EUR'}, {'person_name': 'Juhani Mäkinen', 'department': 'Manufacturing - assembly', 'base_salary': 2190.27, 'currency': 'EUR'}, {'person_name': 'Jenna Mäkipää', 'department': 'Manufacturing - assembly', 'base_salary': 2247.68, 'currency': 'EUR'}, {'person_name': 'Kätlin Müürsepp', 'department': 'Manufacturing - assembly', 'base_salary': 2348.91, 'currency': 'EUR'}, {'person_name': 'Grzegorz Młynarczyk', 'department': 'Manufacturing - chrome plating', 'base_salary': 4643, 'currency': 'PLN'}, {'person_name': 'Justyna Młyńczyk', 'department': 'Manufacturing - chrome plating', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Tomasz Nalichowski', 'department': 'Supply Chain development', 'base_salary': 6001, 'currency': 'PLN'}, {'person_name': 'Frank Neubert', 'department': 'Marketing', 'base_salary': 5045.14, 'currency': 'EUR'}, {'person_name': 'Elżbieta Neumann', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Joachim Neumann', 'department': 'Supply Chain development', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Markus Niemi', 'department': 'Sales network', 'base_salary': 5050.39, 'currency': 'EUR'}, {'person_name': 'Liisa Niemi', 'department': 'Production scheduling', 'base_salary': 3796.65, 'currency': 'EUR'}, {'person_name': 'Katja Nieminen', 'department': 'Production scheduling', 'base_salary': 3761.9, 'currency': 'EUR'}, {'person_name': 'Jussi Nieminen', 'department': 'Manufacturing - assembly', 'base_salary': 2292.02, 'currency': 'EUR'}, {'person_name': 'Jan-Erik Nieminen', 'department': 'Manufacturing Technology', 'base_salary': 3065.59, 'currency': 'EUR'}, {'person_name': 'Janne Nieminen', 'department': 'Supply chain management', 'base_salary': 5173.38, 'currency': 'EUR'}, {'person_name': 'Olli-Pekka Nieminen', 'department': 'Product Management', 'base_salary': 7792.34, 'currency': 'EUR'}, {'person_name': 'Patrycja Niesłony', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Ryszard Nikel', 'department': 'Supply Chain development', 'base_salary': 5120, 'currency': 'PLN'}, {'person_name': 'Miloš Niklas', 'department': 'Logistic', 'base_salary': 18700, 'currency': 'CZK'}, {'person_name': 'Renata Noga', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Titta Nordberg', 'department': 'Safety', 'base_salary': 3642.5, 'currency': 'EUR'}, {'person_name': 'Ingrid Nordling', 'department': 'Manufacturing - assembly', 'base_salary': 2253.73, 'currency': 'EUR'}, {'person_name': 'Sauli Nordqvist', 'department': 'Manufacturing Technology', 'base_salary': 3078.64, 'currency': 'EUR'}, {'person_name': 'Mickael Norrby', 'department': 'Sales network', 'base_salary': 50584.36, 'currency': 'SEK'}, {'person_name': 'Marta Novotná', 'department': 'Manufacturing - assembly', 'base_salary': 11000, 'currency': 'CZK'}, {'person_name': 'Marcin Nowak', 'department': 'Supply Chain development', 'base_salary': 7300, 'currency': 'PLN'}, {'person_name': 'Nikola Nowak', 'department': 'Supply Chain development', 'base_salary': 4554, 'currency': 'PLN'}, {'person_name': 'Małgorzata Nowak', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Czesława Nowak', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Krzysztof Nowak', 'department': 'Manufacturing Technology', 'base_salary': 10080, 'currency': 'PLN'}, {'person_name': 'Mitja Nurmi', 'department': 'Manufacturing - injection molding', 'base_salary': 2962.08, 'currency': 'EUR'}, {'person_name': 'Ville Nurminen', 'department': 'Purchasing', 'base_salary': 4212.47, 'currency': 'EUR'}, {'person_name': 'Piia Nylund', 'department': 'Manufacturing - chrome plating', 'base_salary': 2717.61, 'currency': 'EUR'}, {'person_name': 'Esa Nyman', 'department': 'Sales network', 'base_salary': 48739.28, 'currency': 'SEK'}, {'person_name': 'Aneta Obłąk', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Agnieszka Ochmann', 'department': 'Manufacturing - assembly', 'base_salary': 4830, 'currency': 'PLN'}, {'person_name': 'Edyta Ochmann', 'department': 'Supply Chain development', 'base_salary': 4554, 'currency': 'PLN'}, {'person_name': 'Outi Ojatalo', 'department': 'Manufacturing - assembly', 'base_salary': 2259.08, 'currency': 'EUR'}, {'person_name': 'Tron Olerud', 'department': 'Sales network', 'base_salary': 58692, 'currency': 'NOK'}, {'person_name': 'Michał Oleś', 'department': 'Purchasing', 'base_salary': 8855, 'currency': 'PLN'}, {'person_name': 'Hana Oliveriusová', 'department': 'Controlling and Finance', 'base_salary': 53818, 'currency': 'CZK'}, {'person_name': 'Paweł Olszewski', 'department': 'Supply Chain development', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Kamil Olszewski', 'department': 'Production scheduling', 'base_salary': 7921, 'currency': 'PLN'}, {'person_name': 'Josef Oláh', 'department': 'Manufacturing - assembly', 'base_salary': 21300, 'currency': 'CZK'}, {'person_name': 'Jolanta Orzeszyna', 'department': 'Supply Chain development', 'base_salary': 4670, 'currency': 'PLN'}, {'person_name': 'Agata Osumek', 'department': 'Manufacturing - chrome plating', 'base_salary': 2573, 'currency': 'EUR'}, {'person_name': 'Katarzyna Ośródka', 'department': 'Quality', 'base_salary': 5290, 'currency': 'PLN'}, {'person_name': 'Päivi Paajanen', 'department': 'Warehouse', 'base_salary': 2783.24, 'currency': 'EUR'}, {'person_name': 'Minna Paasio', 'department': 'IT', 'base_salary': 3902.56, 'currency': 'EUR'}, {'person_name': 'Juha Paavilainen', 'department': 'Manufacturing Technology', 'base_salary': 3104.2, 'currency': 'EUR'}, {'person_name': 'Artur Pakuła', 'department': 'Supply Chain development', 'base_salary': 6300, 'currency': 'PLN'}, {'person_name': 'Honorata Pakuła', 'department': 'Manufacturing - assembly', 'base_salary': 5700, 'currency': 'PLN'}, {'person_name': 'Andrzej Palmąka', 'department': 'Manufacturing Technology', 'base_salary': 17472, 'currency': 'PLN'}, {'person_name': 'Artur Paluch', 'department': 'Manufacturing - chrome plating', 'base_salary': 5437, 'currency': 'PLN'}, {'person_name': 'Piotr Pankosz', 'department': 'Logistics', 'base_salary': 8831, 'currency': 'PLN'}, {'person_name': 'Marcin Pawelec', 'department': 'Logistics', 'base_salary': 5400, 'currency': 'PLN'}, {'person_name': 'Mariusz Pawełczyk', 'department': 'Quality', 'base_salary': 7498, 'currency': 'PLN'}, {'person_name': 'Jarosław Pawlica', 'department': 'Supply Chain development', 'base_salary': 6596, 'currency': 'PLN'}, {'person_name': 'Katarzyna Pecela', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Wojciech Pecela', 'department': 'Supply Chain development', 'base_salary': 6664, 'currency': 'PLN'}, {'person_name': 'Michal Pech', 'department': 'Quality', 'base_salary': 87344, 'currency': 'CZK'}, {'person_name': 'Marek Pecka', 'department': 'Logistic', 'base_salary': 18700, 'currency': 'CZK'}, {'person_name': 'Lidia Pelka', 'department': 'Supply Chain development', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Riku Peltomaa', 'department': 'Warehouse', 'base_salary': 2339.88, 'currency': 'EUR'}, {'person_name': 'Janne Pentikäinen', 'department': 'Sales management', 'base_salary': 3531.98, 'currency': 'EUR'}, {'person_name': 'Roni Pietilä', 'department': 'Warehouse', 'base_salary': 2793.64, 'currency': 'EUR'}, {'person_name': 'Anita Pietrucha', 'department': 'Logistics', 'base_salary': 5518, 'currency': 'PLN'}, {'person_name': 'Jaana Piiroinen', 'department': 'Warehouse', 'base_salary': 2735.11, 'currency': 'EUR'}, {'person_name': 'Dawid Pilak', 'department': 'Supply Chain development', 'base_salary': 4300, 'currency': 'PLN'}, {'person_name': 'Anna Pilarska', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Agnieszka Pilarz', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Marcin Pilśniak', 'department': 'Process engineering', 'base_salary': 9202, 'currency': 'PLN'}, {'person_name': 'Minna Pirttilahti', 'department': 'Manufacturing - chrome plating', 'base_salary': 2612.58, 'currency': 'EUR'}, {'person_name': 'Sławomir Piśniak', 'department': 'Supply Chain development', 'base_salary': 5297, 'currency': 'PLN'}, {'person_name': 'Kamil Podstawa', 'department': 'Supply Chain development', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Tadeusz Podusowski', 'department': 'Supply Chain development', 'base_salary': 6664, 'currency': 'PLN'}, {'person_name': 'Jacek Popczyk', 'department': 'Supply Chain development', 'base_salary': 6627, 'currency': 'PLN'}, {'person_name': 'Jarkko Poskiparta', 'department': 'Manufacturing Technology', 'base_salary': 4261.78, 'currency': 'EUR'}, {'person_name': 'Kamil Pownuk', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Klára Procházková', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Zbigniew Psik', 'department': 'Supply Chain development', 'base_salary': 6832, 'currency': 'PLN'}, {'person_name': 'Rafał Psiuch', 'department': 'Project Management', 'base_salary': 17680, 'currency': 'PLN'}, {'person_name': 'Monika Pszczołowska', 'department': 'Customer service & Sales support', 'base_salary': 13520, 'currency': 'PLN'}, {'person_name': 'Dominik Ptok', 'department': 'Supply Chain development', 'base_salary': 5145, 'currency': 'PLN'}, {'person_name': 'Waldemar Ptok', 'department': 'Supply Chain development', 'base_salary': 6664, 'currency': 'PLN'}, {'person_name': 'Heli Puputti', 'department': 'Quality', 'base_salary': 2847.43, 'currency': 'EUR'}, {'person_name': 'Arkadiusz Pyzalski', 'department': 'Supply Chain development', 'base_salary': 5118, 'currency': 'PLN'}, {'person_name': 'Małgorzata Rabińska', 'department': 'Manufacturing - assembly', 'base_salary': 5135, 'currency': 'PLN'}, {'person_name': 'Elżbieta Raczyńska', 'department': 'Controlling and Finance', 'base_salary': 12480, 'currency': 'PLN'}, {'person_name': 'Lukáš Rada', 'department': 'Logistic', 'base_salary': 18700, 'currency': 'CZK'}, {'person_name': 'Goran Radman', 'department': 'Sales management', 'base_salary': 4346, 'currency': 'EUR'}, {'person_name': 'Grzegorz Radzioch', 'department': 'Manufacturing Technology', 'base_salary': 10432, 'currency': 'PLN'}, {'person_name': 'Essi Rajalin', 'department': 'Manufacturing - chrome plating', 'base_salary': 2265.45, 'currency': 'EUR'}, {'person_name': 'Piotr Rak', 'department': 'Supply Chain development', 'base_salary': 4925, 'currency': 'PLN'}, {'person_name': 'Tomáš Rambousek', 'department': 'Manufacturing - assembly', 'base_salary': 51940, 'currency': 'CZK'}, {'person_name': 'Marena Ranne', 'department': 'Warehouse', 'base_salary': 2228.59, 'currency': 'EUR'}, {'person_name': 'Kati Rannikko', 'department': 'Supply chain management', 'base_salary': 2729.54, 'currency': 'EUR'}, {'person_name': 'Toni Rantala', 'department': 'Warehouse', 'base_salary': 2168.65, 'currency': 'EUR'}, {'person_name': 'Kirsi Rantanen', 'department': 'Manufacturing - assembly', 'base_salary': 2532.71, 'currency': 'EUR'}, {'person_name': 'Matleena Rantanen', 'department': 'Controlling and Finance', 'base_salary': 4409, 'currency': 'EUR'}, {'person_name': 'Tiina Rantanen', 'department': 'Controlling and Finance', 'base_salary': 3338.61, 'currency': 'EUR'}, {'person_name': 'Jaana Rantanen', 'department': 'Quality', 'base_salary': 2664.55, 'currency': 'EUR'}, {'person_name': 'Marko Raski', 'department': 'Quality', 'base_salary': 5238.44, 'currency': 'EUR'}, {'person_name': 'Katarzyna Rataj', 'department': 'Supply Chain development', 'base_salary': 4672, 'currency': 'PLN'}, {'person_name': 'Sanna Rauhala', 'department': 'Product Management', 'base_salary': 3480, 'currency': 'EUR'}, {'person_name': 'Timo Rauhala', 'department': 'Quality', 'base_salary': 3296.35, 'currency': 'EUR'}, {'person_name': 'Niko Rautiainen', 'department': 'Quality', 'base_salary': 2590.28, 'currency': 'EUR'}, {'person_name': 'Tuomas Ravantti', 'department': 'Manufacturing Technology', 'base_salary': 4061.07, 'currency': ''}, {'person_name': 'Achim Redlich', 'department': 'Sales network', 'base_salary': 5317.86, 'currency': 'EUR'}, {'person_name': 'Sławomir Rembielak', 'department': 'Supply Chain development', 'base_salary': 5634, 'currency': 'PLN'}, {'person_name': 'Gaëtan Renier', 'department': 'Sales network', 'base_salary': 6719.35, 'currency': 'EUR'}, {'person_name': 'Minna-Riitta Reponen', 'department': 'Manufacturing - assembly', 'base_salary': 2647.58, 'currency': 'EUR'}, {'person_name': 'Betina Respondek', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Klaus Rettkowski', 'department': 'Project Management', 'base_salary': 4022.8, 'currency': 'EUR'}, {'person_name': 'Katja Rinne', 'department': 'Manufacturing - assembly', 'base_salary': 3270.68, 'currency': 'EUR'}, {'person_name': 'Veli Rinne', 'department': 'Product Management', 'base_salary': 5183.44, 'currency': 'EUR'}, {'person_name': 'Kalle Rintanen', 'department': 'Technology', 'base_salary': 5175.39, 'currency': 'EUR'}, {'person_name': 'Jarkko Ristilä', 'department': 'Manufacturing - injection molding', 'base_salary': 2517.39, 'currency': 'EUR'}, {'person_name': 'Isak Ritakallio', 'department': 'Manufacturing - injection molding', 'base_salary': 2523.29, 'currency': 'EUR'}, {'person_name': 'Mateusz Robok', 'department': 'Supply Chain development', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Jacek Robok', 'department': 'Supply Chain development', 'base_salary': 6238, 'currency': 'PLN'}, {'person_name': 'Miluše Rohrová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Jarkko Roitto', 'department': 'Manufacturing Technology', 'base_salary': 4182, 'currency': ''}, {'person_name': 'Jeroen Roobaert', 'department': 'Customer service & Sales support', 'base_salary': 4317.19, 'currency': 'EUR'}, {'person_name': 'Radosław Rosak', 'department': 'Supply Chain development', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Marcin Rosak', 'department': 'Supply Chain development', 'base_salary': 5145, 'currency': 'PLN'}, {'person_name': 'Tiia Roslöf', 'department': 'Manufacturing - assembly', 'base_salary': 2566.63, 'currency': 'EUR'}, {'person_name': 'Teea Roslöf', 'department': 'Manufacturing - assembly', 'base_salary': 2337.97, 'currency': 'EUR'}, {'person_name': 'Anita Rostedt', 'department': 'Manufacturing - assembly', 'base_salary': 2414.55, 'currency': 'EUR'}, {'person_name': 'Nick Roth', 'department': 'Sales management', 'base_salary': 4919.01, 'currency': 'EUR'}, {'person_name': 'Timo Rouhio', 'department': 'Manufacturing Technology', 'base_salary': 4629.72, 'currency': ''}, {'person_name': 'Pavel Roškot', 'department': 'Sales network', 'base_salary': 80289, 'currency': 'CZK'}, {'person_name': 'Sławomir Rudnik', 'department': 'Supply Chain development', 'base_salary': 6523, 'currency': 'PLN'}, {'person_name': 'Maarit Susanna Ruohola', 'department': 'Manufacturing - assembly', 'base_salary': 2433.45, 'currency': 'EUR'}, {'person_name': 'Maarit Ruohola', 'department': 'Supply chain management', 'base_salary': 4720.89, 'currency': 'EUR'}, {'person_name': 'Birgitta Ruohonen', 'department': 'Manufacturing - chrome plating', 'base_salary': 2668.42, 'currency': 'EUR'}, {'person_name': 'Noora Ruuskanen', 'department': 'Customer service & Sales support', 'base_salary': 3342.9, 'currency': 'EUR'}, {'person_name': 'Łukasz Rużyło', 'department': 'Customer service & Sales support', 'base_salary': 9646, 'currency': 'PLN'}, {'person_name': 'Agnieszka Rygulska-Kmieć', 'department': 'Sales network', 'base_salary': 16224, 'currency': 'PLN'}, {'person_name': 'Ewa Rymarczyk', 'department': 'Environment', 'base_salary': 10400, 'currency': 'PLN'}, {'person_name': 'Łukasz Ryng', 'department': 'Manufacturing Technology', 'base_salary': 9381, 'currency': 'PLN'}, {'person_name': 'Mirja Rytinki', 'department': 'Manufacturing - chrome plating', 'base_salary': 3255.84, 'currency': 'EUR'}, {'person_name': 'Niina Rytinki', 'department': 'Manufacturing - chrome plating', 'base_salary': 2290.87, 'currency': 'EUR'}, {'person_name': 'Niina Ränkman', 'department': 'Supply chain management', 'base_salary': 5545.78, 'currency': 'EUR'}, {'person_name': 'Mateusz Ręg', 'department': 'Logistics', 'base_salary': 6571, 'currency': 'PLN'}, {'person_name': 'Heidi Saari', 'department': 'Purchasing', 'base_salary': 4195.43, 'currency': 'EUR'}, {'person_name': 'Ilkka Saarinen', 'department': 'Manufacturing Technology', 'base_salary': 4561.03, 'currency': 'EUR'}, {'person_name': 'Tommi Saarinen', 'department': 'Warehouse', 'base_salary': 2542.27, 'currency': 'EUR'}, {'person_name': 'Timo Saartomaa', 'department': 'Warehouse', 'base_salary': 2574.86, 'currency': 'EUR'}, {'person_name': 'Samuel Sabatowicz', 'department': 'Export', 'base_salary': 8960, 'currency': 'PLN'}, {'person_name': 'Anniki Sagar', 'department': 'Manufacturing - assembly', 'base_salary': 2344.85, 'currency': 'EUR'}, {'person_name': 'Riitta Salmi', 'department': 'Manufacturing - assembly', 'base_salary': 2298.59, 'currency': 'EUR'}, {'person_name': 'Tapio Salminen', 'department': 'Product Management', 'base_salary': 4044.07, 'currency': 'EUR'}, {'person_name': 'Taina Salo', 'department': 'Manufacturing - assembly', 'base_salary': 2319.38, 'currency': 'EUR'}, {'person_name': 'Tatjaana Salomaa', 'department': 'Manufacturing - assembly', 'base_salary': 2787.62, 'currency': 'EUR'}, {'person_name': 'Katja Salomaa', 'department': 'Manufacturing - assembly', 'base_salary': 2300.77, 'currency': 'EUR'}, {'person_name': 'Riitta Salonen', 'department': 'Manufacturing - assembly', 'base_salary': 2662.11, 'currency': 'EUR'}, {'person_name': 'Mauri Salovaara', 'department': 'Manufacturing Technology  ', 'base_salary': 4001.15, 'currency': ''}, {'person_name': 'Anders Sandstig', 'department': 'Sales network', 'base_salary': 57329.31, 'currency': 'SEK'}, {'person_name': 'Heidi Santanen', 'department': 'Quality', 'base_salary': 2821.53, 'currency': 'EUR'}, {'person_name': 'Manne Santonen', 'department': 'Technology', 'base_salary': 3323.09, 'currency': 'EUR'}, {'person_name': 'Mantas Sapalas', 'department': 'Sales network', 'base_salary': 7830, 'currency': 'EUR'}, {'person_name': 'Pirkko Sario', 'department': 'Manufacturing - assembly', 'base_salary': 2543.65, 'currency': 'EUR'}, {'person_name': 'Stanisław Sas', 'department': 'Supply Chain development', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Pasi Savila', 'department': 'Manufacturing Technology', 'base_salary': 3518.77, 'currency': 'EUR'}, {'person_name': 'Mariola Schepper', 'department': 'Quality', 'base_salary': 5469, 'currency': 'PLN'}, {'person_name': 'Waldemar Schepper', 'department': 'Supply Chain development', 'base_salary': 6664, 'currency': 'PLN'}, {'person_name': 'Friedrich Schindlauer', 'department': 'Sales management', 'base_salary': 4588, 'currency': 'EUR'}, {'person_name': 'Jens Schrader', 'department': 'Product Management', 'base_salary': 3658.29, 'currency': 'EUR'}, {'person_name': 'Reiner Schumacher', 'department': 'Controlling and Finance', 'base_salary': 6097.14, 'currency': 'EUR'}, {'person_name': 'Gabriela Schwendtner', 'department': 'Sales management', 'base_salary': 3409, 'currency': 'EUR'}, {'person_name': 'Giuliana Sciuto', 'department': 'Customer service & Sales support', 'base_salary': 2285.13, 'currency': 'EUR'}, {'person_name': 'Mika Seidel', 'department': 'Sales network', 'base_salary': 4947.43, 'currency': 'EUR'}, {'person_name': 'Antti Seppälä', 'department': 'IT', 'base_salary': 3898.04, 'currency': 'EUR'}, {'person_name': 'Fiorangela Sguotti', 'department': 'Sales network', 'base_salary': 3772.49, 'currency': 'EUR'}, {'person_name': 'Julian Siegmund', 'department': 'Purchasing', 'base_salary': 5746.86, 'currency': 'EUR'}, {'person_name': 'Viktor Sihvonen', 'department': 'Manufacturing - chrome plating', 'base_salary': 2704.03, 'currency': 'EUR'}, {'person_name': 'Eveliina Siivonen', 'department': 'Manufacturing - chrome plating', 'base_salary': 2930.98, 'currency': 'EUR'}, {'person_name': 'Paweł Sikora', 'department': 'Supply chain management', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Sylwia Sikora', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Saija Siren', 'department': 'Supply chain management', 'base_salary': 3105.26, 'currency': 'EUR'}, {'person_name': 'Alex Six', 'department': 'Sales network', 'base_salary': 5395.68, 'currency': 'EUR'}, {'person_name': 'Jörgen Sjölander', 'department': 'Sales management', 'base_salary': 49877.51, 'currency': 'SEK'}, {'person_name': 'Jaroslava Sklenářová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Ilona Skowronek', 'department': 'Logistics', 'base_salary': 6520, 'currency': 'PLN'}, {'person_name': 'Wiktor Skraba', 'department': 'Supply chain management', 'base_salary': 5712, 'currency': 'PLN'}, {'person_name': 'Agnieszka Skraba-Rusek', 'department': 'Safety', 'base_salary': 9712, 'currency': 'PLN'}, {'person_name': 'Damian Skrzydło', 'department': 'Supply Chain development', 'base_salary': 6600, 'currency': 'PLN'}, {'person_name': 'Daniel Skwara', 'department': 'Supply chain management', 'base_salary': 6171, 'currency': 'PLN'}, {'person_name': 'Zdeněk Sládek', 'department': 'Logistic', 'base_salary': 18700, 'currency': 'CZK'}, {'person_name': 'Patryk Smaga', 'department': 'Supply chain management', 'base_salary': 6426, 'currency': 'PLN'}, {'person_name': 'Aleksandra Smyrek', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Magdalena Sneka', 'department': 'Quality', 'base_salary': 7998, 'currency': 'PLN'}, {'person_name': 'Wojciech Sneka', 'department': 'Process engineering', 'base_salary': 8820, 'currency': 'PLN'}, {'person_name': 'Bartosz Snoch', 'department': 'Marketing', 'base_salary': 15600, 'currency': 'PLN'}, {'person_name': 'Tomasz Sobczak', 'department': 'Controlling and Finance', 'base_salary': 10000, 'currency': 'PLN'}, {'person_name': 'Rafał Sojka', 'department': 'Supply chain management', 'base_salary': 8600, 'currency': 'PLN'}, {'person_name': 'Veronika Soukupová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Magdalena Sowa', 'department': 'Manufacturing - assembly', 'base_salary': 4830, 'currency': 'PLN'}, {'person_name': 'Żaneta Sowa', 'department': 'Controlling and Finance', 'base_salary': 5032, 'currency': 'PLN'}, {'person_name': 'Martina Springer', 'department': 'Product Management', 'base_salary': 2698, 'currency': 'EUR'}, {'person_name': 'Christoph Stangel', 'department': 'Supply Chain development', 'base_salary': 6097.14, 'currency': 'EUR'}, {'person_name': 'Agnieszka Staniec', 'department': 'Customer service & Sales support', 'base_salary': 5616, 'currency': 'PLN'}, {'person_name': 'Heli Starck', 'department': 'Manufacturing - injection molding', 'base_salary': 2821.54, 'currency': 'EUR'}, {'person_name': 'Magda Starczewska', 'department': 'Controlling and Finance', 'base_salary': 9200, 'currency': 'PLN'}, {'person_name': 'Martyna Stasiak', 'department': 'Manufacturing - assembly', 'base_salary': 4830, 'currency': 'PLN'}, {'person_name': 'Iva Staňková', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Adrian Stefanowicz', 'department': 'Supply chain management', 'base_salary': 6300, 'currency': 'PLN'}, {'person_name': 'Ulrich Streib', 'department': 'Product Management', 'base_salary': 5335, 'currency': 'EUR'}, {'person_name': 'Piotr Strugała', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Wiktoria Strzelcok', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Roksana Strzelcok', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Krzysztof Strózik', 'department': 'Supply chain management', 'base_salary': 8009, 'currency': 'PLN'}, {'person_name': 'Aneta Styczyrz', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Jindřich Střelec', 'department': 'Supply chain management', 'base_salary': 44488, 'currency': 'CZK'}, {'person_name': 'Sari Sulin', 'department': 'Manufacturing Technology', 'base_salary': 4363.92, 'currency': ''}, {'person_name': 'Sirkka Sundell', 'department': 'Manufacturing - assembly', 'base_salary': 2779.97, 'currency': 'EUR'}, {'person_name': 'Taija Sundholm', 'department': 'Manufacturing - assembly', 'base_salary': 2494.42, 'currency': 'EUR'}, {'person_name': 'Sari Sunila', 'department': 'Controlling and Finance', 'base_salary': 3100.44, 'currency': 'EUR'}, {'person_name': 'Sannamari Suominen', 'department': 'Manufacturing - assembly', 'base_salary': 2532.71, 'currency': 'EUR'}, {'person_name': 'Virpi Suonpää', 'department': 'Supply chain management', 'base_salary': 2409.09, 'currency': 'EUR'}, {'person_name': 'Agnieszka Surowa', 'department': 'Supply Chain development', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Marzena Sykulska', 'department': 'Manufacturing - assembly', 'base_salary': 4972, 'currency': 'PLN'}, {'person_name': 'Aleksander Sykulski', 'department': 'Supply chain management', 'base_salary': 5122, 'currency': 'PLN'}, {'person_name': 'Růžena Symerská', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Jaana Syren', 'department': 'Manufacturing - assembly', 'base_salary': 2699, 'currency': 'EUR'}, {'person_name': 'Damian Szandała', 'department': 'Production scheduling', 'base_salary': 9110, 'currency': 'PLN'}, {'person_name': 'Ryszard Szarzewicz', 'department': 'Supply chain management', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Agnieszka Szczypińska', 'department': 'Supply chain management', 'base_salary': 4708, 'currency': 'PLN'}, {'person_name': 'Mateusz Szewczyk', 'department': 'Supply chain management', 'base_salary': 5200, 'currency': 'PLN'}, {'person_name': 'Mariusz Szychowski', 'department': 'Sales management', 'base_salary': 7603, 'currency': 'PLN'}, {'person_name': 'Robert Szyszka', 'department': 'Supply Chain development', 'base_salary': 5879, 'currency': 'PLN'}, {'person_name': 'Jenna Säikkä', 'department': 'Manufacturing - chrome plating', 'base_salary': 2179.77, 'currency': 'EUR'}, {'person_name': 'Alicja Sówka', 'department': 'Supply chain management', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Kamil Słomian', 'department': 'Supply chain management', 'base_salary': 6089, 'currency': 'PLN'}, {'person_name': 'Bogusława Słowik', 'department': 'Manufacturing - chrome plating', 'base_salary': 4647, 'currency': 'PLN'}, {'person_name': 'Heli Talvio', 'department': 'Warehouse', 'base_salary': 2730.72, 'currency': 'EUR'}, {'person_name': 'Niina Tanila', 'department': 'Manufacturing - assembly', 'base_salary': 2386.99, 'currency': 'EUR'}, {'person_name': 'Monika Tasarz', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Thorsten Tauer', 'department': 'Controlling and Finance', 'base_salary': 6750, 'currency': 'EUR'}, {'person_name': 'Kirsi-Maria Tauriainen', 'department': 'Manufacturing - injection molding', 'base_salary': 2489.64, 'currency': 'EUR'}, {'person_name': 'Anna Władysława Tekieli', 'department': 'Manufacturing - assembly', 'base_salary': 4830, 'currency': 'PLN'}, {'person_name': 'Anna Tekieli', 'department': 'Manufacturing - assembly', 'base_salary': 5259, 'currency': 'PLN'}, {'person_name': 'Miia Tervo', 'department': 'Manufacturing - assembly', 'base_salary': 2824.82, 'currency': 'EUR'}, {'person_name': 'Erja Tetri', 'department': 'Customer service & Sales support', 'base_salary': 3118.58, 'currency': 'EUR'}, {'person_name': 'Adam Tkacz', 'department': 'Supply Chain development', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Ari Toivonen', 'department': 'Technology', 'base_salary': 5296.15, 'currency': 'EUR'}, {'person_name': 'Joanna Tomaszewska', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Żaneta Topolska', 'department': 'Manufacturing - assembly', 'base_salary': 4861, 'currency': 'PLN'}, {'person_name': 'Grzegorz Topolski', 'department': 'Supply Chain development', 'base_salary': 4983, 'currency': 'PLN'}, {'person_name': 'Oskar Torikka', 'department': 'Supply Chain development', 'base_salary': 2399.06, 'currency': 'EUR'}, {'person_name': 'Wilhelmiina Torikka', 'department': 'Technical Communication', 'base_salary': 3687.45, 'currency': ''}, {'person_name': 'Anna Tousek', 'department': 'Logistics', 'base_salary': 6000, 'currency': 'PLN'}, {'person_name': 'Robert Trojanek', 'department': 'Supply chain management', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Marcin Trzepała', 'department': 'Process engineering', 'base_salary': 8737, 'currency': 'PLN'}, {'person_name': 'Susanna Tuomivaara', 'department': 'Manufacturing - assembly', 'base_salary': 2690.25, 'currency': 'EUR'}, {'person_name': 'Sauli Tuomivaara', 'department': 'Manufacturing - injection molding', 'base_salary': 3467.02, 'currency': 'EUR'}, {'person_name': 'Jukka Tuurala', 'department': 'Warehouse', 'base_salary': 2522.86, 'currency': 'EUR'}, {'person_name': 'Päivi Tynkkynen', 'department': 'Supply chain management', 'base_salary': 2670.56, 'currency': 'EUR'}, {'person_name': 'Katarzyna Tyrka', 'department': 'Manufacturing - assembly', 'base_salary': 5091, 'currency': 'PLN'}, {'person_name': 'Leila Tähtivuori', 'department': 'Warehouse', 'base_salary': 2654.14, 'currency': 'EUR'}, {'person_name': 'Jenni Tähtivuori', 'department': 'Warehouse', 'base_salary': 2644.73, 'currency': 'EUR'}, {'person_name': 'Jass Täll', 'department': 'Supply chain management', 'base_salary': 3331.36, 'currency': 'EUR'}, {'person_name': 'Tanja Uhlig', 'department': 'Quality', 'base_salary': 3019.54, 'currency': 'EUR'}, {'person_name': 'Marian Urbaniak', 'department': 'Sales network', 'base_salary': 10720, 'currency': 'PLN'}, {'person_name': 'Paulina Urbańczyk', 'department': 'Supply chain management', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Mariusz Urbańczyk', 'department': 'Supply chain management', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Minna Vainio', 'department': 'Manufacturing - assembly', 'base_salary': 2596.43, 'currency': 'EUR'}, {'person_name': 'Juha Vainio', 'department': 'Logistics', 'base_salary': 4254.43, 'currency': ''}, {'person_name': 'Tiina Valtonen', 'department': 'Supply chain management', 'base_salary': 2905.79, 'currency': 'EUR'}, {'person_name': 'Päivi Vanne', 'department': 'Manufacturing - assembly', 'base_salary': 2455.82, 'currency': 'EUR'}, {'person_name': 'Eva Vančová', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Esa Varho', 'department': 'Sales network', 'base_salary': 6305.12, 'currency': 'EUR'}, {'person_name': 'Anna Varis', 'department': 'Manufacturing - assembly', 'base_salary': 2248.2, 'currency': 'EUR'}, {'person_name': 'Sari Varonen', 'department': 'Manufacturing - chrome plating', 'base_salary': 2355.48, 'currency': 'EUR'}, {'person_name': 'Maija Vastiala-Saarinen', 'department': 'Logistics', 'base_salary': 3208.46, 'currency': ''}, {'person_name': 'Lenka Vaňková', 'department': 'Customer service & Sales support', 'base_salary': 48029, 'currency': 'CZK'}, {'person_name': 'Soňa Vaňková', 'department': 'Controlling and Finance', 'base_salary': 49895, 'currency': 'CZK'}, {'person_name': 'Markku Vehanen', 'department': 'Sales management', 'base_salary': 4853.02, 'currency': 'EUR'}, {'person_name': 'Marjo Venttola', 'department': 'Production scheduling', 'base_salary': 3462, 'currency': ''}, {'person_name': 'Melissa Vernijns', 'department': 'Customer service & Sales support', 'base_salary': 3693.98, 'currency': 'EUR'}, {'person_name': 'Jos Verstraten', 'department': 'Customer service & Sales support', 'base_salary': 6174.49, 'currency': 'EUR'}, {'person_name': 'Kateřina Veselá', 'department': 'Supply chain management', 'base_salary': 43715, 'currency': 'CZK'}, {'person_name': 'Heli Vidqvist', 'department': 'Controlling and Finance', 'base_salary': 5907.43, 'currency': 'EUR'}, {'person_name': 'Teija Viitanen', 'department': 'Manufacturing - assembly', 'base_salary': 2477.25, 'currency': 'EUR'}, {'person_name': 'Sari Vilen', 'department': 'Manufacturing - assembly', 'base_salary': 2108.72, 'currency': 'EUR'}, {'person_name': 'Päivi Viljanen', 'department': 'Manufacturing - assembly', 'base_salary': 2546.93, 'currency': 'EUR'}, {'person_name': 'Stefan Vinnay', 'department': 'Sales management', 'base_salary': 4219.63, 'currency': 'EUR'}, {'person_name': 'Jomi Virtanen', 'department': 'Technology', 'base_salary': 4923.29, 'currency': ''}, {'person_name': 'Jonni Virtanen', 'department': 'Manufacturing Technology', 'base_salary': 4025.95, 'currency': ''}, {'person_name': 'Merja Virtanen', 'department': 'Warehouse', 'base_salary': 3040.34, 'currency': 'EUR'}, {'person_name': 'Nina Virtanen', 'department': 'Warehouse', 'base_salary': 2746.86, 'currency': 'EUR'}, {'person_name': 'Arto Virtanen', 'department': 'Manufacturing Technology', 'base_salary': 3446.26, 'currency': 'EUR'}, {'person_name': 'Jesse Virtanen', 'department': 'Manufacturing - injection molding', 'base_salary': 2308.88, 'currency': 'EUR'}, {'person_name': 'Sari Virtanen', 'department': 'Warehouse', 'base_salary': 2537.09, 'currency': 'EUR'}, {'person_name': 'Juha Viskari', 'department': 'Manufacturing Technology', 'base_salary': 3268.17, 'currency': 'EUR'}, {'person_name': 'Jaroslav Vodrážka', 'department': 'Quality', 'base_salary': 44195, 'currency': 'CZK'}, {'person_name': 'Veronika Volínová', 'department': 'Controlling and Finance', 'base_salary': 32500, 'currency': 'CZK'}, {'person_name': 'Kateřina Votroubková', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Mervi Vuori', 'department': 'Quality', 'base_salary': 2803.7, 'currency': 'EUR'}, {'person_name': 'Anne Vähä-Ypyä', 'department': 'Manufacturing Technology', 'base_salary': 3794.25, 'currency': ''}, {'person_name': 'Mika Väisänen', 'department': 'Product Management', 'base_salary': 4812.63, 'currency': ''}, {'person_name': 'Henri Vång', 'department': 'Manufacturing - injection molding', 'base_salary': 2522.07, 'currency': ''}, {'person_name': 'Magdalena Wajrauch', 'department': 'Controlling and Finance', 'base_salary': 9558, 'currency': 'PLN'}, {'person_name': 'Artur Walicki', 'department': 'Marketing', 'base_salary': 11314, 'currency': 'PLN'}, {'person_name': 'Damian Warmuzek', 'department': 'Logistics', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Wioletta Wasiak', 'department': 'Controlling and Finance', 'base_salary': 9984, 'currency': 'PLN'}, {'person_name': 'Urszula Wazner', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Bernard Wazner', 'department': 'Supply chain management', 'base_salary': 6800, 'currency': 'PLN'}, {'person_name': 'Snorre Westrum', 'department': 'Sales management', 'base_salary': 66643, 'currency': 'NOK'}, {'person_name': 'Magdalena Wicher', 'department': 'Manufacturing - assembly', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Damian Wicher', 'department': 'Supply chain management', 'base_salary': 6848, 'currency': 'PLN'}, {'person_name': 'Kornelia Widera', 'department': 'Manufacturing - assembly', 'base_salary': 5265, 'currency': 'PLN'}, {'person_name': 'Michał Wiechoczek', 'department': 'Logistics', 'base_salary': 5100, 'currency': 'PLN'}, {'person_name': 'Angelika Wieczorek', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Karolina Wieczorek', 'department': 'Controlling and Finance', 'base_salary': 6465, 'currency': 'PLN'}, {'person_name': 'Irena Wieczorek', 'department': 'Supply chain management', 'base_salary': 4670, 'currency': 'PLN'}, {'person_name': 'Merena Wikman', 'department': 'Warehouse', 'base_salary': 2533.92, 'currency': 'EUR'}, {'person_name': 'Janne Wikström', 'department': 'Logistics', 'base_salary': 5049.01, 'currency': 'EUR'}, {'person_name': 'Irena Wilhelm', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Weronika Wilk', 'department': 'Supply chain management', 'base_salary': 4554, 'currency': 'PLN'}, {'person_name': 'Bożena Winecka', 'department': 'Manufacturing - assembly', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Michael Wirthle', 'department': 'Controlling and Finance', 'base_salary': 10990.68, 'currency': 'EUR'}, {'person_name': 'Marcin Więdłocha', 'department': 'Marketing', 'base_salary': 2500, 'currency': 'PLN'}, {'person_name': 'Jagoda Więdłocha', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Izabela Więdłocha', 'department': 'Logistic', 'base_salary': 5200, 'currency': 'PLN'}, {'person_name': 'Olimpia Wloczyk', 'department': 'Supply chain management', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Martyna Wojaczyk', 'department': 'Manufacturing - assembly', 'base_salary': 4913, 'currency': 'PLN'}, {'person_name': 'Paweł Wolny', 'department': 'Supply chain management', 'base_salary': 4900, 'currency': 'PLN'}, {'person_name': 'Michał Wolny', 'department': 'Quality', 'base_salary': 6300, 'currency': 'PLN'}, {'person_name': 'Sebastian Wolny', 'department': 'Supply chain management', 'base_salary': 5634, 'currency': 'PLN'}, {'person_name': 'Aleksander Woźny', 'department': 'Supply Chain development', 'base_salary': 5300, 'currency': 'PLN'}, {'person_name': 'Grzegorz Wróbel', 'department': 'Supply chain management', 'base_salary': 6300, 'currency': 'PLN'}, {'person_name': 'Aleksandra Wróż', 'department': 'Process engineering', 'base_salary': 8100, 'currency': 'PLN'}, {'person_name': 'Anna Justyna Wręczycka', 'department': 'Supply Chain development', 'base_salary': 4300, 'currency': 'PLN'}, {'person_name': 'Anna Wręczycka', 'department': 'Supply chain management', 'base_salary': 4670, 'currency': 'PLN'}, {'person_name': 'Jerzy Wyrwich', 'department': 'Supply chain management', 'base_salary': 5700, 'currency': 'PLN'}, {'person_name': 'Karina Wystalska-Wąsińska', 'department': 'Manufacturing - assembly', 'base_salary': 5282, 'currency': 'PLN'}, {'person_name': 'Mateusz Wystrychowski', 'department': 'Supply chain management', 'base_salary': 6195, 'currency': 'PLN'}, {'person_name': 'Jarosław Wąsiński', 'department': 'Logistics', 'base_salary': 5829, 'currency': 'PLN'}, {'person_name': 'Grzegorz Wąsiński', 'department': 'Supply chain management', 'base_salary': 6664, 'currency': 'PLN'}, {'person_name': 'Heikki Ylijoki', 'department': 'Manufacturing Technology', 'base_salary': 3030.52, 'currency': 'EUR'}, {'person_name': 'Taina Ylijoki', 'department': 'Manufacturing - assembly', 'base_salary': 2345.94, 'currency': 'EUR'}, {'person_name': 'Sebastian Zawierta', 'department': 'Supply chain management', 'base_salary': 9898, 'currency': 'PLN'}, {'person_name': 'Limin Zhang', 'department': 'Purchasing', 'base_salary': 3658.29, 'currency': 'EUR'}, {'person_name': 'Marcus Zier', 'department': 'Product Management', 'base_salary': 4721.5, 'currency': 'EUR'}, {'person_name': 'Zdzisław Ziętera', 'department': 'Manufacturing - chrome plating', 'base_salary': 5600, 'currency': 'PLN'}, {'person_name': 'Anna-Karin Öjetoft', 'department': 'Customer service & Sales support', 'base_salary': 37403.88, 'currency': 'SEK'}, {'person_name': 'Anette Österberg-Raula', 'department': 'Manufacturing - assembly', 'base_salary': 2400.34, 'currency': 'EUR'}, {'person_name': 'Miia Östman', 'department': 'Manufacturing - assembly', 'base_salary': 2735.13, 'currency': 'EUR'}, {'person_name': 'Hana Čapková', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}, {'person_name': 'Joanna Ładak', 'department': 'Quality', 'base_salary': 5414, 'currency': 'PLN'}, {'person_name': 'Joanna Łapucha-Włodarska', 'department': 'Manufacturing - assembly', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Katarzyna Ławna', 'department': 'Manufacturing - chrome plating', 'base_salary': 4600, 'currency': 'PLN'}, {'person_name': 'Marcin Łyko', 'department': 'Supply chain management', 'base_salary': 5257, 'currency': 'PLN'}, {'person_name': 'Wojciech Śniady', 'department': 'Production scheduling', 'base_salary': 9002, 'currency': 'PLN'}, {'person_name': 'Jiří Šiml', 'department': 'Logistic', 'base_salary': 18700, 'currency': 'CZK'}, {'person_name': 'Tomáš Škvor', 'department': 'Manufacturing - assembly', 'base_salary': 21300, 'currency': 'CZK'}, {'person_name': 'Petr Šubrt', 'department': 'Logistic', 'base_salary': 18700, 'currency': 'CZK'}, {'person_name': 'Izabela Żwaka', 'department': 'Customer service & Sales support', 'base_salary': 5721, 'currency': 'PLN'}, {'person_name': 'Ilona Živníčková', 'department': 'Manufacturing - assembly', 'base_salary': 12300, 'currency': 'CZK'}]
 
# Define currency conversion rates (NOK, PLN, CZK, SEK)
conversion_rates = {
    'AED': 0.25,   # UAE Dirham to EUR
    'AFN': 0.011,  # Afghan Afghani to EUR
    'ALL': 0.0093,  # Albanian Lek to EUR
    'AMD': 0.0024,  # Armenian Dram to EUR
    'ANG': 0.51,   # Netherlands Antillean Guilder to EUR
    'AOA': 0.0011,  # Angolan Kwanza to EUR
    'ARS': 0.0027,  # Argentine Peso to EUR
    'AUD': 0.60,   # Australian Dollar to EUR
    'AWG': 0.51,   # Aruban Florin to EUR
    'AZN': 0.53,   # Azerbaijani Manat to EUR
    'BAM': 0.51,   # Bosnia-Herzegovina Convertible Mark to EUR
    'BBD': 0.47,   # Barbadian Dollar to EUR
    'BDT': 0.0084,  # Bangladeshi Taka to EUR
    'BGN': 0.51,   # Bulgarian Lev to EUR
    'BHD': 2.46,   # Bahraini Dinar to EUR
    'BIF': 0.00034,# Burundian Franc to EUR
    'BMD': 0.94,   # Bermudian Dollar to EUR
    'BND': 0.69,   # Brunei Dollar to EUR
    'BOB': 0.14,   # Bolivian Boliviano to EUR
    'BRL': 0.19,   # Brazilian Real to EUR
    'BSD': 0.94,   # Bahamian Dollar to EUR
    'BTN': 0.011,  # Bhutanese Ngultrum to EUR
    'BWP': 0.07,   # Botswanan Pula to EUR
    'BYN': 0.36,   # Belarusian Ruble to EUR
    'BZD': 0.47,   # Belize Dollar to EUR
    'CAD': 0.69,   # Canadian Dollar to EUR
    'CDF': 0.00038,# Congolese Franc to EUR
    'CHF': 0.94,   # Swiss Franc to EUR
    'CLP': 0.0011,  # Chilean Peso to EUR
    'CNY': 0.13,   # Chinese Yuan to EUR
    'COP': 0.00024,# Colombian Peso to EUR
    'CRC': 0.0018,  # Costa Rican Colón to EUR
    'CUP': 0.037,  # Cuban Peso to EUR
    'CVE': 0.0092,  # Cape Verdean Escudo to EUR
    'CZK': 0.041,  # Czech Koruna to EUR
    'DJF': 0.0053,  # Djiboutian Franc to EUR
    'DKK': 0.13,   # Danish Krone to EUR
    'DOP': 0.017,  # Dominican Peso to EUR
    'DZD': 0.0069,  # Algerian Dinar to EUR
    'EGP': 0.030,  # Egyptian Pound to EUR
    'ERN': 0.063,  # Eritrean Nakfa to EUR
    'ETB': 0.017,  # Ethiopian Birr to EUR
    'FJD': 0.42,   # Fijian Dollar to EUR
    'FKP': 1.14,   # Falkland Islands Pound to EUR
    'FOK': 0.13,   # Faroese Króna to EUR
    'GEL': 0.35,   # Georgian Lari to EUR
    'GGP': 1.14,   # Guernsey Pound to EUR
    'GHS': 0.081,  # Ghanaian Cedi to EUR
    'GIP': 1.14,   # Gibraltar Pound to EUR
    'GMD': 0.014,  # Gambian Dalasi to EUR
    'GNF': 0.00011,# Guinean Franc to EUR
    'GTQ': 0.12,   # Guatemalan Quetzal to EUR
    'GYD': 0.0045,  # Guyanaese Dollar to EUR
    'HKD': 0.12,   # Hong Kong Dollar to EUR
    'HNL': 0.038,  # Honduran Lempira to EUR
    'HRK': 0.13,   # Croatian Kuna to EUR
    'HTG': 0.0083,  # Haitian Gourde to EUR
    'HUF': 0.0026,  # Hungarian Forint to EUR
    'IDR': 0.000061,# Indonesian Rupiah to EUR
    'ILS': 0.24,   # Israeli New Shekel to EUR
    'IMP': 1.14,   # Isle of Man Pound to EUR     
    'INR': 0.011,  # Indian Rupee to EUR
    'IQD': 0.00064,# Iraqi Dinar to EUR
    'IRR': 0.000022,# Iranian Rial to EUR
    'ISK': 0.0064,  # Icelandic Króna to EUR
    'JEP': 1.14,   # Jersey Pound to EUR
    'JMD': 0.0061,  # Jamaican Dollar to EUR
    'JOD': 1.32,   # Jordanian Dinar to EUR
    'JPY': 0.0063,  # Japanese Yen to EUR
    'KES': 0.0064,  # Kenyan Shilling to EUR
    'KGS': 0.011,  # Kyrgystani Som to EUR
    'KHR': 0.00023,# Cambodian Riel to EUR
    'KID': 0.60,   # Kiribati Dollar to EUR
    'KMF': 0.0020,  # Comorian Franc to EUR
    'KRW': 0.00071,# South Korean Won to EUR
    'KWD': 3.06,   # Kuwaiti Dinar to EUR
    'KYD': 1.13,   # Cayman Islands Dollar to EUR
    'KZT': 0.0019,  # Kazakhstani Tenge to EUR
    'LAK': 0.000048,# Laotian Kip to EUR
    'LBP': 0.000062,# Lebanese Pound to EUR
    'LKR': 0.0029,  # Sri Lankan Rupee to EUR
    'LRD': 0.0047,  # Liberian Dollar to EUR
    'LSL': 0.050,  # Lesotho Loti to EUR
    'LYD': 0.19,   # Libyan Dinar to EUR
    'MAD': 0.087,  # Moroccan Dirham to EUR
    'MDL': 0.051,  # Moldovan Leu to EUR
    'MGA': 0.00021,# Malagasy Ariary to EUR
    'MKD': 0.016,  # Macedonian Denar to EUR
    'MMK': 0.00045,# Myanmar Kyat to EUR
    'MNT': 0.00027,# Mongolian Tugrik to EUR
    'MOP': 0.12,   # Macanese Pataca to EUR
    'MRU': 0.024,  # Mauritanian Ouguiya to EUR
    'MUR': 0.020,  # Mauritian Rupee to EUR
    'MVR': 0.057,  # Maldivian Rufiyaa to EUR
    'MWK': 0.00082,# Malawian Kwacha to EUR
    'MXN': 0.053,  # Mexican Peso to EUR
    'MYR': 0.20,   # Malaysian Ringgit to EUR
    'MZN': 0.015,  # Mozambican Metical to EUR
    'NAD': 0.050,  # Namibian Dollar to EUR
    'NGN': 0.0012,  # Nigerian Naira to EUR
    'NIO': 0.026,  # Nicaraguan Córdoba to EUR
    'NOK': 0.086,  # Norwegian Krone to EUR
    'NPR': 0.0069,  # Nepalese Rupee to EUR
    'NZD': 0.56,   # New Zealand Dollar to EUR
    'OMR': 2.44,   # Omani Rial to EUR
    'PAB': 0.94,   # Panamanian Balboa to EUR
    'PEN': 0.25,   # Peruvian Nuevo Sol to EUR
    'PGK': 0.26,   # Papua New Guinean Kina to EUR
    'PHP': 0.016,  # Philippine Peso to EUR
    'PKR': 0.0034,  # Pakistani Rupee to EUR
    'PLN': 0.22,   # Polish Zloty to EUR
    'PYG': 0.00013,# Paraguayan Guarani to EUR
    'QAR': 0.26,   # Qatari Rial to EUR
    'RON': 0.20,   # Romanian Leu to EUR
    'RUB': 0.0097,  # Russian Ruble to EUR
    'RWF': 0.00077,# Rwandan Franc to EUR
    'SAR': 0.25,   # Saudi Riyal to EUR
    'SBD': 0.11,   # Solomon Islands Dollar to EUR
    'SCR': 0.068,  # Seychellois Rupee to EUR
    'SDG': 0.0016,  # Sudanese Pound to EUR
    'SEK': 0.086,  # Swedish Krona to EUR
    'SGD': 0.69,   # Singapore Dollar to EUR
    'SHP': 1.14,   # Saint Helena Pound to EUR
    'SLE': 0.043,  # Sierra Leonean Leone to EUR
    'SLL': 0.000043,# Sierra Leonean Leone to EUR
    'SOS': 0.0016,  # Somali Shilling to EUR
    'SRD': 0.025,  # Surinamese Dollar to EUR
    'SSP': 0.0077,  # South Sudanese Pound to EUR
    'STN': 0.042,  # São Tomé and Príncipe Dobra to EUR
    'SYP': 0.00012,# Syrian Pound to EUR
    'SZL': 0.050,  # Swazi Lilangeni to EUR
    'THB': 0.025,  # Thai Baht to EUR
    'TJS': 0.086,  # Tajikistani Somoni to EUR
    'TMT': 0.27,   # Turkmenistani Manat to EUR
    'TNS': 0.038,  # Tunisian Dinar to EUR
    'TOP': 0.38,   # Tongan Paʻanga to EUR
    'TRY': 0.034,  # Turkish Lira to EUR
    'TTD': 0.14,   # Trinidad and Tobago Dollar to EUR
    'TVD': 0.60,   # Tuvaluan Dollar to EUR
    'TWD': 0.029,  # New Taiwan Dollar to EUR
    'TZS': 0.00038,# Tanzanian Shilling to EUR
    'UAH': 0.025,  # Ukrainian Hryvnia to EUR
    'UGX': 0.00025,# Ugandan Shilling to EUR
    'USD': 0.94,   # US Dollar to EUR
    'UYU': 0.024,  # Uruguayan Peso to EUR
    'UZS': 0.000077,# Uzbekistani Som to EUR
    'VES': 0.028,  # Venezuelan Bolívar Soberano to EUR
    'VND': 0.000038,# Vietnamese Dong to EUR
    'VUV': 0.0078,  # Vanuatu Vatu to EUR
    'WST': 0.35,   # Samoan Tala to EUR
    'XAF': 0.0015,  # Central African CFA Franc to EUR
    'XCD': 0.35,   # East Caribbean Dollar to EUR
    'XDR': 1.23,   # Special Drawing Rights to EUR
    'XOF': 0.0015,  # West African CFA Franc to EUR
    'XPF': 0.0084,  # CFP Franc to EUR
    'YER': 0.0038,  # Yemeni Rial to EUR
    'ZAR': 0.050,  # South African Rand to EUR
    'ZMW': 0.045,  # Zambian Kwacha to EUR
    'ZWL': 0.0029,   # Zimbabwean Dollar to EUR
}
 
# Load the data into a DataFrame (assuming you have some data in data)
df = pd.DataFrame(data)

# Convert the 'base_salary' column to numeric (in case of strings or mixed types)
df['base_salary'] = pd.to_numeric(df['base_salary'], errors='coerce')

# Function to convert salary to EUR
def convert_to_eur(row):
    return row['base_salary'] * conversion_rates.get(row['currency'], 1)
print(conversion_rates)
# Convert all salaries to EUR
df['salary_in_eur'] = df.apply(convert_to_eur, axis=1)
print(conversion_rates)
# Handle missing values (if any) by dropping rows with NaN values in relevant columns
df.dropna(subset=['salary_in_eur', 'department'], inplace=True)
 
# Group data by department and sort by salary for visualization
df_grouped = df.groupby('department')['salary_in_eur'].median().reset_index().sort_values(by='salary_in_eur')
 
# Plot salary distribution per department using seaborn
plt.figure(figsize=(10, 8))
sns.boxplot(x='department', y='salary_in_eur', data=df, palette='Set3')
plt.xticks(rotation=90)
plt.title('Salary Distribution by Department (in EUR)', fontsize=14)
plt.xlabel('Department', fontsize=12)
plt.ylabel('Salary in EUR', fontsize=12)
plt.tight_layout()
plt.show()
"""

    # Optionally, you can dynamically insert your dataset into the `custom_code`
    # Convert `full_data` to DataFrame and inject it into the code
    

    # graph_code = get_dynamic_graph_code(report_name, full_data, user_description)

    # if graph_code is None:
    #     # Return an error response if the graph_code could not be generated
    #     return jsonify({"error": "Failed to generate graph code from OpenAI."}), 500

    # print('Graph Code:', graph_code)

    # # Replace the full data with the full dataset in the generated code because openai doesn't support large data
    # modified_code = replace_data_with_full_dataset(graph_code, full_data2)

    # print('Modified Code:', modified_code)

    print(custom_code)
    exec(custom_code,globals())
    # exec(custom_code, {"plt": plt, "pd": pd, "sns": sns, "conversion_rates": conversion_rates}, local_scope)


    # Save the graph to a BytesIO object instead of saving it as a file
    img_io = BytesIO()
    plt.savefig(img_io, format='png')
    plt.close()
    img_io.seek(0)

    # Return the image directly in the response
    return send_file(img_io, mimetype='image/png')

@generate_report.route('/generate-report3', methods=['POST'])
def generate_report4():
    request_data = request.get_json()
    report_name = request_data.get('report_name')
    print("report name : ", report_name)
    print("*"*25)
    user_description = request_data.get('description')  # User-provided description
 
    # Fetch the report info from the report_fields_mapping1
    #report_info = report_fields_mapping.get(report_name)
    report_info = generate_graph_fields(user_description)
    if not report_info:
        return jsonify({"error": "Invalid report name provided."}), 400
 
    # Initialize full_data
    full_data = []
 
    # Fetch full data from all collections (without limiting to 50 employees)
    for idx, (collection_name, field_names) in enumerate(report_info.items()):
        projection = {field: 1 for field in field_names}
        projection.update({'_id': 0})
 
        print("collection name : ", collection_name)
        print("*"*25)
        # Fetch full dataset from each collection
        collection_data = list(db[collection_name].find({}, projection).limit(150))
        # collection_data = list(db[collection_name].find({}, projection))
        
        print('collection name : ',collection_data)
        print("*"*25)
        print()
 
        if idx == 0:
            # Initialize full_data with the first collection
            full_data = collection_data
        else:
            # Merge this collection's data with the full_data based on 'person_name'
            collection_data_dict = {employee.get('person_name', 'Unknown'): employee for employee in collection_data}
            for employee in full_data:
                person_name = employee.get('person_name')
                if person_name and person_name in collection_data_dict:
                    # Merge fields from this collection's data into full_data
                    for key in field_names:
                        employee[key] = collection_data_dict[person_name].get(key, None)
 
    print("Full data : ",full_data)
                       
    # Get dynamic graph code from OpenAI using the full data and the user description
    graph_code = get_dynamic_graph_code(report_name, full_data, user_description)
 
    if graph_code is None:
        # Return an error response if the graph_code could not be generated
        return jsonify({"error": "Failed to generate graph code from OpenAI."}), 500
 
    print('Graph Code:', graph_code)
 
    # Replace the fukk data with the full dataset in the generated code because openai doesn't support large data
    modified_code = replace_data_with_full_dataset(graph_code, full_data)
 
    print('Modified Code:', modified_code)
   
        # Generate a unique filename to save the image
    image_filename = f"{uuid.uuid4().hex}.png"
    image_path = os.path.join(TEMP_IMAGE_FOLDER, image_filename)
 
    # Execute the dynamically generated and modified code
    local_scope = {}
    exec(modified_code, {"plt": plt, "pd": pd, "sns": sns}, local_scope)    
    # Save the graph to the image path
    plt.savefig(image_path)
    plt.close()
 
    # Generate a URL to access the image in a temporary UI
    image_url = url_for('generate_report.show_image', image_filename=image_filename, _external=True)
    view_image_url = url_for('generate_report.view_image', image_filename=image_filename, _external=True)
 
    # Return a link to view the image in the frontend
    return jsonify({
        "view_image_url": view_image_url
    })
 
 
#All graph generation on bigger data(more than 100 employee) use this approach until find any better approach. If anyone find any better approach then notify.

# Register Blueprint
app.register_blueprint(generate_report)

# Run the Flask application
if __name__ == "__main__":
    app.run(debug=True, port=5000)