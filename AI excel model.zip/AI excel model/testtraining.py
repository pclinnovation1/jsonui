import pandas as pd
import numpy as np
import openai
from sklearn.metrics.pairwise import cosine_similarity
import re
import h5py
import os

# Initialize OpenAI API key
openai.api_key = 'sk-None-6UW5ydeHcotdQg7fx94FT3BlbkFJiTCBx9J0npkvw5lX6UFY'  # Replace with your OpenAI API key

# Function to get embeddings from OpenAI
def get_embeddings(texts):
    response = openai.Embedding.create(input=texts, engine="text-embedding-ada-002")
    embeddings = [data['embedding'] for data in response['data']]
    return np.array(embeddings)

# Load the provided Excel file
file_path = 'AI excel model/trainingexcel3.xlsx'  # Update with your actual file path
excel_data = pd.ExcelFile(file_path)

# Display the sheet names to understand the structure of the file
sheet_names = excel_data.sheet_names
print(sheet_names)

# Function to concatenate column names and data for better similarity matching
def concatenate_column_data(df, n_samples=10):
    concatenated_data = {}
    for col in df.columns:
        sample_data = df[col].astype(str).sample(n=min(n_samples, len(df)), random_state=1).tolist()
        concatenated_data[col] = f"{col}: {' '.join(sample_data)}"
    return concatenated_data

# Function to collect column names and concatenated data from each sheet
def collect_sheet_data(excel_data, sheet_names, exclude_sheets=[]):
    collected_data = {}
    for sheet in sheet_names:
        if sheet not in exclude_sheets:  # Exclude specified sheets
            df = excel_data.parse(sheet)
            sheet_data = concatenate_column_data(df)
            collected_data.update(sheet_data)
    return collected_data

# Load the data from Sheet1 (reference)
sheet1_df = excel_data.parse('Sheet1')

# Reference columns and concatenated data from Sheet1
ref_data = concatenate_column_data(sheet1_df)
ref_columns = list(ref_data.keys())

# Collect data from all other sheets for training
training_collected_data = collect_sheet_data(excel_data, sheet_names, exclude_sheets=['Sheet1'])

# Function to get combined embeddings for columns and data
def get_combined_embeddings(columns_data):
    column_names = [col for col, _ in columns_data.items()]
    data_samples = [data for _, data in columns_data.items()]
    
    # Get embeddings for column names
    column_name_embeddings = get_embeddings(column_names)
    # Get embeddings for data samples
    data_sample_embeddings = get_embeddings(data_samples)
    
    # Combine the embeddings with more weight to the column name
    combined_embeddings = 0.3 * column_name_embeddings + 0.7 * data_sample_embeddings
    return combined_embeddings

# Get combined embeddings for reference and training data
ref_embeddings = get_combined_embeddings(ref_data)
train_embeddings = get_combined_embeddings(training_collected_data)

# Load existing model if it exists
model_path = 'AI excel model/trained_model.h5'
if os.path.exists(model_path):
    with h5py.File(model_path, 'r') as f:
        prev_ref_columns = [col.decode('utf-8') for col in f['ref_columns']]
        prev_ref_embeddings = np.array(f['ref_embeddings'])
    # Combine previous and new embeddings
    ref_columns += prev_ref_columns
    ref_embeddings = np.vstack((ref_embeddings, prev_ref_embeddings))

# Save the trained model to an H5 file
with h5py.File(model_path, 'w') as f:
    ref_columns_bytes = np.array([col.encode('utf-8') for col in ref_columns], dtype=h5py.string_dtype('utf-8'))
    f.create_dataset('ref_columns', data=ref_columns_bytes)
    f.create_dataset('ref_embeddings', data=ref_embeddings)

print(f"Trained model saved to {model_path}")
