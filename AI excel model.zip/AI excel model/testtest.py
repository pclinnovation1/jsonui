import pandas as pd
import numpy as np
import openai
import h5py
from sklearn.metrics.pairwise import cosine_similarity
import re

# Initialize OpenAI API key
openai.api_key = 'sk-None-6UW5ydeHcotdQg7fx94FT3BlbkFJiTCBx9J0npkvw5lX6UFY'  # Replace with your OpenAI API key

# Function to get embeddings from OpenAI
def get_embeddings(texts):
    response = openai.Embedding.create(input=texts, engine="text-embedding-ada-002")
    embeddings = [data['embedding'] for data in response['data']]
    return np.array(embeddings)

# Function to concatenate column names and data for better similarity matching
def concatenate_column_data(df, n_samples=10):
    concatenated_data = {}
    for col in df.columns:
        sample_data = df[col].astype(str).sample(n=min(n_samples, len(df)), random_state=1).tolist()
        concatenated_data[col] = f"{col}: {' '.join(sample_data)}"
    return concatenated_data

# Function to get combined embeddings for columns and data
def get_combined_embeddings(columns_data):
    column_names = [col for col, _ in columns_data.items()]
    data_samples = [data for _, data in columns_data.items()]
    
    # Get embeddings for column names
    column_name_embeddings = get_embeddings(column_names)
    # Get embeddings for data samples
    data_sample_embeddings = get_embeddings(data_samples)
    
    # Combine the embeddings with more weight to the column name
    combined_embeddings = 0.3 * column_name_embeddings + 0.7 * data_sample_embeddings
    return combined_embeddings

# Function to map new data columns using the trained model
def map_new_columns(input_df, ref_columns, ref_embeddings):
    # Collect data from the input DataFrame
    input_data = concatenate_column_data(input_df)
    input_columns = list(input_data.keys())

    # Get combined embeddings for input data
    input_embeddings = get_combined_embeddings(input_data)
    
    # Calculate cosine similarity
    similarity_matrix = cosine_similarity(input_embeddings, ref_embeddings)
    
    # Find the best matches for each new column
    new_column_mappings = {}
    for i, input_col in enumerate(input_columns):
        if similarity_matrix.shape[0] <= i:
            print(f"Skipping column {input_col} due to mismatch in embeddings.")
            continue
        best_match_index = np.argmax(similarity_matrix[i])
        best_match_score = similarity_matrix[i][best_match_index]
        if best_match_index < len(ref_columns) and best_match_score >= 0.7:
            new_column_mappings[input_col] = (ref_columns[best_match_index], best_match_score)
        else:
            new_column_mappings[input_col] = ('No Match', best_match_score)
    
    # Convert the mappings to a DataFrame for better readability
    new_mappings_df = pd.DataFrame(new_column_mappings).T
    new_mappings_df.columns = ['Mapped Reference Column', 'Cosine Similarity']
    
    return new_mappings_df

# Load the trained model from the H5 file
model_path = 'AI excel model/trained_model.h5'
with h5py.File(model_path, 'r') as f:
    ref_columns = [col.decode('utf-8') for col in f['ref_columns']]
    ref_embeddings = np.array(f['ref_embeddings'])

print("Trained model loaded")

# Load the new Excel file
new_file_path = input("Enter the path to the new Excel file: ")  # Prompt user to enter the new file path
excel_data = pd.ExcelFile(new_file_path)

# Load the data from the specified sheet
sheet_name = input("Enter the sheet name to test: ")  # Prompt user to enter the sheet name
input_df = excel_data.parse(sheet_name)

# Use the trained model to detect columns in the new sheet
new_mappings_df = map_new_columns(input_df, ref_columns, ref_embeddings)

# Display the mappings DataFrame
print(new_mappings_df)

# Save the mappings DataFrame to a CSV file
output_file_path = 'AI excel model/column_mappings.csv'
new_mappings_df.to_csv(output_file_path, index=True)

print(f"Mappings saved to {output_file_path}")
