from pymongo import MongoClient
from datetime import datetime, timedelta
from leave_accrual_config import leave_accrual_config

# MongoDB connection setup
client = MongoClient("mongodb://localhost:27017/")
db = client["dev1"]
employees_collection = db["HRM_employee_details"]
leave_accruals_collection = db["leave_accruals"]


def calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender=None, fte=1.0, additional_leave_rate=0.0):
    """
    Calculate the total accrued leave based on various factors.

    Parameters:
        start_date (str): The start date of the accrual period in the format "YYYY-MM-DD".
        end_date (str): The end date of the accrual period in the format "YYYY-MM-DD".
        employee_type (str): The type of employee (e.g., "full-time", "part-time").
        leave_type (str): The type of leave for which accrual is calculated.
        gender (str, optional): The gender of the employee (e.g., "male", "female").
        fte (float, optional): The Full-Time Equivalent (FTE) value of the employee.
        additional_leave_rate (float, optional): Additional leave rate for special cases (e.g., shift types, seniority levels).

    Returns:
        dict: A dictionary containing the total accrued leave.
    """
    # Input validation
    if not (start_date and end_date and employee_type and leave_type):
        return {"error": "Invalid input parameters"}

    # Check if leave type exists in the configuration
    leave_type_details = leave_accrual_config["leave_types"].get(leave_type)
    if not leave_type_details:
        return {"error": "Invalid leave type"}

    # Check if leave type is applicable based on gender
    if "applicable_gender" in leave_type_details and leave_type_details["applicable_gender"] != gender:
        return {"error": "Leave type not applicable based on gender"}

    # Get the accrual rate for the given employee type and leave type
    accrual_rate = leave_type_details["accrual_rates"].get(employee_type)
    if accrual_rate is None:
        return {"error": "Invalid employee type"}

    # Prorate accrual rate based on FTE for part-time employees
    prorated_accrual_rate = accrual_rate * fte if employee_type == "part-time" else accrual_rate

    # Calculate the number of months between start_date and end_date
    start_date = datetime.strptime(start_date, "%Y-%m-%d")
    end_date = datetime.strptime(end_date, "%Y-%m-%d")

    # Initialize total accrued leave
    total_accrued_leave = 0.0

    # Calculate the number of full months between start_date and end_date
    while start_date <= end_date:
        # Add the prorated accrual rate plus additional leave rate to the total accrued leave
        total_accrued_leave += prorated_accrual_rate + additional_leave_rate

        # Move to the next month
        start_date = start_date.replace(day=1) + timedelta(days=32)
        start_date = start_date.replace(day=1)

    return {"total_accrued_leave": total_accrued_leave}


# Function to calculate leave accruals for all employees
def calculate_leave_accruals():
    leave_accruals_collection.delete_many({})
    # Fetch all distinct person numbers from the HRM_employee_details collection
    person_numbers = employees_collection.distinct("Person_Number")

    for person_number in person_numbers:
        # Fetch employee data by person number
        employee_data = employees_collection.find_one({"Person_Number": person_number})
        if not employee_data:
            continue

        # Extract relevant data for leave accrual calculation
        start_date = datetime.strptime(employee_data["Original_Start_Date"], "%Y-%m-%d")
        hire_date = datetime.strptime(employee_data["Hire_Date"], "%Y-%m-%d")
        gender = employee_data["Gender"]
        employment_type = employee_data["Employment_Type"].lower()
        fte = float(employee_data["FTE"])

        # Use financial year start date if hire date is after financial year start date, else use hire date
        current_year = datetime.now().year
        financial_year_start = datetime(current_year, 4, 1)
        start_date = max(start_date, hire_date, financial_year_start).strftime("%Y-%m-%d")
        end_date = datetime.utcnow().strftime("%Y-%m-%d")  # Use current date as end date

        # Fetch shift details for the employee
        shift_type = employee_data.get("Shift_Type", "")  # Assume the field in MongoDB is "Shift_Type"
        print(shift_type)
        # hire_date = hire_date.strftime("%Y-%m-%d")
        seniority_level = calculate_seniority_level(start_date, hire_date)  # Calculate seniority level based on hire date
        union_member = employee_data.get("Union_Member", False)  # Check if employee is a union member
        unionized_leave_accrual = get_unionized_leave_accrual(employment_type, fte) if union_member else 0.0


        # Perform leave accrual calculation for all leave types
        for leave_type in ["annual_leave"]:
            # Calculate additional leave accrual based on seniority level and shift type
            additional_leave_rate = calculate_additional_leave_rate(seniority_level, shift_type) + unionized_leave_accrual
            print(additional_leave_rate)
            # leave_accrual_config["leave_types"].keys():
            accrued_leave = calculate_leave_accrual(start_date, end_date, employment_type, leave_type, gender, fte, additional_leave_rate)

            # Store leave accrual data in the MongoDB collection
            leave_record = {
                "person_number": person_number,
                "leave_type": leave_type,
                "total_accrued_leave": accrued_leave["total_accrued_leave"],
                "timestamp": datetime.now()
            }
            leave_accruals_collection.insert_one(leave_record)

# Function to calculate additional leave rate based on seniority level and shift type
def calculate_additional_leave_rate(seniority_level, shift_type):
    # Get additional leave rate based on seniority level and shift type
    seniority_leave_rate = leave_accrual_config.get("seniority_levels", {}).get(seniority_level, {}).get("additional_leave_rate", 0.0)
    shift_leave_rate = leave_accrual_config.get("shift_types", {}).get(shift_type, {}).get("additional_leave_rate", 0.0)
    print("shift_leave_rate1:",shift_leave_rate)

    # Combine both leave rates
    return seniority_leave_rate + shift_leave_rate       

# Function to calculate seniority level based on hire date
def calculate_seniority_level(start_date, hire_date):
    start_date = datetime.strptime(start_date, "%Y-%m-%d")
    # hire_date = datetime.strptime(hire_date, "%Y-%m-%d")
    years_of_service = (start_date - hire_date).days / 365
    if years_of_service < 5:
        return "1-5"
    elif years_of_service < 10:
        return "6-10"
    else:
        return "10+"    

# Function to get unionized leave accrual based on employment type and FTE
def get_unionized_leave_accrual(employment_type, fte):
    # Get accrual rates for unionized employees based on employment type
    accrual_rates = leave_accrual_config.get("unionized_employees", {}).get("accrual_rates", {})
    accrual_rate = accrual_rates.get(employment_type, fte)

    # Prorate accrual rate based on FTE for part-time employees
    if employment_type == "part-time":
        accrual_rate *= fte
        print("uacc :", accrual_rate)

    return accrual_rate     

if __name__ == "__main__":
    # Call the function to calculate leave accruals
    calculate_leave_accruals()
