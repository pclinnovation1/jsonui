from flask import Flask, request, jsonify
from pymongo import MongoClient

app = Flask(__name__)

# Connect to MongoDB
client = MongoClient('mongodb://PCL_Interns_admin:PCLinterns2050admin@172.191.245.199:27017/dev1')
db = client['dev1']

@app.route('/enroll', methods=['POST'])
def enroll_employee():
    data = request.get_json()
    offering_title = data.get("Offering Title")
    person_name = data.get("Person Name")
    enrollment_date = data.get("Enrollment Date")

    if not offering_title or not person_name or not enrollment_date:
        return jsonify({"error": "Invalid input data"}), 400

    # Split Person Name into First Name and Last Name
    try:
        first_name, last_name = person_name.split(" ", 1)
    except ValueError:
        return jsonify({"error": "Invalid Person Name format"}), 400

    # Find Person Number from HRM_employee_details
    employee = db['HRM_employee_details'].find_one({"First_Name": first_name, "Last_Name": last_name})
    if not employee:
        return jsonify({"error": "Employee not found"}), 404

    person_number = employee["Person_Number"]
    employee_details = {
        "Person Number": person_number,
        "Employee Name": person_name,
        "Enrollment Date": enrollment_date,
        "Status": "in-progress"
    }
    employee_details_wl = {
        "Person Number": person_number,
        "Employee Name": person_name,
        "Enrollment Date": enrollment_date,
        "Status": "Waiting"
    }

    offering = db['LRN_Offerings'].find_one({"Offering Title": offering_title})

    if offering:
        offering_id = offering["_id"]
        if offering["Active Learners"] < offering["Maximum Capacity"]:
            # Enroll the employee
            db['LRN_Offerings'].update_one(
                {"_id": offering_id},
                {"$inc": {"Active Learners": 1}}
            )
            db['LRN_employee_offering_detail'].insert_one({
                "offering_id": offering_id,
                "Offering Title": offering_title,
                **employee_details
            })
            return jsonify({"message": "Employee enrolled successfully."}), 200
        else:
            # Calculate next waitlist number
            waitlist_count = db['employee_waitlist_details'].count_documents({"offering_id": offering_id})
            waitlist_number = waitlist_count + 1

            # Add to waitlist
            db['employee_waitlist_details'].insert_one({
                "offering_id": offering_id,
                "waitlist_number": waitlist_number,
                **employee_details_wl
            })
            return jsonify({"message": f"Seats are full. Employee added to waitlist with waitlist number {waitlist_number}."}), 200
    else:
        return jsonify({"error": "Offering not found."}), 404

@app.route('/withdraw', methods=['POST'])
def withdraw_employee():
    data = request.get_json()
    offering_title = data.get("Offering Title")
    person_name = data.get("Person Name")

    if not offering_title or not person_name:
        return jsonify({"error": "Invalid input data"}), 400

    # Split Person Name into First Name and Last Name
    try:
        first_name, last_name = person_name.split(" ", 1)
    except ValueError:
        return jsonify({"error": "Invalid Person Name format"}), 400

    # Find Person Number from HRM_employee_details
    employee = db['HRM_employee_details'].find_one({"First_Name": first_name, "Last_Name": last_name})
    if not employee:
        return jsonify({"error": "Employee not found"}), 404

    person_number = employee["Person_Number"]

    offering = db['LRN_Offerings'].find_one({"Offering Title": offering_title})

    if offering:
        offering_id = offering["_id"]
        result = db['LRN_employee_offering_detail'].update_one(
            {"offering_id": offering_id, "Person Number": person_number},
            {"$set": {"Status": "withdrawn"}}
        )
        if result.matched_count > 0:
            # Decrease Active Learners count by 1
            db['LRN_Offerings'].update_one(
                {"_id": offering_id},
                {"$inc": {"Active Learners": -1}}
            )

            # Check for waitlisted employees
            waitlisted_employee = db['employee_waitlist_details'].find_one(
                {"offering_id": offering_id},
                sort=[("waitlist_number", 1)]
            )

            if waitlisted_employee:
                # Remove from waitlist and add to enrolled
                db['employee_waitlist_details'].delete_one(
                    {"_id": waitlisted_employee["_id"]}
                )
                db['LRN_employee_offering_detail'].insert_one({
                    "offering_id": offering_id,
                    "Person Number": waitlisted_employee["Person Number"],
                    "Employee Name": waitlisted_employee["Employee Name"],
                    "Enrollment Date": waitlisted_employee["Enrollment Date"],
                    "Status": "in-progress"
                })

                # Increase Active Learners count by 1
                db['LRN_Offerings'].update_one(
                    {"_id": offering_id},
                    {"$inc": {"Active Learners": 1}}
                )

                # Decrease waitlist numbers for remaining waitlisted employees
                db['employee_waitlist_details'].update_many(
                    {"offering_id": offering_id, "waitlist_number": {"$gt": waitlisted_employee["waitlist_number"]}},
                    {"$inc": {"waitlist_number": -1}}
                )

            return jsonify({"message": "Employee withdrawn successfully and waitlist updated."}), 200
        else:
            return jsonify({"error": "Employee not enrolled in the specified offering."}), 404
    else:
        return jsonify({"error": "Offering not found."}), 404

if __name__ == '__main__':
    app.run(debug=True)
