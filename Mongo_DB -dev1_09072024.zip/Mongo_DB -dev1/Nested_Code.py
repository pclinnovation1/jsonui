from pymongo import MongoClient, errors

try:
    # Connect to MongoDB
    client = MongoClient("mongodb://localhost:27017/")
    print("Connected to MongoDB successfully!")

    # Access the database (create it if it doesn't exist)
    db = client.company

    # Access the collection (create it if it doesn't exist)
    employee_collection = db.employees

    # Sample employee documents with nested documents
    employees = [
        {
            "name": "John Doe",
            "age": 30,
            "position": "Software Engineer",
            "department": "Engineering",
            "address": {
                "street": "123 Main St",
                "city": "Springfield",
                "state": "IL",
                "zip": "62701"
            },
            "projects": [
                {"name": "Project A", "status": "Completed"},
                {"name": "Project B", "status": "In Progress"}
            ]
        },
        {
            "name": "Jane Smith",
            "age": 25,
            "position": "Data Analyst",
            "department": "Data Science",
            "address": {
                "street": "456 Elm St",
                "city": "Springfield",
                "state": "IL",
                "zip": "62702"
            },
            "projects": [
                {"name": "Project C", "status": "In Progress"},
                {"name": "Project D", "status": "Not Started"}
            ]
        },
        {
            "name": "Mike Johnson",
            "age": 35,
            "position": "Project Manager",
            "department": "Management",
            "address": {
                "street": "789 Oak St",
                "city": "Springfield",
                "state": "IL",
                "zip": "62703"
            },
            "projects": [
                {"name": "Project E", "status": "Completed"},
                {"name": "Project F", "status": "In Progress"}
            ]
        }
    ]

    # Insert multiple documents into the collection
    result = employee_collection.insert_many(employees)
    print(f"Inserted document IDs: {result.inserted_ids}")

    # Fetch and display the documents to verify insertion
    for employee in employee_collection.find():
        print(employee)

except errors.ConnectionFailure as e:
    print(f"Could not connect to MongoDB: {e}")

except errors.PyMongoError as e:
    print(f"An error occurred with PyMongo: {e}")

except Exception as e:
    print(f"An unexpected error occurred: {e}")
