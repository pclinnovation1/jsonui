from pymongo import MongoClient, errors

def get_next_sequence_value(sequence_name):
    """Get the next sequence value for a given sequence name."""
    return db.counters.find_one_and_update(
        {"_id": sequence_name},
        {"$inc": {"sequence_value": 1}},
        return_document=True
    )["sequence_value"]

try:
    # Connect to MongoDB
    client = MongoClient("mongodb://localhost:27017/")
    print("Connected to MongoDB successfully!")

    # Access the database (create it if it doesn't exist)
    db = client.company

    # Create a counter collection if it doesn't exist
    if not db.counters.find_one({"_id": "employee_id"}):
        # Initialize the counter with the highest EmployeeID + 1 from the initial records
        initial_employee_ids = [12345, 12346, 12347, 12348, 12349, 12351, 12352]
        max_employee_id = max(initial_employee_ids)
        db.counters.insert_one({"_id": "employee_id", "sequence_value": max_employee_id})

    # Access the collection (create it if it doesn't exist)
    employee_details_uk_collection = db.HRM_employee_details

    # Sample employee documents
    employees = [
        {
            "EmployeeID": 12345,
            "FirstName": "John",
            "LastName": "Doe",
            "NationalInsuranceNumber": "AB123456C",
            "DateOfBirth": "1990-01-01",
            "Address": "101 Main St, Townsville",
            "StartDate": "2022-01-10",
            "TaxCode": "1250L",
            "AnnualSalary": 30000.0,
            "BankAccountNumber": "12345678",
            "BankSortCode": "10-20-30",
            "Department": "Engineering",
            "EmploymentStatus": "Active",
            "JobTitle": "Engineer",
            "Manager_ID": 12346
        },
        {
            "EmployeeID": 12346,
            "FirstName": "Jane",
            "LastName": "Smith",
            "NationalInsuranceNumber": "AB123456D",
            "DateOfBirth": "1991-02-01",
            "Address": "102 Main St, Townsville",
            "StartDate": "2022-02-20",
            "TaxCode": "1250L",
            "AnnualSalary": 32000.0,
            "BankAccountNumber": "87654321",
            "BankSortCode": "20-30-40",
            "Department": "HR",
            "EmploymentStatus": "Active",
            "JobTitle": "HR Manager",
            "Manager_ID": 12346
        },
        {
            "EmployeeID": 12347,
            "FirstName": "John",
            "LastName": "Doe",
            "NationalInsuranceNumber": "AB123456E",
            "DateOfBirth": "1992-03-01",
            "Address": "103 Main St, Townsville",
            "StartDate": "2022-03-15",
            "TaxCode": "1250L",
            "AnnualSalary": 35000.0,
            "BankAccountNumber": "11223344",
            "BankSortCode": "30-40-50",
            "Department": "Marketing",
            "EmploymentStatus": "Active",
            "JobTitle": "Marketing Director",
            "Manager_ID": 12346
        },
        {
            "EmployeeID": 12348,
            "FirstName": "Jill",
            "LastName": "Hill",
            "NationalInsuranceNumber": "AB123456F",
            "DateOfBirth": "1993-04-01",
            "Address": "104 Main St, Townsville",
            "StartDate": "2022-04-25",
            "TaxCode": "1250L",
            "AnnualSalary": 33000.0,
            "BankAccountNumber": "44332211",
            "BankSortCode": "40-50-60",
            "Department": "Sales",
            "EmploymentStatus": "Active",
            "JobTitle": "Sales Representative",
            "Manager_ID": 12346
        },
        {
            "EmployeeID": 12349,
            "FirstName": "Jack",
            "LastName": "Gill",
            "NationalInsuranceNumber": "AB123456G",
            "DateOfBirth": "1994-05-01",
            "Address": "105 Main St, Townsville",
            "StartDate": "2022-05-30",
            "TaxCode": "1250L",
            "AnnualSalary": 34000.0,
            "BankAccountNumber": "55667788",
            "BankSortCode": "50-60-70",
            "Department": "IT",
            "EmploymentStatus": "Active",
            "JobTitle": "IT Support",
            "Manager_ID": 12346
        },
        {
            "EmployeeID": 12351,
            "FirstName": "Alice",
            "LastName": "Johnson",
            "NationalInsuranceNumber": "JZ123456D",
            "DateOfBirth": "1990-07-15",
            "Address": "45B Elm Street, Anytown, XY12 3AB",
            "StartDate": "2022-11-01",
            "TaxCode": None,
            "AnnualSalary": None,
            "BankAccountNumber": None,
            "BankSortCode": None,
            "Department": "Project Management",
            "EmploymentStatus": None,
            "JobTitle": "Project Manager",
            "Manager_ID": 12346
        },
        {
            "EmployeeID": 12352,
            "FirstName": "Michael",
            "LastName": "Brown",
            "NationalInsuranceNumber": "MN987654C",
            "DateOfBirth": "1985-03-22",
            "Address": "123 Baker Street, London, NW1 6XE",
            "StartDate": "2021-05-15",
            "TaxCode": None,
            "AnnualSalary": None,
            "BankAccountNumber": None,
            "BankSortCode": None,
            "Department": "Engineering",
            "EmploymentStatus": None,
            "JobTitle": "Software Engineer",
            "Manager_ID": 12346
        }
    ]

    # Insert the initial documents into the collection
    result = employee_details_uk_collection.insert_many(employees)
    print(f"Inserted document IDs: {result.inserted_ids}")

    # Function to insert a new employee with auto-incremented EmployeeID
    def insert_new_employee(employee):
        employee["EmployeeID"] = get_next_sequence_value("employee_id")
        result = employee_details_uk_collection.insert_one(employee)
        print(f"Inserted document ID: {result.inserted_id}")

    # Sample new employee document to be inserted
    new_employee = {
        "FirstName": "Sarah",
        "LastName": "Connor",
        "NationalInsuranceNumber": "SC123456H",
        "DateOfBirth": "1980-05-12",
        "Address": "106 Main St, Townsville",
        "StartDate": "2023-01-10",
        "TaxCode": "1250L",
        "AnnualSalary": 45000.0,
        "BankAccountNumber": "99887766",
        "BankSortCode": "60-70-80",
        "Department": "Engineering",
        "EmploymentStatus": "Active",
        "JobTitle": "Lead Engineer",
        "Manager_ID": 12346
    }

    # Insert the new employee
    insert_new_employee(new_employee)

    # Fetch and display the documents to verify insertion
    for employee in employee_details_uk_collection.find():
        print(employee)

except errors.ConnectionFailure as e:
    print(f"Could not connect to MongoDB: {e}")

except errors.PyMongoError as e:
    print(f"An error occurred with PyMongo: {e}")

except Exception as e:
    print(f"An unexpected error occurred: {e}")
