import re
import openai
from datetime import datetime, timedelta
from pymongo import MongoClient
import dateparser
from word2number import w2n

# Set your OpenAI API key here
openai.api_key = 'your-api-key-here'

# Function to interpret the rule and calculate the due date
def calculate_due_date(start_date, rule):
    # Prepare the prompt
    prompt = (f"Given the rule '{rule}' and the starting date {start_date.strftime('%Y-%m-%d')}, "
              "calculate the due date. Return the due date in 'YYYY-MM-DD' format.")

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ]
    )

    # Extract the calculated due date from the response
    due_date_str = response['choices'][0]['message']['content'].strip()
    try:
        due_date = datetime.strptime(due_date_str, '%Y-%m-%d')
    except ValueError:
        raise ValueError(f"Could not parse the due date from the response: {due_date_str}")

    return due_date

# Function to extract numbers and time units from text
def extract_time_units(text):
    pattern = re.compile(r'(\d+|\b(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\b)\s*(day|week|month|year)s?\s*(before|after)?', re.IGNORECASE)
    matches = pattern.findall(text)
    return matches

# Function to parse due date from extracted numbers and time units
def parse_due_date(start_date, time_units):
    due_date = start_date
    for match in time_units:
        number_word, number_digit, unit, direction = match
        number = int(number_word) if number_word.isdigit() else w2n.word_to_num(number_word)
        if unit.lower() == 'day':
            delta = timedelta(days=number)
        elif unit.lower() == 'week':
            delta = timedelta(weeks=number)
        elif unit.lower() == 'month':
            delta = dateparser.parse(f"in {number} months", settings={'RELATIVE_BASE': due_date}) - due_date
        elif unit.lower() == 'year':
            delta = dateparser.parse(f"in {number} years", settings={'RELATIVE_BASE': due_date}) - due_date

        if direction.lower() == 'before':
            due_date -= delta
        else:
            due_date += delta
    return due_date


# Function to save the extracted due dates to MongoDB
def save_to_mongo(dates, db_name, collection_name):
    client = MongoClient("mongodb://localhost:27017/")
    db = client[db_name]
    collection = db[collection_name]
    collection.insert_one({"dates": dates})

# Sample starting date
start_date = datetime(2021, 6, 14)

# Sample rules
rule_scenario_1 = "the Due Date must be set for reassignment in 3 months before"
rule_scenario_2 = "the Due Date must be set for reassignment in 1 year and 6 months"
rule_scenario_3 = "the Due Date must be set for reassignment in 10 days"

# Extract time units from rules
time_units_1 = extract_time_units(rule_scenario_1)
time_units_2 = extract_time_units(rule_scenario_2)
time_units_3 = extract_time_units(rule_scenario_3)

# Parse due dates for different scenarios
due_date_1 = parse_due_date(start_date, time_units_1)
due_date_2 = parse_due_date(start_date, time_units_2)
due_date_3 = parse_due_date(start_date, time_units_3)

print(f"Due Date for Scenario 1: {due_date_1.strftime('%Y-%m-%d')}")
print(f"Due Date for Scenario 2: {due_date_2.strftime('%Y-%m-%d')}")
print(f"Due Date for Scenario 3: {due_date_3.strftime('%Y-%m-%d')}")

# Save parsed due dates to MongoDB
db_name = 'dev1'
collection_name = 'ParsedDueDates'
save_to_mongo([due_date_1.strftime('%Y-%m-%d'), due_date_2.strftime('%Y-%m-%d'), due_date_3.strftime('%Y-%m-%d')], db_name, collection_name)
