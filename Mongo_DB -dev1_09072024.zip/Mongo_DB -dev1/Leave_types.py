from pymongo import MongoClient, errors

def get_next_sequence_value(sequence_name):
    """Get the next sequence value for a given sequence name."""
    return db.counters.find_one_and_update(
        {"_id": sequence_name},
        {"$inc": {"sequence_value": 1}},
        return_document=True
    )["sequence_value"]

try:
    # Connect to MongoDB
    client = MongoClient("mongodb://localhost:27017/")
    print("Connected to MongoDB successfully!")

    # Access the database (create it if it doesn't exist)
    db = client.company

    # Create a counter collection if it doesn't exist
    if not db.counters.find_one({"_id": "leave_type_id"}):
        db.counters.insert_one({"_id": "leave_type_id", "sequence_value": 0})

    # Sample Leave Types data
    leave_types = [
        {"Leave_Type_Name": "Annual Vacation"},
        {"Leave_Type_Name": "Sick Leave"},
        {"Leave_Type_Name": "Maternity Leave"},
        {"Leave_Type_Name": "Paternity Leave"},
        {"Leave_Type_Name": "Unpaid Leave"},
        {"Leave_Type_Name": "Maternity Leave"},
        {"Leave_Type_Name": "Adoption Leave"}
    ]

    # Insert each leave type with an auto-incremented Leave_Type_ID
    for leave_type in leave_types:
        leave_type["Leave_Type_ID"] = get_next_sequence_value("leave_type_id")
        db.leave_types.insert_one(leave_type)
        print(f"Inserted Leave_Type_ID: {leave_type['Leave_Type_ID']} - {leave_type['Leave_Type_Name']}")

    # Fetch and display the documents to verify insertion
    for leave_type in db.leave_types.find():
        print(leave_type)

except errors.ConnectionFailure as e:
    print(f"Could not connect to MongoDB: {e}")

except errors.PyMongoError as e:
    print(f"An error occurred with PyMongo: {e}")

except Exception as e:
    print(f"An unexpected error occurred: {e}")
