from pymongo import MongoClient
from datetime import datetime, timedelta

client = MongoClient('mongodb://localhost:27017/')
db = client['dev1']
collection = db['HRM_employee_details']

# Example course mapping
course_mapping = {
    'DEV123': {
        'Software Developer': 'Advanced Python Course',
        'Senior Developer': 'Advanced Software Development',
        'default': 'General Development Course'
    },
    'default': 'General Course'
}

def assign_courses():
    now = datetime.now()
    twenty_four_hours_ago = now - timedelta(hours=24)
    
    employees = list(collection.find({'Effective_Start_Date': {'$gte': twenty_four_hours_ago}}))
    print(employees)

    for employee in employees:
        if employee.get('Effective_End_Date') is not None:
            print('Effective_End_Date1')
            continue

        person_number = employee['Person_Number']
        print(person_number)
        old_record = collection.find_one({'Person_Number': person_number, 'Effective_End_Date': {'$lt': now}})
        print(old_record)

        if old_record:
            new_record = collection.find_one({'Person_Number': person_number, 'Effective_Start_Date': {'$eq': employee['Effective_Start_Date']}})
            if new_record:
                old_job_title = old_record['Job_Title']
                old_job_code = old_record['Job_Code']
                new_job_title = new_record['Job_Title']
                new_job_code = new_record['Job_Code']

                if old_job_title != new_job_title and old_job_code != new_job_code:
                    course_name = get_course(new_job_code, new_job_title)
                    print('1',course_name)
                elif old_job_title != new_job_title:
                    course_name = get_course(new_job_code, new_job_title)
                    print('2',course_name)
                elif old_job_code != new_job_code:
                    course_name = get_course(new_job_code, new_job_title)
                    print('3',course_name)
                else:
                    course_name = None
                    print('4',course_name)

                if course_name:
                    assign_course_to_employee(person_number, course_name)

    print('Courses assigned based on changes')

def get_course(job_code, job_title):
    if job_code and job_title:
        return course_mapping.get(job_code, {}).get(job_title, course_mapping[job_code].get('default', course_mapping['default']))
    elif job_code:
        return course_mapping.get(job_code, {}).get('default', course_mapping['default'])
    elif job_title:
        for code_courses in course_mapping.values():
            if isinstance(code_courses, dict):
                course_name = code_courses.get(job_title)
                if course_name:
                    return course_name
        return course_mapping['default']
    return None

def assign_course_to_employee(person_number, course_name):
    # Logic to assign the course to the employee (e.g., insert a record in a courses collection)
    courses_collection = db['EmployeeCourses']
    courses_collection.insert_one({
        'Person_Number': person_number,
        'Course_Name': course_name,
        'Assigned_Date': datetime.now().strftime('%Y-%m-%d'),
        'timesamp': datetime.now()
    })

if __name__ == '__main__':
    assign_courses()
