from flask import Flask, request, jsonify
from pymongo import MongoClient

app = Flask(__name__)

# MongoDB client setup
client = MongoClient('mongodb://PCL_Interns_admin:PCLinterns2050admin@172.191.245.199:27017/dev1')  # Adjust the connection string as necessary
db = client['dev1']  # Database name
eligibility_profiles_collection = db['EligibilityProfiles']  # Collection name

# Endpoint to create and store an eligibility profile
@app.route('/create_eligibility_profile', methods=['POST'])
def create_eligibility_profile():
    data = request.json
    profile_name = data.get('Create Participant Profile', {}).get('Eligibility Profile Definition', {}).get('Name')
    
    if not profile_name:
        return jsonify({"error": "Eligibility Profile Name is required"}), 400

    existing_profile = eligibility_profiles_collection.find_one({"Create Participant Profile.Eligibility Profile Definition.Name": profile_name})
    
    if existing_profile:
        return jsonify({"error": "Eligibility Profile with this name already exists"}), 400

    eligibility_profiles_collection.insert_one(data)
    return jsonify({"message": f"Eligibility Profile '{profile_name}' created successfully"}), 200

if __name__ == '__main__':
    app.run(debug=True)
