import unittest
import requests

class TestEnrollmentAndWithdrawal(unittest.TestCase):

    BASE_URL = "http://localhost:5000"

    def setUp(self):
        # Setting up the data needed for tests
        self.enroll_url = f"{self.BASE_URL}/enroll"
        self.withdraw_url = f"{self.BASE_URL}/withdraw"
        self.common_payload = {
            "Offering Title": "Advanced GPT Techniques",
            "Enrollment Date": "2024-06-17"
        }

    # Enroll Endpoint Test Cases

    def test_successful_enrollment(self):
        payload = {**self.common_payload, "Person Name": "Jane Smith"}
        response = requests.post(self.enroll_url, json=payload)
        self.assertEqual(response.status_code, 200)
        self.assertIn("Employee enrolled successfully", response.json()["message"])

    def test_enrollment_to_waitlist(self):
        payload = {**self.common_payload, "Person Name": "John Doe"}
        response = requests.post(self.enroll_url, json=payload)
        self.assertEqual(response.status_code, 200)
        self.assertIn("Employee added to waitlist", response.json()["message"])

    def test_invalid_input_data_enroll(self):
        payload = {"Person Name": "Jane Smith", "Enrollment Date": "2024-06-17"}
        response = requests.post(self.enroll_url, json=payload)
        self.assertEqual(response.status_code, 400)
        self.assertIn("Invalid input data", response.json()["error"])

    def test_multiple_offerings_with_same_title_enroll(self):
        payload = {"Offering Title": "Advanced GPT Techniques", "Person Name": "Jane Smith", "Enrollment Date": "2024-06-17"}
        response = requests.post(self.enroll_url, json=payload)
        self.assertEqual(response.status_code, 400)
        self.assertIn("Please specify the Offering Number", response.json()["error"])

    def test_offering_not_found_enroll(self):
        payload = {"Offering Title": "Non-existent Course", "Person Name": "Jane Smith", "Enrollment Date": "2024-06-17"}
        response = requests.post(self.enroll_url, json=payload)
        self.assertEqual(response.status_code, 404)
        self.assertIn("Offering not found", response.json()["error"])

    def test_offering_format_not_instructor_led_enroll(self):
        payload = {"Offering Title": "Online AI Techniques", "Person Name": "Jane Smith", "Enrollment Date": "2024-06-17"}
        response = requests.post(self.enroll_url, json=payload)
        self.assertEqual(response.status_code, 400)
        self.assertIn("not Instructor-Led", response.json()["error"])

    def test_invalid_person_name_format_enroll(self):
        payload = {"Offering Title": "Advanced GPT Techniques", "Person Name": "SingleName", "Enrollment Date": "2024-06-17"}
        response = requests.post(self.enroll_url, json=payload)
        self.assertEqual(response.status_code, 400)
        self.assertIn("Invalid Person Name format", response.json()["error"])

    def test_employee_not_found_enroll(self):
        payload = {"Offering Title": "Advanced GPT Techniques", "Person Name": "Non Existent", "Enrollment Date": "2024-06-17"}
        response = requests.post(self.enroll_url, json=payload)
        self.assertEqual(response.status_code, 404)
        self.assertIn("Employee not found", response.json()["error"])

    # Withdraw Endpoint Test Cases

    def test_successful_withdrawal(self):
        payload = {"Offering Title": "Advanced GPT Techniques", "Person Name": "Jane Smith"}
        response = requests.post(self.withdraw_url, json=payload)
        self.assertEqual(response.status_code, 200)
        self.assertIn("Employee withdrawn successfully", response.json()["message"])

    def test_already_withdrawn(self):
        payload = {"Offering Title": "Advanced GPT Techniques", "Person Name": "Jane Smith"}
        response = requests.post(self.withdraw_url, json=payload)
        self.assertEqual(response.status_code, 400)
        self.assertIn("Employee has already withdrawn from the course", response.json()["error"])

    def test_invalid_input_data_withdraw(self):
        payload = {"Person Name": "Jane Smith"}
        response = requests.post(self.withdraw_url, json=payload)
        self.assertEqual(response.status_code, 400)
        self.assertIn("Invalid input data", response.json()["error"])

    def test_multiple_offerings_with_same_title_withdraw(self):
        payload = {"Offering Title": "Advanced GPT Techniques", "Person Name": "Jane Smith"}
        response = requests.post(self.withdraw_url, json=payload)
        self.assertEqual(response.status_code, 400)
        self.assertIn("Please specify the Offering Number", response.json()["error"])

    def test_offering_not_found_withdraw(self):
        payload = {"Offering Title": "Non-existent Course", "Person Name": "Jane Smith"}
        response = requests.post(self.withdraw_url, json=payload)
        self.assertEqual(response.status_code, 404)
        self.assertIn("Offering not found", response.json()["error"])

    def test_offering_format_not_instructor_led_withdraw(self):
        payload = {"Offering Title": "Online AI Techniques", "Person Name": "Jane Smith"}
        response = requests.post(self.withdraw_url, json=payload)
        self.assertEqual(response.status_code, 400)
        self.assertIn("not Instructor-Led", response.json()["error"])

    def test_invalid_person_name_format_withdraw(self):
        payload = {"Offering Title": "Advanced GPT Techniques", "Person Name": "SingleName"}
        response = requests.post(self.withdraw_url, json=payload)
        self.assertEqual(response.status_code, 400)
        self.assertIn("Invalid Person Name format", response.json()["error"])

    def test_employee_not_found_withdraw(self):
        payload = {"Offering Title": "Advanced GPT Techniques", "Person Name": "Non Existent"}
        response = requests.post(self.withdraw_url, json=payload)
        self.assertEqual(response.status_code, 404)
        self.assertIn("Employee not found", response.json()["error"])

    def test_employee_not_enrolled_withdraw(self):
        payload = {"Offering Title": "Advanced GPT Techniques", "Person Name": "John Doe"}
        response = requests.post(self.withdraw_url, json=payload)
        self.assertEqual(response.status_code, 404)
        self.assertIn("Employee not enrolled in the specified offering", response.json()["error"])

if __name__ == "__main__":
    unittest.main()
