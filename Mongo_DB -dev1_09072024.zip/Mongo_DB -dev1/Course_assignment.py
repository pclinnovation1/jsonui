import pandas as pd
from pymongo import MongoClient
from datetime import datetime, timedelta

# Define the MongoDB connection and database
def get_mongo_connection():
    return MongoClient("mongodb://localhost:27017/")

# Function to convert date to ISO format string
def to_iso_date(date):
    return date.isoformat()

# Function to create sample course assignments collection using courses from the provided list
def create_course_assignments_collection(db_name, collection_name):
    # Sample employees
    sample_employees = [
        "Alice Johnson", "Bob Smith", "Charlie Davis", "Diana Prince", "Eve Adams",
        "Frank Miller", "Grace Lee", "Hank Green", "Ivy White", "Jack Black",
        "Kevin Brown", "Laura Clark", "Mike Davis"
    ]
    
    # List of courses from the provided image
    course_names = [
        "Anti Social Behaviour Target Audience TBC", "Autism Awareness Tier 1", "Domestic Abuse", 
        "Infection Control", "Learning Disability Tier 1", "Legionella & Water Safety",
        "Moving and Positioning of People", "Professional Boundaries", 
        "Prevention & Diffusion of Violence", "Prevention & Diffusion of Violence Refresher",
        "Safe Handling of Medication", "Sharps", "Support Planning & Risk Assessment"
    ]
    
    # Ensure we have the same number of employees as courses
    assert len(course_names) == len(sample_employees), "The number of courses and employees should be equal."

    # Create assignment data by combining sample data with course names
    data = []
    for i, course_name in enumerate(course_names):
        person = sample_employees[i]
        date_assignment = (datetime(2021, 1, 15) + timedelta(days=i * 30)).date()  # Different assignment dates
        due_date = date_assignment + timedelta(days=90)
        completion_date = due_date - timedelta(days=5)
        data.append({
            "Course_Name": course_name,
            "Person": person,
            "Date_Assignment": to_iso_date(date_assignment),
            "Due_Date": to_iso_date(due_date),
            "Completion_Date": to_iso_date(completion_date),
            "timestamp" : datetime.now()
        })

    # Connect to MongoDB
    db = get_mongo_connection()[db_name]
    collection = db[collection_name]

    # Insert sample data into the collection
    collection.insert_many(data)

# Example usage
db_name = 'dev1'
collection_name = 'LRN_course_assignment'
create_course_assignments_collection(db_name, collection_name)
