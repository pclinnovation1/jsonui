import unittest
from Leave_acc_3 import calculate_leave_accrual, calculate_additional_leave_rate, get_unionized_leave_accrual, calculate_seniority_level

class TestLeaveAccrual(unittest.TestCase):

    def test_full_time_annual_leave_day_shift_less_than_1_year(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "full-time"
        leave_type = "annual_leave"
        gender = "male"
        fte = 1.0
        shift_type = "day"
        seniority_level = "1-5"
        union_member = False
        additional_leave_rate = calculate_additional_leave_rate(seniority_level, shift_type)

        expected_output = (2.5 + 0.0) * 3

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_part_time_study_leave_night_shift_seniority_6_10_unionized(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "part-time"
        leave_type = "study_leave"
        gender = "male"
        fte = 0.5
        shift_type = "night"
        seniority_level = "6-10"
        union_member = True
        additional_leave_rate = calculate_additional_leave_rate(seniority_level, shift_type) + get_unionized_leave_accrual(employee_type, fte)

        expected_output = (1.0 * fte + additional_leave_rate) * 3

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_contractor_paternity_leave_rotating_shift_10_years_not_unionized(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "contractor"
        leave_type = "paternity_leave"
        gender = "male"
        fte = 1.0
        shift_type = "rotating"
        seniority_level = "10+"
        union_member = False
        additional_leave_rate = calculate_additional_leave_rate(seniority_level, shift_type)

        expected_output = (0.25 + 0.5 + 0.25) * 3

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_full_time_adoption_leave_night_shift_1_5_years_unionized(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "full-time"
        leave_type = "adoption_leave"
        gender = "female"
        fte = 1.0
        shift_type = "night"
        seniority_level = "1-5"
        union_member = True
        additional_leave_rate = calculate_additional_leave_rate(seniority_level, shift_type) + get_unionized_leave_accrual(employee_type, fte)

        expected_output = (1.5 + 0.0 + 0.5 + 3.0) * 3

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_part_time_sick_leave_day_shift_6_10_years_not_unionized(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "part-time"
        leave_type = "sick_leave"
        gender = "male"
        fte = 0.75
        shift_type = "day"
        seniority_level = "6-10"
        union_member = False
        additional_leave_rate = calculate_additional_leave_rate(seniority_level, shift_type)

        expected_output = (1.0 * 0.75 + 0.25 + 0.0) * 3

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_full_time_compassionate_leave_night_shift_10_years_unionized(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "full-time"
        leave_type = "compassionate_leave"
        gender = "male"
        fte = 1.0
        shift_type = "night"
        seniority_level = "10+"
        union_member = True
        additional_leave_rate = calculate_additional_leave_rate(seniority_level, shift_type) + get_unionized_leave_accrual(employee_type, fte)

        expected_output = (0.5 + 0.5 + 0.5 + 3.0) * 3

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_contractor_bereavement_leave_day_shift_less_than_1_year_not_unionized(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "contractor"
        leave_type = "bereavement_leave"
        gender = "male"
        fte = 1.0
        shift_type = "day"
        seniority_level = "1-5"
        union_member = False
        additional_leave_rate = calculate_additional_leave_rate(seniority_level, shift_type)

        expected_output = (0.1 + 0.0 + 0.0) * 3

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_part_time_shared_parental_leave_rotating_shift_seniority_6_10_unionized(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "part-time"
        leave_type = "shared_parental_leave"
        gender = "male"
        fte = 0.75
        shift_type = "rotating"
        seniority_level = "6-10"
        union_member = True

        additional_leave_rate = calculate_additional_leave_rate(seniority_level, shift_type)
        unionized_leave_accrual = get_unionized_leave_accrual(employee_type, fte)

        additional_leave_rate += unionized_leave_accrual

        expected_output = (1.5 * 0.75 + 0.5 + unionized_leave_accrual) * 3

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)


    def test_full_time_sabbatical_leave_night_shift_10_years_unionized(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "full-time"
        leave_type = "sabbatical_leave"
        gender = "male"
        fte = 1.0
        shift_type = "night"
        seniority_level = "10+"
        union_member = True
        additional_leave_rate = calculate_additional_leave_rate(seniority_level, shift_type) + get_unionized_leave_accrual(employee_type, fte)

        expected_output = (0.5 + 0.5 + 0.5 + 3.0) * 3

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_part_time_parental_leave_day_shift_less_than_1_year_not_unionized(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "part-time"
        leave_type = "parental_leave"
        gender = "male"
        fte = 0.75
        shift_type = "day"
        seniority_level = "1-5"
        union_member = False
        additional_leave_rate = calculate_additional_leave_rate(seniority_level, shift_type)

        expected_output = (1.0 * 0.75 + 0.0 + 0.0) * 3

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

if __name__ == '__main__':
    unittest.main()
