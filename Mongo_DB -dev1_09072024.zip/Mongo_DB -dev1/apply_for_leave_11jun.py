from flask import Flask, request, jsonify
from pymongo import MongoClient
from datetime import datetime, timedelta
from leave_accrual_config import leave_accrual_config
from flask import Flask, request, jsonify
from pymongo import MongoClient, errors
import logging
import pymongo
from datetime import datetime
from collections import Counter

app = Flask(__name__)

# MongoDB connection setup
client = MongoClient("mongodb://localhost:27017/")
db = client["dev1"]
employees_collection = db["HRM_employee_details"]
leave_accruals_collection = db["ABS_leave_balance"]
leave_details_collection = db["ABS_daily_leave_details"]
leave_applications_collection = db["ABS_leave_application"]

@app.route('/applyForLeave', methods=['POST'])
def submit_leave_application():
    data = request.json
    if not data:
        return jsonify({"error": "Invalid data"}), 400

    # Convert date strings to date objects
    try:
        if "Start_Date" in data:
            start_date = datetime.strptime(data["Start_Date"], "%Y-%m-%d")
        if "End_Date" in data:
            end_date = datetime.strptime(data["End_Date"], "%Y-%m-%d")
    except ValueError as e:
        logging.error(f"Date conversion error: {e}")
        return jsonify({"error": "Invalid date format"}), 400

    # Split employee name into first and last names
    employee_name = data.get("Employee_Name")
    if employee_name:
        name_parts = employee_name.split()
        if len(name_parts) < 2:
            return jsonify({"error": "Invalid Employee_Name. Please provide both first and last names."}), 400
        first_name = name_parts[0]
        last_name = name_parts[1]
    else:
        return jsonify({"error": "Employee_Name is required"}), 400

    # Fetch employee details
    employee_data = employees_collection.find_one({"First_Name": first_name, "Last_Name": last_name})
    if not employee_data:
        return jsonify({"error": "Employee not found"}), 404

    person_number = employee_data["Person_Number"]
    person_name = employee_data["First_Name"] + " " + employee_data["Last_Name"]

    # Insert data into the ABS_leave_application collection
    try:
        leave_applications_collection.insert_one({
            "Person_Number": person_number,
            "Employee_Name": employee_name,
            "Leave_Type": data.get("Leave_Type"),
            "Start_Date": data.get("Start_Date"),
            "End_Date": data.get("End_Date"),
            "Duration": data.get("Duration"),
            "Reason_for_Absence": data.get("Reason_for_Absence"),
            "Status": data.get("Status"),
            "Manager": data.get("Manager"),
            "Timestamp": datetime.now()
        })
    except errors.PyMongoError as e:
        logging.error(f"Error inserting data: {e}")
        return jsonify({"error": f"Error inserting data: {e}"}), 500

    # Insert entries into the ABS_daily_leave_details collection for each day of absence
    current_date = start_date
    while current_date <= end_date:
        leave_details_collection.insert_one({
            "person_number": person_number,
            "person_name": person_name,
            "leave_type": data.get("Leave_Type", "absence"),
            "date": current_date.strftime("%Y-%m-%d"),
            "type": "Absence",
            "days": -1,
            "timestamp": datetime.now()
        })
        current_date += timedelta(days=1)

    logging.info("Leave application submitted successfully")
    return jsonify({"message": "Leave application submitted successfully"}), 200

if __name__ == "__main__":
    app.run(debug=True)