from flask import Flask, request, jsonify
from pymongo import MongoClient
from datetime import datetime

app = Flask(__name__)

# Connect to MongoDB
client = MongoClient('mongodb://dev1_user:dev1_pass@172.191.245.199:27017/dev1')
db = client['dev1']

@app.route('/enroll', methods=['POST'])
def enroll_employee():
    data = request.get_json()
    offering_title = data.get("offering_title")
    enrollment_date = data.get("enrollment_date")
    offering_number = data.get("offering_number")
    person_name = data.get("person_name")

    if not offering_title or not person_name or not enrollment_date:
        return jsonify({"error": "Invalid input data"}), 400

    # Find offerings by title
    offerings = list(db['LRN_course_offering'].find({"general_information.basic_information.title": offering_title}))
    print('offering1',offerings)

    if len(offerings) > 1 and not offering_number:
        multiple_offerings = []
        for offering in offerings:
            multiple_offerings.append({
                "offering_number": offering["offering_number"],
                "offering_title": offering["general_information"]["basic_information"]["title"],
                "offering_format": offering["additional_attributes"]["offered_format"],
                "active_learners": offering["statistics"]["active_learners"],
                "maximum_capacity": offering["capacity_rules"]["maximum_capacity"]
            })
        return jsonify({
            "error": "There are multiple offerings with this title. Please specify the Offering Number.",
            "offerings": multiple_offerings
        }), 400

    if not offerings:
        return jsonify({"error": "Offering not found."}), 404

    # Use the Offering Number if provided
    if offering_number:
        offering = db['LRN_Course_Offering'].find_one({"offering_number": offering_number})
    else:
        offering = offerings[0]

    # Check if offering was found
    if offering is None:
        return jsonify({"error": f"No course offering found with Offering Number '{offering_number}'."}), 400

    # Check if the course is Instructor-Led
    if offering["general_information"]["offering_details"]["facilitator_type"] != "Instructor-led":
        return jsonify({"error": f"The course offering with title '{offering_title}' is not Instructor-Led."}), 400

    # Split Person Name into First Name and Last Name
    try:
        first_name, last_name = person_name.split(" ", 1)
    except ValueError:
        return jsonify({"error": "Invalid Person Name format"}), 400

    # Find Person Number from HRM_employee_details
    employee = db['HRM_employee_details'].find_one({"first_name": first_name, "last_name": last_name})
    if not employee:
        return jsonify({"error": "Employee not found"}), 404

    person_number = employee["person_number"]

    # Check if the employee is already enrolled or has withdrawn from the course offering
    existing_enrollment = db['LRN_employee_offering_detail'].find_one({
        "person_name": person_name,
        "offering_number": offering["offering_number"],
        "current_status": {"$in": ["in-progress", "completed", "withdrawn"]}
    })

    if existing_enrollment:
        current_status = existing_enrollment["current_status"]
        return jsonify({"error": f"Employee is already enrolled in this course offering with status '{current_status}'."}), 400

    # Count the number of active learners for this offering number
    active_learners_count = db['LRN_employee_offering_detail'].count_documents({
        "offering_number": offering["offering_number"], "current_status": "in-progress"
    })

    # Enroll or add to waitlist based on availability
    if active_learners_count < offering["capacity_rules"]["maximum_capacity"]:
        # Enroll the employee
        enrollment_data = {
            "person_name": person_name,
            "enrollment_date": enrollment_date,
            "enrolled_status": "in-progress",
            "current_status": "in-progress",
            "last_update_timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "offering_name": offering["general_information"]["basic_information"]["title"]
        }
        db['LRN_employee_offering_detail'].insert_one(enrollment_data)
        return jsonify({"message": "Employee enrolled successfully."}), 200
    else:
        # Calculate next waitlist number
        waitlist_count = db['LRN_employee_offering_detail'].count_documents({
            "offering_number": offering["offering_number"], "current_status": "waitlist"
        })
        waitlist_number = waitlist_count + 1

        # Add to waitlist
        waitlist_data = {
            "person_name": person_name,
            "enrollment_date": enrollment_date,
            "enrolled_status": f"waitlist {waitlist_number}",
            "current_status": "waitlist",
            "waitlist_number": waitlist_number,
            "last_update_timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "offering_name": offering["general_information"]["basic_information"]["title"]
        }
        db['LRN_employee_offering_detail'].insert_one(waitlist_data)
        return jsonify({
            "message": f"Seats are full. Employee added to waitlist with waitlist number {waitlist_number}."
        }), 200

@app.route('/withdraw', methods=['POST'])
def withdraw_employee():
    data = request.get_json()
    offering_title = data.get("offering_title")
    offering_number = data.get("offering_number")
    person_name = data.get("person_name")

    if not offering_title or not person_name:
        return jsonify({"error": "Invalid input data"}), 400

    # Find offerings by title
    offerings = list(db['LRN_course_offering'].find({"general_information.basic_information.title": offering_title}))
    
    if len(offerings) > 1 and not offering_number:
        multiple_offerings = []
        for offering in offerings:
            multiple_offerings.append({
                "offering_number": offering["offering_number"],
                "offering_format": offering["additional_attributes"]["offered_format"],
                "active_learners": offering["statistics"]["active_learners"],
                "maximum_capacity": offering["capacity_rules"]["maximum_capacity"]
            })
        return jsonify({
            "error": "There are multiple offerings with this title. Please specify the Offering Number.",
            "offerings": multiple_offerings
        }), 400

    if not offerings:
        return jsonify({"error": "Offering not found."}), 404

    # Use the Offering Number if provided
    if offering_number:
        offering = db['LRN_course_offering'].find_one({"offering_number": offering_number})
    else:
        offering = offerings[0]

    # Check if the course is Instructor-Led
    if offering["general_information"]["offering_details"]["facilitator_type"] != "Instructor-led":
        return jsonify({"error": f"The course offering with title '{offering_title}' is not Instructor-Led."}), 400

    # Split Person Name into First Name and Last Name
    try:
        first_name, last_name = person_name.split(" ", 1)
    except ValueError:
        return jsonify({"error": "Invalid Person Name format"}), 400

    # Find Person Number from HRM_employee_details
    employee = db['HRM_employee_details'].find_one({"first_name": first_name, "last_name": last_name})
    if not employee:
        return jsonify({"error": "Employee not found"}), 404

    person_number = employee["person_number"]

    offering_id = offering["_id"]
    enrolled_employee = db['LRN_employee_offering_detail'].find_one(
        {"offering_number": offering["offering_number"], "person_name": person_name}
    )
    if enrolled_employee:
        if enrolled_employee["current_status"] == "withdrawn":
            return jsonify({"error": "Employee has already withdrawn from the course."}), 400

        result = db['LRN_employee_offering_detail'].update_one(
    {
        "offering_number": offering["offering_number"],
        "person_name": person_name,
        "current_status": {"$in": ["in-progress", "waitlist"]}
    },
    {"$set": {"current_status": "withdrawn"}}
    )
        if result.matched_count > 0:
            # Check for waitlisted employees
            waitlisted_employee = db['LRN_employee_offering_detail'].find_one(
                {"offering_number": offering["offering_number"], "current_status": "waitlist"},
                sort=[("waitlist_number", 1)]
            )

            if waitlisted_employee:
                # Remove from waitlist and add to enrolled
                db['LRN_employee_offering_detail'].update_one(
                    {"_id": waitlisted_employee["_id"]},
                    {"$set": {"current_status": "in-progress"}, "$unset": {"waitlist_number": ""}}
                )

                # Decrease waitlist numbers for remaining waitlisted employees
                db['LRN_employee_offering_detail'].update_many(
                    {"offering_number": offering["offering_number"], "waitlist_number": {"$gt": waitlisted_employee["waitlist_number"]}},
                    {"$inc": {"waitlist_number": -1}}
                )

            return jsonify({"message": "Employee withdrawn successfully and waitlist updated."}), 200
        else:
            return jsonify({"error": "Employee not enrolled in the specified offering."}), 404
    else:
        return jsonify({"error": "Employee not enrolled in the specified offering."}), 404

if __name__ == '__main__':
    app.run(debug=True)
