# openai_integration.py
import openai
from openai import OpenAI
import logging
import os

# Set up logging
logger = logging.getLogger(__name__)

client = OpenAI(api_key='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')

class ConversationState:
    def __init__(self):
        self.messages = []

    def add_message(self, role, content):
        self.messages.append({"role": role, "content": content})

    def get_messages(self):
        return self.messages

def query_openai_chat(message, conversation_state, token_limit):
    try:
        if len(conversation_state.get_messages()) >= token_limit:
            logger.error("Token limit exceeded")
            return "Token limit exceeded. Please try again later.", None

        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=conversation_state.get_messages() + [{"role": "user", "content": message}]
        )
        conversation_state.add_message("user", message)
        conversation_state.add_message("system", response.choices[0].message.content)
        logger.info("OpenAI chat queried successfully")
        return response.choices[0].message.content, response
    except client.error.OpenAIError as e:
        logger.exception("OpenAI API error")
        return "I encountered an error while processing your request.", None

def convert_text_to_speech(text):
    try:
        speech_response = client.audio.speech.create(
            model="tts-1",
            voice="nova",
            input=text
        )
        logger.info("Text to speech conversion successful")
        return speech_response.content
    except Exception as e:
        logger.exception("Failed to convert text to speech")
        return None
    
def transcribe_audio(filepath):
    try:
        with open(filepath, 'rb') as audio:
            response = client.audio.transcriptions.create(
                model="whisper-1",
                file=audio,
                language="en"
            )
        os.remove(filepath)  # Clean up the file after processing
        # Assuming response has an attribute 'text'
        transcription = getattr(response, 'text', 'No transcription available')
        logger.info(f"Transcription successful: {transcription}")
        return transcription
    except Exception as e:
        logger.exception("Failed to process audio file for transcription")
        return None

