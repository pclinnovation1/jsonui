# import pandas as pd
# from pymongo import MongoClient

# # Define the MongoDB connection and database
# def get_mongo_connection():
#     return MongoClient("mongodb://localhost:27017/")

# # Function to create course rules collection
# def create_course_rules_collection(excel_path, sheet_name, db_name, collection_name):
#     # Read the Excel file from row 31 to row 43
#     df = pd.read_excel(excel_path, sheet_name=sheet_name, skiprows=range(1, 30), nrows=13)

#     # Print column names to inspect them
#     print("Column names:", df.columns.tolist())

#     # Connect to MongoDB
#     db = get_mongo_connection()[db_name]
#     collection = db[collection_name]

#     # Insert course rules into the collection
#     for index, row in df.iterrows():
#         course_name = row['Course Name']
#         required_voluntary = row['Required/Voluntary']
#         rule1 = row['Rule1']
#         rule2 = row['Rule2']
#         rule3 = row['Rule 3']
#         rule4 = row['Rule 4']

#         collection.insert_one({
#             "Course_Name": course_name,
#             "Required_Voluntary": required_voluntary,
#             "Rule1": rule1,
#             "Rule2": rule2,
#             "Rule3": rule3,
#             "Rule4": rule4
#         })

# # Example usage
# excel_path = r'C:\Users\Sajal\Downloads\Learning Config Book 2.xlsx'
# sheet_name = 'Renewals'  # Sheet containing the course rules
# db_name = 'dev1'
# collection_name = 'LRN_course_rule'

# create_course_rules_collection(excel_path, sheet_name, db_name, collection_name)


import pandas as pd
from pymongo import MongoClient

# Define the MongoDB connection and database
def get_mongo_connection():
    return MongoClient("mongodb://localhost:27017/")

# Function to create course rules collection
def create_course_rules_collection(excel_path, sheet_name, db_name, collection_name):
    # Read the Excel file from the specified sheet
    df = pd.read_excel(excel_path, sheet_name=sheet_name)

    # Print column names to inspect them
    print("Column names:", df.columns.tolist())

    # Filter out rows where 'Rule1' is empty
    df = df[df['Rule1'].notna()]

    # Connect to MongoDB
    db = get_mongo_connection()[db_name]
    collection = db[collection_name]

    # Insert course rules into the collection
    for index, row in df.iterrows():
        # Construct document dict using all available columns, handling potential NaN with fillna or default value
        document = {col: row[col] if pd.notna(row[col]) else None for col in df.columns}

        collection.insert_one(document)

    print(f"Data successfully loaded into MongoDB from {sheet_name}.")

# Example usage
excel_path = r'C:\Users\Sajal\Downloads\Learning Config Book 2.xlsx'  # Update with the correct path
sheet_name = 'Renewals'  # Sheet containing the course rules
db_name = 'dev1'
collection_name = 'LRN_course_rule'

create_course_rules_collection(excel_path, sheet_name, db_name, collection_name)
