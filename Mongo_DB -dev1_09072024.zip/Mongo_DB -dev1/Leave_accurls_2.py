# from pymongo import MongoClient
# from datetime import datetime

# # MongoDB connection setup
# client = MongoClient("mongodb://localhost:27017/")
# db = client["dev1"]
# employees_collection = db["HRM_employee_details"]
# leave_accruals_collection = db["leave_accruals"]

# def calculate_leave_accrual(start_date, end_date, employee_type, leave_type):
#     """
#     Calculate the total accrued leave based on start date, end date, employee type, and leave type.
#     """
#     # Define leave accrual rates based on leave type and employee type
#     leave_accrual_rates = {
#         "annual_leave": {
#             "full-time": 2.5,  # days per month
#             "part-time": 1.25,
#             "contractor": 0.5
#         },
#         "sick_leave": {
#             "full-time": 1.0,
#             "part-time": 0.5,
#             "contractor": 0.25
#         },
#         "maternity_leave": {
#             "full-time": 1.5,
#             "part-time": 0.75,
#             "contractor": 0.5
#         },
#         "paternity_leave": {
#             "full-time": 1.0,
#             "part-time": 0.5,
#             "contractor": 0.25
#         },
#         "adoption_leave": {
#             "full-time": 1.5,
#             "part-time": 0.75,
#             "contractor": 0.5
#         },
#         "bereavement_leave": {
#             "full-time": 0.5,
#             "part-time": 0.25,
#             "contractor": 0.1
#         },
#         "unpaid_leave": {
#             "full-time": 0.0,
#             "part-time": 0.0,
#             "contractor": 0.0
#         },
#         "parental_leave": {
#             "full-time": 1.0,
#             "part-time": 0.5,
#             "contractor": 0.25
#         },
#         "compassionate_leave": {
#             "full-time": 0.5,
#             "part-time": 0.25,
#             "contractor": 0.1
#         },
#         "shared_parental_leave": {
#             "full-time": 1.5,
#             "part-time": 0.75,
#             "contractor": 0.5
#         }
#         # Add other leave types and rates here
#     }

#     # Check if leave type and employee type are valid
#     if leave_type not in leave_accrual_rates or employee_type not in leave_accrual_rates[leave_type]:
#         return {"total_accrued_leave": 0}  # Return 0 if leave type or employee type is invalid

#     # Get the accrual rate for the given leave type and employee type
#     accrual_rate = leave_accrual_rates[leave_type][employee_type]

#     # Calculate the number of months between start_date and end_date
#     start_date = datetime.strptime(start_date, "%Y-%m-%d")
#     end_date = datetime.strptime(end_date, "%Y-%m-%d")
#     months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)

#     # Calculate total accrued leave
#     total_accrued_leave = months * accrual_rate

#     return {"total_accrued_leave": total_accrued_leave}

# # Function to calculate leave accruals for all employees
# def calculate_leave_accruals():
#     # Fetch all distinct person numbers from the HRM_employee_details collection
#     person_numbers = employees_collection.distinct("Person_Number")

#     for person_number in person_numbers:
#         # Fetch employee data by person number
#         employee_data = employees_collection.find_one({"Person_Number": person_number})

#         # Extract relevant data for leave accrual calculation
#         start_date = datetime.strptime(employee_data["Original_Start_Date"], "%Y-%m-%d")
#         hire_date = datetime.strptime(employee_data["Hire_Date"], "%Y-%m-%d")
#         current_year = datetime.now().year
#         financial_year_start = datetime(current_year, 4, 6)
#         start_date = max(start_date, hire_date, financial_year_start).strftime("%Y-%m-%d")
        
#         # Set end date to June 15, 2024
#         end_date = "2024-05-31"
        
#         employee_type = employee_data["Employment_Type"]

#         # Perform leave accrual calculation
#         for leave_type in ["annual_leave"]:
#             accrual_data = calculate_leave_accrual(start_date, end_date, employee_type, leave_type)

#             # Store leave accrual data in the MongoDB collection
#             leave_record = {
#                 "person_number": person_number,
#                 "leave_type": leave_type,
#                 "total_accrued_leave": accrual_data["total_accrued_leave"],
#                 "timestamp": datetime.now()
#             }
#             leave_accruals_collection.insert_one(leave_record)

# if __name__ == "__main__":
#     # Call the function to calculate leave accruals
#     calculate_leave_accruals()


from pymongo import MongoClient
from datetime import datetime, timedelta

# MongoDB connection setup
client = MongoClient("mongodb://localhost:27017/")
db = client["dev1"]
employees_collection = db["HRM_employee_details"]
leave_accruals_collection = db["leave_accruals"]

def calculate_leave_accrual(start_date, end_date, employee_type, leave_type):
    """
    Calculate the total accrued leave based on start date, end date, employee type, and leave type.
    """
    # Define leave accrual rates based on leave type and employee type
    leave_accrual_rates = {
        "annual_leave": {
            "full-time": 2.5,  # days per month
            "part-time": 1.25,
            "contractor": 0.5
        },
        "sick_leave": {
            "full-time": 1.0,
            "part-time": 0.5,
            "contractor": 0.25
        },
        "maternity_leave": {
            "full-time": 1.5,
            "part-time": 0.75,
            "contractor": 0.5
        },
        "paternity_leave": {
            "full-time": 1.0,
            "part-time": 0.5,
            "contractor": 0.25
        },
        "adoption_leave": {
            "full-time": 1.5,
            "part-time": 0.75,
            "contractor": 0.5
        },
        "bereavement_leave": {
            "full-time": 0.5,
            "part-time": 0.25,
            "contractor": 0.1
        },
        "unpaid_leave": {
            "full-time": 0.0,
            "part-time": 0.0,
            "contractor": 0.0
        },
        "parental_leave": {
            "full-time": 1.0,
            "part-time": 0.5,
            "contractor": 0.25
        },
        "compassionate_leave": {
            "full-time": 0.5,
            "part-time": 0.25,
            "contractor": 0.1
        },
        "shared_parental_leave": {
            "full-time": 1.5,
            "part-time": 0.75,
            "contractor": 0.5
        }
        # Add other leave types and rates here
    }

    # Check if leave type and employee type are valid
    if leave_type not in leave_accrual_rates or employee_type not in leave_accrual_rates[leave_type]:
        return {"total_accrued_leave": 0}  # Return 0 if leave type or employee type is invalid

    # Get the accrual rate for the given leave type and employee type
    accrual_rate = leave_accrual_rates[leave_type][employee_type]

    # Convert start_date and end_date to datetime objects
    start_date = datetime.strptime(start_date, "%Y-%m-%d")
    end_date = datetime.strptime(end_date, "%Y-%m-%d")

    # Initialize total accrued leave
    total_accrued_leave = 0.0

    # Calculate the number of full months between start_date and end_date
    while start_date < end_date:
        # Add the full monthly accrual to the total accrued leave
        total_accrued_leave += accrual_rate

        # Move to the next month
        start_date = start_date.replace(day=1) + timedelta(days=32)
        start_date = start_date.replace(day=1)

    return {"total_accrued_leave": total_accrued_leave}

# Function to calculate leave accruals for all employees
def calculate_leave_accruals():
    # Fetch all distinct person numbers from the HRM_employee_details collection
    person_numbers = employees_collection.distinct("Person_Number")

    for person_number in person_numbers:
        # Fetch employee data by person number
        employee_data = employees_collection.find_one({"Person_Number": person_number})

        # Extract relevant data for leave accrual calculation
        start_date = datetime.strptime(employee_data["Original_Start_Date"], "%Y-%m-%d")
        hire_date = datetime.strptime(employee_data["Hire_Date"], "%Y-%m-%d")
        # Use financial year start date if hire date is after financial year start date, else use hire date
        current_year = datetime.now().year
        financial_year_start = datetime(current_year, 4, 1)  # Financial year starts on April 1st
        start_date = max(start_date, hire_date, financial_year_start).strftime("%Y-%m-%d")
        
#         # Set end date to June 15, 2024
        end_date = "2024-06-02"
        
#         employee_type = employee_data["Employment_Type"]
        employee_type = employee_data["Employment_Type"]

        # Perform leave accrual calculation
        for leave_type in ["annual_leave"]:
            accrual_data = calculate_leave_accrual(start_date, end_date, employee_type, leave_type)

            # Store leave accrual data in the MongoDB collection
            leave_record = {
                "person_number": person_number,
                "leave_type": leave_type,
                "total_accrued_leave": accrual_data["total_accrued_leave"],
                "timestamp": datetime.now()
            }
            leave_accruals_collection.insert_one(leave_record)


if __name__ == "__main__":
    # Call the function to calculate leave accruals
    calculate_leave_accruals()
