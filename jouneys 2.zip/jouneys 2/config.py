config = {
    "HR_JOB_CODE":"JB10",
    "company_name":"ORAS",
    'from_email': 'piyushbirkh@gmail.com',  # Default sender email
    'templates': {
        'user_unassigned_from_journey': 'user_unassigned_from_journey',
        'task_removed_notification': 'task_removed_notification',
        'team_assignment_notification': 'team_assignment_notification',
        'user_added_to_journey': 'user_added_to_journey',
        'journey_updated': 'journey_updated',
        'team_task_complete': 'team_task_complete',
        'task_complete': 'task_complete',
        'employee_added_notification': 'employee_added_notification',
        'tasks_assigned': 'tasks_assigned',
        'onboarding_journey_assigned_today': 'onboarding_journey_assigned_today',
        'employee_offboarding': 'employee_offboarding',
        'team_creation_notification': 'team_creation_notification',
        'task_updated': 'task_updated',
        "tasks_overdue3":"tasks_overdue3"
    }
}
