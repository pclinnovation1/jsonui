from flask import Blueprint, request, jsonify, Flask

from journey_management import (
    add_user_to_journey, 
    view_journeys_of_user, 
    view_all_journeys,
    create_journey,
    update_journey,
    delete_journey,
    view_my_journeys,
    track_journey_progress,
    complete_task,
    submit_feedback,
    view_team_journeys,
    track_team_member_progress,
    update_task_status_for_team_member,
    provide_feedback_on_team_member_task,
    monitor_overall_journey_progress,
    generate_reports,
    add_user_to_team_in_journey,
        create_task,
    update_task,
    view_task,
    delete_task,
    show_my_tasks,
    show_team_journey_tasks_and_report,
    show_journey_activities,
    update_time_status
)

app = Flask(__name__)
journey_bp = Blueprint('journey_bp', __name__)

@app.route('/add_user_to_journey', methods=['POST'])
def add_user():
    data = request.json
    journey_title = data.get("name")
    user = data.get("users")

    if not journey_title or not user:
        return jsonify({"error": "Missing journey_title or user in request body"}), 400

    return add_user_to_journey(journey_title, user)

@app.route('/view_journeys_of_user', methods=['POST'])
def view_user_journeys():
    data = request.json
    user_name = data.get("users")

    if not user_name:
        return jsonify({"error": "Missing user_name in request body"}), 400

    return jsonify(view_journeys_of_user(user_name))

@app.route('/view_all_journeys', methods=['POST'])
def view_journeys():
    return view_all_journeys()

@app.route('/create_journey', methods=['POST'])
def create_new_journey():
    data = request.json
    if not data:
        return jsonify({"error": "Invalid data"}), 400

    return create_journey(data)

@app.route('/update_journey', methods=['POST'])
def update_existing_journey():
    data = request.json
    if not data or "name" not in data or "update_data" not in data:
        return jsonify({"error": "Missing journey_title or update_data in request body"}), 400

    journey_title = data["name"]
    update_data = data["update_data"]

    return update_journey(journey_title, update_data)

@app.route('/delete_journey', methods=['POST'])
def delete_existing_journey():
    data = request.json
    if not data or "name" not in data:
        return jsonify({"error": "Missing journey_title in request body"}), 400

    journey_title = data["name"]

    return delete_journey(journey_title)

@app.route('/view_my_journeys', methods=['POST'])
def view_my_journeys_route():
    data = request.json
    person_name = data.get("person_name")

    if not person_name:
        return jsonify({"error": "Missing person_name in request body"}), 400

    return view_my_journeys(person_name)

@app.route('/track_journey_progress', methods=['POST'])
def track_journey_progress_route():
    data = request.json
    person_name = data.get("person_name")

    if not person_name:
        return jsonify({"error": "Missing person_name in request body"}), 400

    return track_journey_progress(person_name)

@app.route('/complete_task', methods=['POST'])
def complete_task_route():
    data = request.json
    person_name = data.get("person_name")
    journey_title = data.get("journey_title")
    task_name = data.get("task_name")

    if not person_name or not journey_title or not task_name:
        return jsonify({"error": "Missing person_name, journey_title, or task_name in request body"}), 400

    return complete_task(person_name, journey_title, task_name)

@app.route('/submit_feedback', methods=['POST'])
def submit_feedback_route():
    data = request.json
    person_name = data.get("person_name")
    journey_title = data.get("journey_title")
    task_name = data.get("task_name")
    feedback = data.get("feedback")

    if not person_name or not journey_title or not task_name or not feedback:
        return jsonify({"error": "Missing person_name, journey_title, task_name, or feedback in request body"}), 400

    return submit_feedback(person_name, journey_title, task_name, feedback)

@app.route('/view_team_journeys', methods=['POST'])
def view_team_journeys_route():
    data = request.json
    team_name = data.get("team_name")

    if not team_name:
        return jsonify({"error": "Missing team_name in request body"}), 400

    return jsonify(view_team_journeys(team_name))

@app.route('/track_team_member_progress', methods=['POST'])
def track_team_member_progress_route():
    data = request.json
    team_name = data.get("team_name")
    member_name = data.get("member_name")

    if not team_name or not member_name:
        return jsonify({"error": "Missing team_name or member_name in request body"}), 400

    return track_team_member_progress(team_name, member_name)

@app.route('/update_task_status_for_team_member', methods=['POST'])
def update_task_status_for_team_member_route():
    data = request.json
    team_name = data.get("team_name")
    member_name = data.get("member_name")
    journey_title = data.get("journey_title")
    task_name = data.get("task_name")
    status = data.get("status")

    if not team_name or not member_name or not journey_title or not task_name or not status:
        return jsonify({"error": "Missing team_name, member_name, journey_title, task_name, or status in request body"}), 400

    return update_task_status_for_team_member(team_name, member_name, journey_title, task_name, status)

@app.route('/provide_feedback_on_team_member_task', methods=['POST'])
def provide_feedback_on_team_member_task_route():
    data = request.json
    team_name = data.get("team_name")
    member_name = data.get("member_name")
    journey_title = data.get("journey_title")
    task_name = data.get("task_name")
    feedback = data.get("feedback")

    if not team_name or not member_name or not journey_title or not task_name or not feedback:
        return jsonify({"error": "Missing team_name, member_name, journey_title, task_name, or feedback in request body"}), 400

    return provide_feedback_on_team_member_task(team_name, member_name, journey_title, task_name, feedback)

@app.route('/monitor_overall_journey_progress', methods=['POST'])
def monitor_overall_journey_progress_route():
    return monitor_overall_journey_progress()

@app.route('/generate_reports', methods=['POST'])
def generate_reports_route():
    return jsonify(generate_reports())

@app.route('/add_user_to_team_in_journey', methods=['POST'])
def add_user_to_team():
    data = request.json
    journey_title = data.get("journey_title")
    team_name = data.get("team_name")
    member_name = data.get("member_name")

    if not journey_title or not team_name or not member_name:
        return jsonify({"error": "Missing journey_title, team_name, or member_name in request body"}), 400

    return jsonify(add_user_to_team_in_journey(journey_title, team_name, member_name))


@app.route('/create_task', methods=['POST'])
def create_new_task():
    data = request.json
    if not data:
        return jsonify({"error": "Invalid data"}), 400

    return create_task(data)

@app.route('/update_task', methods=['POST'])
def update_existing_task():
    data = request.json
    task_name = data.get("task_name")
    update_data = data.get("update_data")

    if not task_name or not update_data:
        return jsonify({"error": "Missing task_name or update_data in request body"}), 400

    return update_task(task_name, update_data)

@app.route('/view_task', methods=['POST'])
def view_existing_task():
    data = request.json
    task_name = data.get("task_name")

    if not task_name:
        return jsonify({"error": "Missing task_name in request body"}), 400

    return view_task(task_name)

@app.route('/delete_task', methods=['POST'])
def delete_existing_task():
    data = request.json
    task_name = data.get("task_name")

    if not task_name:
        return jsonify({"error": "Missing task_name in request body"}), 400

    return delete_task(task_name)


@app.route('/show_my_tasks', methods=['POST'])
def show_my_tasks_route():
    data = request.json
    person_name = data.get("person_name")

    if not person_name:
        return jsonify({"error": "Missing person_name in request body"}), 400

    return jsonify(show_my_tasks(person_name))

@app.route('/show_team_journey_tasks_and_report', methods=['POST'])
def show_team_journey_tasks_and_report_route():
    data = request.json
    team_name = data.get("team_name")
    member_name = data.get("member_name")

    if not team_name or not member_name:
        return jsonify({"error": "Missing team_name or member_name in request body"}), 400

    return jsonify(show_team_journey_tasks_and_report(team_name, member_name))

@app.route('/show_journey_activities', methods=['POST'])
def show_journey_activities_route():
    data = request.json
    person_name = data.get("person_name")

    if not person_name:
        return jsonify({"error": "Missing person_name in request body"}), 400

    return jsonify(show_journey_activities(person_name))


# run this on daily basis
@app.route('/update_time_status', methods=['POST'])
def update_time_status_route():
    result, status_code = update_time_status()
    return jsonify(result), status_code


if __name__ == '__main__':
    app.run(debug=True, port=5002)
