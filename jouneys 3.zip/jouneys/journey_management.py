from datetime import datetime, timedelta
from pymongo import errors
from general_algo import get_database, data_validation_against_schema
from pymongo import UpdateOne

def add_user_to_journey(journey_title, user):
    db = get_database()
    collection = db["JRN_journey"]
    task_collection = db["JRN_task"]

    try:
        journey = collection.find_one({'name': journey_title})
        if not journey:
            return {'error': 'Journey not found'}, 404

        tasks = []
        for task in journey['tasks']:
            task_info = task_collection.find_one({'task_name': task['title']})
            if not task_info:
                return {'error': f'Task {task["title"]} not found in task collection'}, 404
            task_due_date = datetime.now() + timedelta(days=task_info['duration'])
            tasks.append({
                "task_name": task['title'],
                "status": "In progress",
                "task_start_date": datetime.now().strftime('%Y-%m-%d'),
                "task_due_date": task_due_date.strftime('%Y-%m-%d'),
                "time_status": "On time",
                "feedback": ""
            })

        user['tasks'] = tasks
        result = collection.update_one(
            {'name': journey_title},
            {'$addToSet': {'users': user}}
        )

        if result.modified_count == 0:
            return {'error': 'User already added'}, 400
        return {'message': 'User added successfully'}, 200
    except Exception as e:
        return {'error': str(e)}, 500

def view_journeys_of_user(user_name):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        journeys = list(collection.find({'users.person_name': user_name}))
        filtered_journeys = []
        for journey in journeys:
            journey['_id'] = str(journey['_id'])
            filtered_users = [user for user in journey['users'] if user['person_name'] == user_name]
            journey['users'] = filtered_users

            for team in journey.get('teams', []):
                team_members = [member for member in team['teammembers'] if member['person_name'] == user_name]
                if team_members:
                    if 'teams' not in journey:
                        journey['teams'] = []
                    journey['teams'].append({
                        "team_name": team['team_name'],
                        "teammembers": team_members
                    })

            filtered_journeys.append(journey)
        return filtered_journeys, 200
    except Exception as e:
        return {'error': str(e)}, 500

def view_all_journeys():
    db = get_database()
    collection = db["JRN_journey"]
    try:
        journeys = list(collection.find({}))
        for journey in journeys:
            journey['_id'] = str(journey['_id'])
        return journeys, 200
    except Exception as e:
        return {'error': str(e)}, 500

def create_journey(data):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        if not data_validation_against_schema(collection, [data]):
            return {'error': 'Data schema does not match collection schema'}, 400

        journey_id = collection.insert_one(data).inserted_id
        return {"message": "Journey created successfully", "journey_id": str(journey_id)}, 201
    except errors.PyMongoError as e:
        return {"error": f"Error inserting data: {e}"}, 500

def update_journey(journey_title, update_data):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        result = collection.update_one(
            {'name': journey_title},
            {'$set': update_data}
        )

        if result.matched_count == 0:
            return {'error': 'Journey not found'}, 404
        return {'message': 'Journey updated successfully'}, 200
    except Exception as e:
        return {'error': str(e)}, 500

def delete_journey(journey_title):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        result = collection.delete_one({'name': journey_title})

        if result.deleted_count == 0:
            return {'error': 'Journey not found'}, 404
        return {'message': 'Journey deleted successfully'}, 200
    except Exception as e:
        return {'error': str(e)}, 500

def track_journey_progress(person_name):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        journeys = list(collection.find({'users.person_name': person_name}))
        progress = []
        for journey in journeys:
            user = next(user for user in journey['users'] if user['person_name'] == person_name)
            completed_tasks = len([task for task in user['tasks'] if task['status'] == 'Completed'])
            total_tasks = len(journey['tasks'])
            progress.append({
                'journey': journey['name'],
                'completed_tasks': completed_tasks,
                'total_tasks': total_tasks,
                'progress': (completed_tasks / total_tasks) * 100 if total_tasks > 0 else 0
            })
        return progress, 200
    except Exception as e:
        return {'error': str(e)}, 500

def complete_task(person_name, journey_title, task_name):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        journey = collection.find_one({'name': journey_title, 'users.person_name': person_name})
        if not journey:
            return {'error': 'Journey or user not found'}, 404
        
        user = next(user for user in journey['users'] if user['person_name'] == person_name)
        task = next((task for task in user['tasks'] if task['task_name'] == task_name), None)
        
        if not task:
            return {'error': 'Task not found'}, 404

        due_date = datetime.strptime(task['task_due_date'], '%Y-%m-%d')
        current_date = datetime.now()
        time_status = "Completed on time" if current_date <= due_date else f"Completed {current_date - due_date} day(s) late"

        result = collection.update_one(
            {'name': journey_title, 'users.person_name': person_name, 'users.tasks.task_name': task_name},
            {'$set': {'users.$[user].tasks.$[task].status': 'Completed', 'users.$[user].tasks.$[task].time_status': time_status}},
            array_filters=[{'user.person_name': person_name}, {'task.task_name': task_name}]
        )

        if result.modified_count == 0:
            return {'error': 'Task update failed'}, 404
        return {'message': 'Task marked as completed'}, 200
    except Exception as e:
        return {'error': str(e)}, 500

def submit_feedback(person_name, journey_title, task_name, feedback):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        result = collection.update_one(
            {'name': journey_title, 'users.person_name': person_name, 'users.tasks.task_name': task_name},
            {'$set': {'users.$[user].tasks.$[task].feedback': feedback}},
            array_filters=[{'user.person_name': person_name}, {'task.task_name': task_name}]
        )

        if result.modified_count == 0:
            return {'error': 'Feedback submission failed'}, 404
        return {'message': 'Feedback submitted successfully'}, 200
    except Exception as e:
        return {'error': str(e)}, 500

def view_team_journeys(team_name):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        journeys = list(collection.find({'teams.team_name': team_name}))
        filtered_journeys = []
        for journey in journeys:
            journey['_id'] = str(journey['_id'])
            filtered_teams = [team for team in journey['teams'] if team['team_name'] == team_name]
            journey['teams'] = filtered_teams
            if 'users' in journey:
                del journey['users']
            filtered_journeys.append(journey)
        return filtered_journeys, 200
    except Exception as e:
        return {'error': str(e)}, 500

def track_team_member_progress(team_name, member_name):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        journeys = list(collection.find({'teams.team_name': team_name, f'teams.teammembers.person_name': member_name}))
        progress = []
        for journey in journeys:
            team = next(team for team in journey['teams'] if team['team_name'] == team_name)
            member = next(member for member in team['teammembers'] if member['person_name'] == member_name)
            completed_tasks = len([task for task in member['tasks'] if task['status'] == 'Completed'])
            total_tasks = len(journey['tasks'])
            progress.append({
                'team_member': member_name,
                'journey': journey['name'],
                'completed_tasks': completed_tasks,
                'total_tasks': total_tasks,
                'progress': (completed_tasks / total_tasks) * 100 if total_tasks > 0 else 0
            })
        return progress, 200
    except Exception as e:
        return {'error': str(e)}, 500

def update_task_status_for_team_member(team_name, member_name, journey_title, task_name, status):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        journey = collection.find_one({'name': journey_title, 'teams.team_name': team_name, 'teams.teammembers.person_name': member_name})
        if not journey:
            return {'error': 'Journey, team, or member not found'}, 404

        team = next(team for team in journey['teams'] if team['team_name'] == team_name)
        member = next(member for member in team['teammembers'] if member['person_name'] == member_name)
        task = next((task for task in member['tasks'] if task['task_name'] == task_name), None)
        
        if not task:
            return {'error': 'Task not found'}, 404

        due_date = datetime.strptime(task['task_due_date'], '%Y-%m-%d')
        current_date = datetime.now()
        time_status = "Completed on time" if current_date <= due_date else f"Completed {current_date - due_date} day(s) late"

        result = collection.update_one(
            {'name': journey_title, 'teams.team_name': team_name, 'teams.teammembers.person_name': member_name, 'teams.teammembers.tasks.task_name': task_name},
            {'$set': {'teams.$[team].teammembers.$[member].tasks.$[task].status': status, 'teams.$[team].teammembers.$[member].tasks.$[task].time_status': time_status}},
            array_filters=[{'team.team_name': team_name}, {'member.person_name': member_name}, {'task.task_name': task_name}]
        )

        if result.modified_count == 0:
            return {'error': 'Task status update failed'}, 404
        return {'message': 'Task status updated successfully'}, 200
    except Exception as e:
        return {'error': str(e)}, 500


def provide_feedback_on_team_member_task(team_name, member_name, journey_title, task_name, feedback):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        result = collection.update_one(
            {'name': journey_title, 'teams.team_name': team_name, 'teams.teammembers.person_name': member_name},
            {'$set': {'teams.$.teammembers.$[member].tasks.$[task].feedback': feedback}},
            array_filters=[{'member.person_name': member_name}, {'task.task_name': task_name}]
        )

        if result.modified_count == 0:
            return {'error': 'Feedback submission failed'}, 404
        return {'message': 'Feedback submitted successfully'}, 200
    except Exception as e:
        return {'error': str(e)}, 500

def monitor_overall_journey_progress():
    db = get_database()
    collection = db["JRN_journey"]
    try:
        journeys = list(collection.find({}))
        progress = []
        for journey in journeys:
            completed_tasks = sum(len([task for task in user['tasks'] if task['status'] == 'Completed']) for user in journey['users'])
            total_tasks = len(journey['tasks']) * len(journey['users'])
            progress.append({
                'journey': journey['name'],
                'completed_tasks': completed_tasks,
                'total_tasks': total_tasks,
                'progress': (completed_tasks / total_tasks) * 100 if total_tasks > 0 else 0
            })
        return progress, 200
    except Exception as e:
        return {'error': str(e)}, 500

def generate_reports():
    db = get_database()
    collection = db["JRN_journey"]
    try:
        journeys = list(collection.find({}))
        report = []
        for journey in journeys:
            journey_report = {
                'journey_name': journey['name'],
                'users': [],
                'teams': []
            }
            for user in journey['users']:
                completed_tasks = len([task for task in user['tasks'] if task['status'] == 'Completed'])
                total_tasks = len(journey['tasks'])
                progress = (completed_tasks / total_tasks) * 100 if total_tasks > 0 else 0
                journey_report['users'].append({
                    'person_name': user['person_name'],
                    'progress': progress
                })
            for team in journey['teams']:
                team_progress = {}
                for member in team['teammembers']:
                    completed_tasks = len([task for task in member['tasks'] if task['status'] == 'Completed'])
                    total_tasks = len(journey['tasks'])
                    progress = (completed_tasks / total_tasks) * 100 if total_tasks > 0 else 0
                    team_progress[member['person_name']] = progress
                journey_report['teams'].append({
                    'team_name': team['team_name'],
                    'progress': team_progress
                })
            report.append(journey_report)
        return report, 200
    except Exception as e:
        return {'error': str(e)}, 500

def view_my_journeys(person_name):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        journeys = list(collection.find({'$or': [{'users.person_name': person_name}, {'teams.teammembers.person_name': person_name}]}))
        for journey in journeys:
            journey['_id'] = str(journey['_id'])
            journey['users'] = [user for user in journey['users'] if user['person_name'] == person_name]
            for team in journey.get('teams', []):
                team['teammembers'] = [member for member in team['teammembers'] if member['person_name'] == person_name]
        return journeys, 200
    except Exception as e:
        return {'error': str(e)}, 500

def add_user_to_team_in_journey(journey_title, team_name, member_name):
    db = get_database()
    collection = db["JRN_journey"]
    task_collection = db["JRN_task"]

    try:
        journey = collection.find_one({'name': journey_title})
        if not journey:
            return {'error': 'Journey not found'}, 404

        tasks = []
        for task in journey['tasks']:
            task_info = task_collection.find_one({'task_name': task['title']})
            if not task_info:
                return {'error': f'Task {task["title"]} not found in task collection'}, 404
            task_due_date = datetime.now() + timedelta(days=task_info['duration'])
            tasks.append({
                "task_name": task['title'],
                "status": "Not Started",
                "task_start_date": datetime.now().strftime('%Y-%m-%d'),
                "task_due_date": task_due_date.strftime('%Y-%m-%d'),
                "time_status": "On time",
                "feedback": ""
            })

        result = collection.update_one(
            {'name': journey_title, 'teams.team_name': team_name},
            {'$addToSet': {'teams.$.teammembers': {
                'person_name': member_name,
                'status': 'In Progress',
                'tasks': tasks
            }}}
        )

        if result.modified_count == 0:
            return {'error': 'Journey or team not found, or member already added'}, 404
        return {'message': 'User added to team successfully'}, 200
    except Exception as e:
        return {'error': str(e)}, 500


def create_task(data):
    db = get_database()
    collection = db["JRN_task"]
    try:
        if not data_validation_against_schema(collection, [data]):
            return {'error': 'Data schema does not match collection schema'}, 400

        task_id = collection.insert_one(data).inserted_id
        return {"message": "Task created successfully", "task_id": str(task_id)}, 201
    except errors.PyMongoError as e:
        return {"error": f"Error inserting data: {e}"}, 500

def update_task(task_name, update_data):
    db = get_database()
    collection = db["JRN_task"]
    try:
        result = collection.update_one(
            {'task_name': task_name},
            {'$set': update_data}
        )

        if result.matched_count == 0:
            return {'error': 'Task not found'}, 404
        return {'message': 'Task updated successfully'}, 200
    except Exception as e:
        return {'error': str(e)}, 500

def view_task(task_name):
    db = get_database()
    collection = db["JRN_task"]
    try:
        task = collection.find_one({'task_name': task_name})
        if task:
            task['_id'] = str(task['_id'])
            return task, 200
        return {'error': 'Task not found'}, 404
    except Exception as e:
        return {'error': str(e)}, 500

def delete_task(task_name):
    db = get_database()
    collection = db["JRN_task"]
    try:
        result = collection.delete_one({'task_name': task_name})

        if result.deleted_count == 0:
            return {'error': 'Task not found'}, 404
        return {'message': 'Task deleted successfully'}, 200
    except Exception as e:
        return {'error': str(e)}, 500

def show_my_tasks(person_name):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        tasks = []
        journeys = list(collection.find({'$or': [{'users.person_name': person_name}, {'teams.teammembers.person_name': person_name}]}))
        
        for journey in journeys:
            journey_name = journey['name']
            
            # Individual tasks
            for user in journey['users']:
                if user['person_name'] == person_name:
                    for task in user['tasks']:
                        tasks.append({
                            'task_name': task['task_name'],
                            'journey_name': journey_name,
                            'description': 'Individual',
                            'time_status': task['time_status'],
                            'status': task['status']
                        })
            
            # Team tasks
            for team in journey.get('teams', []):
                for member in team['teammembers']:
                    if member['person_name'] == person_name:
                        for task in member['tasks']:
                            tasks.append({
                                'task_name': task['task_name'],
                                'journey_name': journey_name,
                                'description': f'Team ({team["team_name"]})',
                                'time_status': task['time_status'],
                                'status': task['status']
                            })
        return tasks, 200
    except Exception as e:
        return {'error': str(e)}, 500

def show_team_journey_tasks_and_report(team_name, member_name):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        report = {
            'tasks': [],
            'member_report': {}
        }
        journeys = list(collection.find({'teams.team_name': team_name, f'teams.teammembers.person_name': member_name}))

        for journey in journeys:
            journey_name = journey['name']
            team = next(team for team in journey['teams'] if team['team_name'] == team_name)
            
            member = next(member for member in team['teammembers'] if member['person_name'] == member_name)
            for task in member['tasks']:
                report['tasks'].append({
                    'task_name': task['task_name'],
                    'journey_name': journey_name,
                    'time_status': task['time_status']
                })
            
            for member in team['teammembers']:
                completed_tasks = len([task for task in member['tasks'] if task['status'] == 'Completed'])
                pending_tasks = len([task for task in member['tasks'] if task['status'] != 'Completed'])
                report['member_report'][member['person_name']] = {
                    'completed_tasks': completed_tasks,
                    'pending_tasks': pending_tasks
                }

            user_completed_tasks = len([task for task in member['tasks'] if task['status'] == 'Completed'])
            user_pending_tasks = len([task for task in member['tasks'] if task['status'] != 'Completed'])
            report['member_report'][member_name] = {
                'completed_tasks': user_completed_tasks,
                'pending_tasks': user_pending_tasks
            }

        return report, 200
    except Exception as e:
        return {'error': str(e)}, 500
def show_journey_activities(person_name):
    db = get_database()
    collection = db["JRN_journey"]
    try:
        activities = []
        journeys = list(collection.find({'$or': [{'users.person_name': person_name}, {'teams.teammembers.person_name': person_name}]}))

        for journey in journeys:
            journey_name = journey['name']
            
            # Get the status, start date, and due date for the journey for the user
            user_status = 'Unknown'
            journey_start_date = 'Unknown'
            journey_due_date = 'Unknown'
            if 'users' in journey:
                for user in journey['users']:
                    if user['person_name'] == person_name:
                        user_status = user['status']
                        journey_start_date = user['journey_start_date']
                        journey_due_date = user['journey_due_date']
                        break

            if user_status == 'Unknown' and 'teams' in journey:
                for team in journey['teams']:
                    for member in team['teammembers']:
                        if member['person_name'] == person_name:
                            user_status = member['status']
                            journey_start_date = team.get('journey_start_date', 'Unknown')
                            journey_due_date = team.get('journey_due_date', 'Unknown')
                            break

            # Count assignees
            assignees = len(journey['users'])
            for team in journey.get('teams', []):
                assignees += len(team['teammembers'])

            # Determine time status
            current_date = datetime.now().date()
            due_date = datetime.strptime(journey_due_date, '%Y-%m-%d').date() if journey_due_date != 'Unknown' else None
            if due_date:
                time_status = 'On time' if current_date <= due_date else f'Overdue by {(current_date - due_date).days} days'
            else:
                time_status = 'Unknown'

            activities.append({
                'journey_name': journey_name,
                'status': user_status,
                'assignees': assignees,
                'start_date': journey_start_date,
                'due_date': journey_due_date,
                'time_status': time_status
            })

        return activities, 200
    except Exception as e:
        return {'error': str(e)}, 500



def update_time_status():
    db = get_database()
    collection = db["JRN_journey"]
    try:
        current_date = datetime.now().date()
        updates = []

        journeys = list(collection.find({}))
        for journey in journeys:
            for user_index, user in enumerate(journey['users']):
                for task_index, task in enumerate(user['tasks']):
                    if task['status'] == 'Completed':
                        continue  # Skip if the task is already completed
                    due_date = datetime.strptime(task['task_due_date'], '%Y-%m-%d').date()
                    if current_date <= due_date:
                        time_status = 'On time'
                    else:
                        time_status = f'Overdue by {(current_date - due_date).days} days'
                    if task['time_status'] != time_status:
                        updates.append(UpdateOne(
                            {'_id': journey['_id'], f'users.{user_index}.tasks.{task_index}.task_name': task['task_name']},
                            {'$set': {f'users.{user_index}.tasks.{task_index}.time_status': time_status}}
                        ))

            for team_index, team in enumerate(journey.get('teams', [])):
                for member_index, member in enumerate(team['teammembers']):
                    for task_index, task in enumerate(member['tasks']):
                        if task['status'] == 'Completed':
                            continue  # Skip if the task is already completed
                        due_date = datetime.strptime(task['task_due_date'], '%Y-%m-%d').date()
                        if current_date <= due_date:
                            time_status = 'On time'
                        else:
                            time_status = f'Overdue by {(current_date - due_date).days} days'
                        if task['time_status'] != time_status:
                            updates.append(UpdateOne(
                                {'_id': journey['_id'], f'teams.{team_index}.teammembers.{member_index}.tasks.{task_index}.task_name': task['task_name']},
                                {'$set': {f'teams.{team_index}.teammembers.{member_index}.tasks.{task_index}.time_status': time_status}}
                            ))

        if updates:
            collection.bulk_write(updates)
        return {'message': 'Time statuses updated successfully'}, 200
    except Exception as e:
        return {'error': str(e)}, 500