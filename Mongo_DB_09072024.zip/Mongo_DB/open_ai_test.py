import openai
from datetime import datetime, timedelta

# Set your OpenAI API key here
openai.api_key = 'your-api-key-here'

# Function to interpret the rule and calculate the due date
def calculate_due_date(completion_date, rule):
    # Prepare the prompt
    prompt = (f"Given the rule '{rule}', calculate the due date starting from the "
              f"completion date {completion_date.strftime('%Y-%m-%d')}. "
              "Return the due date in 'YYYY-MM-DD' format.")

    response = openai.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ]
    )

    # Extract the calculated due date from the response
    due_date_str = response['choices'][0]['message']['content'].strip()
    try:
        due_date = datetime.strptime(due_date_str, '%Y-%m-%d')
    except ValueError:
        raise ValueError(f"Could not parse the due date from the response: {due_date_str}")

    return due_date

# Sample completion date
completion_date = datetime(2021, 6, 14)

# Sample rules
rule_scenario_1 = "the Due Date must be set for reassignment at three years after the original Completion Date"
rule_scenario_2 = "the Due Date must be set for reassignment at four years after the original Completion Date"

# Calculate due dates for different scenarios
due_date_1 = calculate_due_date(completion_date, rule_scenario_1)
due_date_2 = calculate_due_date(completion_date, rule_scenario_2)

print(f"Due Date for Scenario 1: {due_date_1.strftime('%Y-%m-%d')}")
print(f"Due Date for Scenario 2: {due_date_2.strftime('%Y-%m-%d')}")
