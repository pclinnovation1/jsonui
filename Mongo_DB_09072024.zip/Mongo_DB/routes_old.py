from flask import Flask, request, jsonify
from pymongo import MongoClient, errors
import logging
import pymongo
from datetime import datetime

app = Flask(__name__)

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client.company

def setup_routes(app):

    # Helper function to fetch manager name by ID
    def fetch_manager_name_by_id(manager_id):
        manager = db.EmployeeDetails_UK.find_one({"EmployeeID": manager_id}, {"_id": 0, "FirstName": 1, "LastName": 1})
        if manager:
            return f"{manager['FirstName']} {manager['LastName']}"
        return None

    # Fetch employee details from MongoDB
    def fetch_employee_details(employee_name, department=None):
        query = {"$expr": {"$eq": [{"$concat": ["$FirstName", " ", "$LastName"]}, employee_name]}}
        if department:
            query["Department"] = department

        employees = list(db.EmployeeDetails_UK.find(query, {"_id": 0, "EmployeeID": 1, "FirstName": 1, "LastName": 1, "Department": 1, "Manager_ID": 1}))
        
        if len(employees) == 1:
            return employees[0]
        elif len(employees) > 1:
            employee_list = []
            for emp in employees:
                manager_name = fetch_manager_name_by_id(emp['Manager_ID'])
                employee_list.append({
                    "EmployeeID": emp['EmployeeID'],
                    "FullName": f"{emp['FirstName']} {emp['LastName']}",
                    "Employee_Department": emp['Department'],
                    "Manager_Name": manager_name
                })
            return employee_list
        else:
            return None

    # Fetch leave type ID from MongoDB
    def fetch_leave_type_id(leave_type_name):
        leave_type = db.leave_types.find_one({"Leave_Type_Name": leave_type_name}, {"_id": 0, "Leave_Type_ID": 1})
        return leave_type['Leave_Type_ID'] if leave_type else None

    # Fetch manager details from MongoDB
    def fetch_manager_details(manager_name, department=None):
        query = {"$expr": {"$eq": [{"$concat": ["$FirstName", " ", "$LastName"]}, manager_name]}}
        if department:
            query["Department"] = department

        managers = list(db.EmployeeDetails_UK.find(query, {"_id": 0, "EmployeeID": 1, "FirstName": 1, "LastName": 1, "Department": 1}))
        
        if len(managers) == 1:
            manager = managers[0]
            return {
                "Manager_ID": manager['EmployeeID'],
                "FullName": f"{manager['FirstName']} {manager['LastName']}",
                "Manager_Department": manager['Department']
            }
        elif len(managers) > 1:
            return [{"Manager_ID": mgr['EmployeeID'], "FullName": f"{mgr['FirstName']} {mgr['LastName']}", "Manager_Department": mgr['Department']} for mgr in managers]
        else:
            return None

    # Function to get the next sequence value for Application_ID
    def get_next_sequence_value(sequence_name):
        counter = db.counters.find_one_and_update(
            {"_id": sequence_name},
            {"$inc": {"sequence_value": 1}},
            return_document=True
        )
        return counter["sequence_value"]

    # Initialize counter for Application_ID if it does not exist
    if db.counters.find_one({"_id": "application_id"}) is None:
        db.counters.insert_one({"_id": "application_id", "sequence_value": 0})

    @app.route('/applyForLeave', methods=['POST'])
    def apply_for_leave():
        data = request.json
        if not data:
            return jsonify({"error": "Invalid data"}), 400

        employee_name = data.get("Employee_Name")
        employee_department = data.get("Employee_Department")
        leave_type_name = data.get("Leave_Type_Name")
        manager_name = data.get("Manager_Name", "Jane Smith")
        manager_department = data.get("Manager_Department")

        if employee_name:
            employee_result = fetch_employee_details(employee_name, employee_department)
            if isinstance(employee_result, list):
                return jsonify({"error": "Multiple employees found. Please specify the Department or Employee ID.", "employees": employee_result}), 400
            elif not employee_result:
                return jsonify({"error": "Employee not found"}), 404
            else:
                data['Employee_ID'] = employee_result['EmployeeID']
                employee_manager_id = employee_result['Manager_ID']  # Get the manager ID for the employee
                employee_manager_name = fetch_manager_name_by_id(employee_manager_id)  # Get the manager name for the employee

        if leave_type_name:
            leave_type_id = fetch_leave_type_id(leave_type_name)
            if not leave_type_id:
                return jsonify({"error": "Leave type not found"}), 404
            else:
                data['Leave_Type_ID'] = leave_type_id
        
        manager_name = "Jane Smith"
        manager_department = None 
        manager_result = fetch_manager_details(manager_name, manager_department)
        if isinstance(manager_result, list):
            return jsonify({"error": "Multiple managers found. Please specify the Department or Manager ID.", "managers": manager_result}), 400
        elif not manager_result:
            return jsonify({"error": "Manager not found"}), 404
        else:
            data['Manager_ID'] = manager_result['Manager_ID']

        # Common required fields
        common_required_fields = ['Employee_ID', 'Leave_Type_ID', 'Start_Date', 'End_Date', 'Duration', 'Reason_for_Absence', 'Status']

        # Additional required fields for Maternity (ID=6) or Adoption (ID=7)
        additional_required_fields = {
            6: ['Expected_Date_of_Childbirth_Adoption', 'Planned_Start_Date', 'Planned_End_Date', 'Will_not_Return_to_Work'],
            7: ['Expected_Date_of_Childbirth_Adoption', 'Planned_Start_Date', 'Planned_End_Date', 'Will_not_Return_to_Work']
        }

        # Check for missing common required fields
        if any(field not in data for field in common_required_fields):
            return jsonify({"error": "Missing mandatory leave application data"}), 400

        leave_type_id = int(data['Leave_Type_ID'])

        # Check for additional fields based on leave type and validate them
        if leave_type_id in additional_required_fields:
            if any(field not in data for field in additional_required_fields[leave_type_id]):
                return jsonify({"error": f"Missing additional leave application data for leave type {leave_type_id}"}), 400
        else:
            # Remove additional fields if they are present in the request but not required
            for field in ['Expected_Date_of_Childbirth_Adoption', 'Planned_Start_Date', 'Planned_End_Date', 'Will_not_Return_to_Work']:
                data.pop(field, None)

        try:
            # Get the next application ID
            application_id = get_next_sequence_value("application_id")

            # Insert the leave application into MongoDB
            leave_application = {
                "Application_ID": application_id,
                "Employee_ID": data['Employee_ID'],
                "Leave_Type_ID": data['Leave_Type_ID'],
                "Start_Date": data['Start_Date'],
                "End_Date": data['End_Date'],
                "Duration": data['Duration'],
                "Reason_for_Absence": data['Reason_for_Absence'],
                "Status": data['Status'],
                "Manager_ID": data['Manager_ID']
            }

            if leave_type_id in additional_required_fields:
                leave_application.update({
                    "Expected_Date_of_Childbirth_Adoption": data.get('Expected_Date_of_Childbirth_Adoption'),
                    "Actual_Date_of_Childbirth_Adoption": data.get('Actual_Date_of_Childbirth_Adoption'),
                    "Planned_Start_Date": data.get('Planned_Start_Date'),
                    "Planned_End_Date": data.get('Planned_End_Date'),
                    "Actual_Start_Date": data.get('Actual_Start_Date'),
                    "Actual_End_Date": data.get('Actual_End_Date'),
                    "Will_not_Return_to_Work": data.get('Will_not_Return_to_Work')
                })

            db.Leave_Applications.insert_one(leave_application)
            return jsonify({"message": "Leave application submitted successfully"}), 200
        except Exception as e:
            logging.error(f"Error applying for leave: {str(e)}")
            return jsonify({"error": "Failed to submit leave application"}), 500
        

    def fetch_employees_by_name(employee_name, department_name=None):
        # db = get_db_connection()
        name_parts = employee_name.split()
        if len(name_parts) == 2:
            first_name, last_name = name_parts
        else:
            return []
        
        query = {"FirstName": first_name, "LastName": last_name}
        if department_name:
            query["Department"] = department_name
        
        employees = db.EmployeeDetails_UK.find(query, {"EmployeeID": 1, "Department": 1, "FullName": {"$concat": ["$FirstName", " ", "$LastName"]}})
        
        return [{"Employee_ID": emp["EmployeeID"], "Department_Name": emp["Department"], "Employee_Name": emp["FullName"]} for emp in employees]

    def fetch_leave_balances(employee_id):
        # db = get_db_connection()
        
        
        # Ensure employee_id is an integer if stored as such in MongoDB
        try:
            employee_id = int(employee_id)
        except ValueError:
            return []  # Return empty list if employee_id is not valid

        # Fetch leave balances for the employee
        leave_balances = list(db.Leave_Balances.find({"Employee_ID": employee_id}, {"_id": 0, "Leave_Type_ID": 1, "Current_Balance": 1}))

        # Fetch leave type names and combine with leave balances
        print(leave_balances)
        result = []
        for balance in leave_balances:
            leave_type = db.leave_types.find_one({"Leave_Type_ID": balance["Leave_Type_ID"]}, {"_id": 0, "Leave_Type_Name": 1})
            if leave_type:
                result.append({"Leave_Type": leave_type["Leave_Type_Name"], "Current_Balance": balance["Current_Balance"]})

        return result

    @app.route('/leaveBalances/view', methods=['GET'])
    def handle_leave_balances():
        data = request.json
        employee_name = data.get('Employee_Name')
        department_name = data.get('Department_Name')
        employee_id = data.get('Employee_ID')

        if not employee_id:
            employees = fetch_employees_by_name(employee_name, department_name)
            if len(employees) == 1:
                employee_id = employees[0]["Employee_ID"]
            elif len(employees) > 1:
                if department_name:
                    # Filter employees by the provided department name
                    filtered_employees = [emp for emp in employees if emp['Department_Name'] == department_name]
                    if len(filtered_employees) == 1:
                        employee_id = filtered_employees[0]['Employee_ID']
                    else:
                        # Return the filtered employees if still multiple or none
                        return jsonify({"message": "Multiple or no employees found in specified department, specify further.", "employees": filtered_employees}), 200
                else:
                    # Return all potential employees if department not specified
                    return jsonify({"message": "Multiple employees found, specify further.", "employees": employees}), 200

        if employee_id:
            print(employee_id)
            leave_balances = fetch_leave_balances(employee_id)
            return jsonify({"leave_balances": leave_balances}), 200
        else:
            return jsonify({"error": "Employee not uniquely identified, provide more details"}), 400
        
    def apply_leave_modifications(employee_id, modifications):
        # db = get_db_connection()
        
        try:
            all_leave_types = db.leave_types.find({}, {"_id": 0, "Leave_Type_Name": 1})
            all_leave_types = [lt["Leave_Type_Name"] for lt in all_leave_types]
            print(all_leave_types)

            results = []
            for mod in modifications:
                leave_type = mod.get("Leave_Type")
                change = mod.get("Change")
                print(leave_type)

                if leave_type not in all_leave_types:
                    return {
                        "error": "This Leave Type does not exist in the database, please add the new Leave Type. Currently, these Leave Types exist:",
                        "Leave_Types": all_leave_types
                    }

                leave_type_record = db.leave_types.find_one({"Leave_Type_Name": leave_type}, {"_id": 0, "Leave_Type_ID": 1})
                leave_type_id = leave_type_record["Leave_Type_ID"] if leave_type_record else None

                if leave_type_id:
                    # Check if the employee has this leave type already
                    current_balance_record = db.leave_balances.find_one({"Employee_ID": employee_id, "Leave_Type_ID": leave_type_id}, {"_id": 0, "Current_Balance": 1})

                    if current_balance_record:
                        new_balance = change
                        db.Leave_Balances.update_one(
                            {"Employee_ID": employee_id, "Leave_Type_ID": leave_type_id},
                            {"$set": {"Current_Balance": new_balance}}
                        )
                        results.append(f"Updated {leave_type} for employee {employee_id}. New balance is {new_balance}.")
                    else:
                        db.leave_balances.insert_one({
                            "Employee_ID": employee_id,
                            "Leave_Type_ID": leave_type_id,
                            "Current_Balance": change
                        })
                        results.append(f"Added {leave_type} for employee {employee_id}. Current balance is {change}.")

            return {"message": "Leave balances updated successfully", "details": results}
        except Exception as e:
            logging.error(f"Error applying leave modifications: {e}")
            return {"error": f"Failed to update leave balances: {str(e)}"}

    @app.route('/leaveBalances/edit', methods=['POST'])
    def edit_leave_balances():
        data = request.json
        employee_name = data.get("Employee_Name")
        department_name = data.get("Department_Name")
        modifications = data.get("Modifications", [])

        if not employee_name or not modifications:
            return jsonify({"error": "Invalid or missing Employee Name or Modifications"}), 400

        employees = fetch_employees_by_name(employee_name, department_name)

        if len(employees) == 1:
            employee_id = employees[0]["Employee_ID"]
            success = apply_leave_modifications(employee_id, modifications)
            if success:
                return jsonify(success), 200
            else:
                return jsonify({"error": "Failed to update leave balances"}), 500
        elif len(employees) > 1:
            return jsonify({"message": "Multiple employees found, specify further.", "employees": employees}), 200
        else:
            return jsonify({"error": "Employee not found"}), 404

    @app.route('/leaveApplications/employee', methods=['GET'])
    def view_leave_applications_by_employee():
        data = request.json
        employee_name = data.get('Employee_Name')
        department_name = data.get('Department_Name')
        employee_id = data.get('Employee_ID')

        if not employee_id:
            employees = fetch_employees_by_name(employee_name, department_name)
            if len(employees) == 1:
                employee_id = employees[0]["Employee_ID"]
            elif len(employees) > 1:
                if department_name:
                    # Filter employees by the provided department name
                    filtered_employees = [emp for emp in employees if emp['Department_Name'] == department_name]
                    if len(filtered_employees) == 1:
                        employee_id = filtered_employees[0]['Employee_ID']
                    else:
                        # Return the filtered employees if still multiple or none
                        return jsonify({"message": "Multiple or no employees found in specified department, specify further.", "employees": filtered_employees}), 200
                else:
                    # Return all potential employees if department not specified
                    return jsonify({"message": "Multiple employees found, specify further.", "employees": employees}), 200
        
        # if not employees:
        #     return jsonify({"error": "This employee does not exist in the database."}), 404
        # elif len(employees) > 1:
        #     return jsonify({"error": "Multiple employees found with the same name. Please provide more details."}), 400

        # employee = employees[0]
        # employee_id = employee['EmployeeID']
        if employee_id:
        
        # Fetch leave applications for the employee
            pipeline = [
                {"$match": {"Employee_ID": employee_id}},
                {"$lookup": {
                    "from": "leave_types",
                    "localField": "Leave_Type_ID",
                    "foreignField": "Leave_Type_ID",
                    "as": "LeaveTypeDetails"
                }},
                {"$unwind": "$LeaveTypeDetails"},
                {"$lookup": {
                    "from": "EmployeeDetails_UK",
                    "localField": "Manager_ID",
                    "foreignField": "EmployeeID",
                    "as": "ManagerDetails"
                }},
                {"$unwind": {"path": "$ManagerDetails", "preserveNullAndEmptyArrays": True}},
                {"$project": {
                    "Application_ID": 1,
                    "Employee_ID": 1,
                    "Full_Name": {"$concat": ["$FirstName", " ", "$LastName"]},
                    "Department": 1,
                    "Leave_Type_ID": 1,
                    "Leave_Type_Name": "$LeaveTypeDetails.Leave_Type_Name",
                    "Start_Date": 1,
                    "End_Date": 1,
                    "Duration": 1,
                    "Reason_for_Absence": 1,
                    "Status": 1,
                    "Manager_ID": 1,
                    "Manager_Name": {"$concat": ["$ManagerDetails.FirstName", " ", "$ManagerDetails.LastName"]},
                    "Application_ID_Str": {"$toString": "$_id"},  # Convert ObjectId to string
                    "Manager_ID_Str": {"$toString": "$Manager_ID"},  # Convert ObjectId to string
                    "Employee_ID_Str": {"$toString": "$Employee_ID"}  # Convert ObjectId to string
                }}
            ]
            print(pipeline)
            applications = list(db.Leave_Applications.aggregate(pipeline))
            
            if applications:
                for application in applications:
                    application['_id'] = str(application['_id'])
                    if application.get('Manager_ID'):
                        application['Manager_ID'] = str(application['Manager_ID'])
                    if application.get('Employee_ID'):
                        application['Employee_ID'] = str(application['Employee_ID'])
                return jsonify({"applications": applications}), 200
            else:
                return jsonify({"message": "This employee has not applied for any leave."}), 200    

    @app.route('/processHrInfoUK', methods=['POST'])
    def process_hr_information():
        data = request.json
        
        # Check if all required data sections are present
        if data and all(key in data for key in ['Personal_Details', 'Employment_Details', 'Working_Hours_and_Shifts']):
            logging.info("Received new employee HR information:")
            
            # Process the HR information
            success = process_hr_info(data)  # Assume this function returns True/False based on success/failure

            if success:
                return success
                # return jsonify({"message": "Successfully processed the HR information"}), 200
            else:
                return jsonify({"error": "Failed to process HR information"}), 500
        else:
            # Respond with error message if required data is missing
            return jsonify({"error": "Bad request, due to missing or invalid HR data"}), 400
        
    def get_next_employee_id(db):
        counters = db["counters"]
        counter = counters.find_one_and_update(
            {"_id": "employee_id"},
            {"$inc": {"sequence_value": 1}},
            return_document=pymongo.ReturnDocument.AFTER,
            upsert=True
        )
        return counter["sequence_value"]        

    def process_hr_info(data):
        # Extracting data from JSON
        personal_details = data["Personal_Details"]
        employment_details = data["Employment_Details"]
        working_hours = data["Working_Hours_and_Shifts"]
        address = personal_details["Address"]

        full_name = personal_details["Full_Name"]
        first_name, last_name = full_name.split(" ", 1)
        date_of_birth = datetime.strptime(personal_details["Date_of_Birth"], "%Y-%m-%d").date()
        national_insurance_number = personal_details["National_Insurance_Number"]

        job_title = employment_details["Job_Title"]
        start_date = datetime.strptime(employment_details["Start_Date"], "%Y-%m-%d").date()
        department = employment_details["Department_Cost_Center"]["Select_Department"]
        department_code = employment_details["Department_Cost_Center"]["Enter_Department_Code"]

        standard_daily_working_hours = working_hours["Standard_Working_Hours"]["Enter_Standard_Daily_Working_Hours"]
        standard_working_days = working_hours["Standard_Working_Hours"]["Choose_Standard_Working_Days"]

        # Convert date objects to strings
        date_of_birth_str = date_of_birth.strftime("%Y-%m-%d")
        start_date_str = start_date.strftime("%Y-%m-%d")

        # Get the next EmployeeID
        employee_id = get_next_employee_id(db)
        # flattened_data["EmployeeID"] = employee_id

        # Construct the document to be inserted in the desired format
        employee_data = {
            "EmployeeID": employee_id,  # Example EmployeeID, you might need to generate this or obtain from the data
            "FirstName": first_name,
            "LastName": last_name,
            "DateOfBirth": date_of_birth_str,
            "NationalInsuranceNumber": national_insurance_number,
            "Address": f"{address['House_Number_Name']} {address['Street_Name']}, {address['Town_City']}, {address['Postcode']}",
            "StartDate": start_date_str,
            "Department": department,
            "DepartmentCode": department_code,
            "JobTitle": job_title,
            "StandardDailyWorkingHours": standard_daily_working_hours,
            "StandardWorkingDays": standard_working_days,
            "Manager_ID": 12346  # Assuming a default manager ID
        }
        
        # Add any additional fields present in the JSON that are not in the predefined structure
        additional_fields = {k: v for k, v in data.items() if k not in ["Personal_Details", "Employment_Details", "Working_Hours_and_Shifts"]}
        employee_data.update(additional_fields)
        
        # Connect to MongoDB
        # collection = get_mongo_connection()

        try:
            # Insert document into MongoDB collection
            db.EmployeeDetails_UK.insert_one(employee_data)
            return jsonify({"message": "Data inserted successfully."}), 200
        except Exception as e:
            return jsonify({"error": f"Failed to insert data into MongoDB: {str(e)}"}), 500
        
    #     #######  New Method  #############

    #     # Function to flatten the JSON structure and handle the address field
    # def flatten_json(y):
    #     out = {}

    #     def flatten(x, name=''):
    #         if isinstance(x, dict):
    #             for a in x:
    #                 if isinstance(x[a], dict):  # If the current field is a dictionary, go deeper without including the current key
    #                     flatten(x[a], name)
    #                 else:
    #                     flatten(x[a], name + a + '_')
    #         else:
    #             if x:  # Only include non-empty values
    #                 out[name[:-1]] = x

    #     flatten(y)
        
    #     # Handling address separately
    #     if 'Personal_Details_Address_House_Number_Name' in out and 'Personal_Details_Address_Street_Name' in out and 'Personal_Details_Address_Town_City' in out and 'Personal_Details_Address_Postcode' in out:
    #         out['Address'] = f"{out.pop('Personal_Details_Address_House_Number_Name')} {out.pop('Personal_Details_Address_Street_Name')}, {out.pop('Personal_Details_Address_Town_City')}, {out.pop('Personal_Details_Address_Postcode')}"
        
    #     # Remove the nested prefixes
    #     cleaned_out = {}
    #     for key, value in out.items():
    #         cleaned_key = key.replace('Personal_Details_', '').replace('Employment_Details_', '').replace('Working_Hours_and_Shifts_', '')
    #         cleaned_out[cleaned_key] = value
        
    #     return cleaned_out

    # # Function to get the next auto-incrementing EmployeeID
    # def get_next_employee_id(db):
    #     counters = db["counters"]
    #     counter = counters.find_one_and_update(
    #         {"_id": "employee_id"},
    #         {"$inc": {"sequence_value": 1}},
    #         return_document=pymongo.ReturnDocument.AFTER,
    #         upsert=True
    #     )
    #     return counter["sequence_value"]

    # # Function to process HR information
    # def process_hr_info(data):
    #     # Flatten the original data
    #     flattened_data = flatten_json(data)

    #     # Convert date objects to strings
    #     for key, value in flattened_data.items():
    #         if 'Date' in key and isinstance(value, str):
    #             try:
    #                 date_obj = datetime.strptime(value, "%Y-%m-%d").date()
    #                 flattened_data[key] = date_obj.strftime("%Y-%m-%d")
    #             except ValueError:
    #                 pass  # Keep the original value if conversion fails

    #     # Connect to MongoDB
    #     # db = get_mongo_connection()
        
    #     # Get the next EmployeeID
    #     employee_id = get_next_employee_id(db)
    #     flattened_data["EmployeeID"] = employee_id

    #     # collection = db["EmployeeDetails_UK"]

    #     try:
    #         # Insert document into MongoDB collection
    #         db.EmployeeDetails_UK.insert_one(flattened_data)
    #         return jsonify({"message": "Data inserted successfully."}), 200
    #     except Exception as e:
    #         return jsonify({"error": f"Failed to insert data into MongoDB: {str(e)}"}), 500

    # @app.route('/processHrInfoUK', methods=['POST'])
    # def process_hr_information():
    #     data = request.json

    #     if data:
    #         logging.info("Received new employee HR information:")
            
    #         # Process the HR information
    #         return process_hr_info(data)
    #     else:
    #         # Respond with error message if required data is missing
    #         return jsonify({"error": "Bad request, due to missing or invalid HR data"}), 400

    # if __name__ == '__main__':
    #     app.run(debug=True)
