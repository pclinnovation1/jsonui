# import pandas as pd
# from pymongo import MongoClient

# def get_mongo_connection():
#     return MongoClient("mongodb://localhost:27017/")

# def load_course_job_family_data(excel_path, sheet_name, db_name, collection_name):
#     # Load the Excel sheet into a pandas DataFrame
#     df = pd.read_excel(excel_path, sheet_name=sheet_name)

#     # Print column names to inspect them
#     print("Column names:", df.columns.tolist())

#     # Connect to MongoDB
#     db = get_mongo_connection()[db_name]
#     collection = db[collection_name]

#     # Convert DataFrame to dictionary and insert into MongoDB
#     data_dict = df.to_dict('records')
#     collection.insert_many(data_dict)
#     print("Data successfully loaded into MongoDB.")

# # File path to the Excel file
# excel_path = r'C:\Users\Sajal\Downloads\PH2 LEARNING Course Job_Family Data_ Catalogue Data v3 140624 2.xlsx'
# sheet_name = 'COURSE - JOB FAMILY'  # The sheet name containing the data
# db_name = 'company2'
# collection_name = 'CourseJobFamily'

# # Load the data into MongoDB
# load_course_job_family_data(excel_path, sheet_name, db_name, collection_name)


import pandas as pd
from pymongo import MongoClient

def get_mongo_connection():
    return MongoClient("mongodb://localhost:27017/")

def load_course_job_family_data(excel_path, sheet_name, db_name, collection_name):
    # Load the Excel sheet into a pandas DataFrame
    df = pd.read_excel(excel_path, sheet_name=sheet_name)

    # Remove unwanted columns, such as 'Unnamed: 0'
    df.drop([col for col in df.columns if 'Unnamed' in col], axis=1, inplace=True)

    # Check if 'Course No.' is in the DataFrame, if not create it
    if 'Course No.' not in df.columns:
        df['Course No.'] = pd.RangeIndex(1, len(df) + 1).astype(str)  # Assign a sequential number if 'Course No.' is absent

    # Rename the 'Course No.' column to a more standard field name if necessary
    df.rename(columns={'Course No.': 'Course_No'}, inplace=True)

    # Print column names to inspect them after modifications
    print("Column names after modifications:", df.columns.tolist())

    # Connect to MongoDB
    db = get_mongo_connection()[db_name]
    collection = db[collection_name]

    # Convert DataFrame to dictionary and insert into MongoDB
    data_dict = df.to_dict('records')
    collection.insert_many(data_dict)
    print("Data successfully loaded into MongoDB.")

# File path to the Excel file
excel_path = r'C:\Users\Sajal\Downloads\PH2 LEARNING Course Job_Family Data_ Catalogue Data v3 140624 2.xlsx'
sheet_name = 'COURSE - JOB FAMILY'  # The sheet name containing the data
db_name = 'company2'
collection_name = 'CourseJobFamily'

# Load the data into MongoDB
load_course_job_family_data(excel_path, sheet_name, db_name, collection_name)
