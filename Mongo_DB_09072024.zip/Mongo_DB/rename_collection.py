from pymongo import MongoClient, errors

try:
    # Connect to MongoDB
    client = MongoClient("mongodb://localhost:27017/")
    print("Connected to MongoDB successfully!")

    # Access the database
    db = client.company

    # Rename the collection from "absence" to "Leave_Applications"
    db.absence.rename("Leave_Applications")
    print("Collection renamed successfully!")

    # Fetch and display the documents to verify
    for doc in db.Leave_Applications.find():
        print(doc)

except errors.ConnectionFailure as e:
    print(f"Could not connect to MongoDB: {e}")

except errors.PyMongoError as e:
    print(f"An error occurred with PyMongo: {e}")

except Exception as e:
    print(f"An unexpected error occurred: {e}")
