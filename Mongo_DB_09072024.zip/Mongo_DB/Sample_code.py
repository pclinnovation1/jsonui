from pymongo import MongoClient, errors

try:
    # Connect to MongoDB
    client = MongoClient("mongodb://localhost:27017/")
    print("Connected to MongoDB successfully!")

    # Access the database (create it if it doesn't exist)
    db = client.company

    # Access the collection (create it if it doesn't exist)
    employee_collection = db.employees

    # Sample employee documents
    employees = [
        {"name": "John Doe", "age": 30, "position": "Software Engineer", "department": "Engineering"},
        {"name": "Jane Smith", "age": 25, "position": "Data Analyst", "department": "Data Science"},
        {"name": "Mike Johnson", "age": 35, "position": "Project Manager", "department": "Management"},
        {"name": "Emily Davis", "age": 28, "position": "UX Designer", "department": "Design"}
    ]

    # Insert multiple documents into the collection
    result = employee_collection.insert_many(employees)
    print(f"Inserted document IDs: {result.inserted_ids}")

    # Fetch and display the documents to verify insertion
    for employee in employee_collection.find():
        print(employee)

    # Query to find details of "John Doe"
    query = {"name": "John Doe"}
    john_doe = employee_collection.find_one(query)

    # Check if the document exists and print the details
    if john_doe:
        print("John Doe's details:")
        print(john_doe)
    else:
        print("John Doe not found in the collection.")

except errors.ConnectionFailure as e:
    print(f"Could not connect to MongoDB: {e}")

except errors.PyMongoError as e:
    print(f"An error occurred with PyMongo: {e}")

except Exception as e:
    print(f"An unexpected error occurred: {e}")
