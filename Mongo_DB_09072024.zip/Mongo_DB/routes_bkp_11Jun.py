from flask import Flask, request, jsonify
from pymongo import MongoClient, errors
import logging
import pymongo
from datetime import datetime
from collections import Counter


app = Flask(__name__)

def setup_routes(app):
    # MongoDB connection setup
    # MongoDB connection setup
    def get_mongo_connection():
        # Replace the connection string with your MongoDB connection string
        client = MongoClient("mongodb://localhost:27017/")  # Update this with your MongoDB connection string
        # Replace "your_database_name" with the actual database name
        db = client["company2"]
        return db

    # Function to get the current counter value or initialize it if it doesn't exist
    def get_counter(db):
        counter_collection = db["counter"]  # Collection to store the counter
        counter_doc = counter_collection.find_one({"_id": "person_number_counter"})
        if counter_doc:
            return counter_doc["value"]
        else:
            # Initialize counter if not exists
            counter_collection.insert_one({"_id": "person_number_counter", "value": 101})  # Starting from 102
            return 101

    # Function to increment and return the new counter value
    def increment_counter(db):
        counter_collection = db["counter"]  # Collection to store the counter
        new_counter_value = get_counter(db) + 1
        counter_collection.find_one_and_update(
            {"_id": "person_number_counter"},
            {"$set": {"value": new_counter_value}}
        )
        return new_counter_value

    # Function to flatten JSON data and insert into MongoDB
    def insert_data(db, data):
        # Remove the person number from the JSON data
        if "Person_Number" in data:
            del data["Person_Number"]

        # Get the current counter value and increment it
        counter = increment_counter(db)

        # Flatten the original data
        flattened_data = flatten_json(data, counter, db)

        # Convert date strings to date objects
        for key, value in flattened_data.items():
            if 'Date' in key and isinstance(value, str):
                try:
                    date_obj = datetime.strptime(value, "%Y-%m-%d").date()
                    flattened_data[key] = date_obj.strftime("%Y-%m-%d")
                except ValueError:
                    pass  # Keep the original value if conversion fails

        # Insert data into the collection
        collection = db["EmployeeDetails_UK"]
        collection.insert_one(flattened_data)
        print("Data inserted successfully")
        return "Data inserted successfully"

    # Function to flatten JSON data
    def flatten_json(data, counter, db):
        out = {}
        duplicates = Counter()  # Counter to keep track of duplicate fields

        def flatten(x, name=''):
            if isinstance(x, dict):
                for a in x:
                    if isinstance(x[a], dict):  # If the current field is a dictionary, go deeper without including the current key
                        flatten(x[a], name)
                    else:
                        field_name = name + a
                        if duplicates[field_name] == 0:  # Check if field is encountered for the first time
                            out[field_name] = x[a]
                        else:
                            # Field encountered more than once, ignore
                            print(f"Duplicate field: {field_name}")

                        duplicates[field_name] += 1
            else:
                if x:  # Only include non-empty values
                    out[name[:-1]] = x

        flatten(data)

        # Handling address separately
        address_keys = ['House_Number_Name', 'Street_Name', 'Town_City', 'Postcode']
        if all('Personal_Details_Address_' + key in out for key in address_keys):
            out['Address'] = ", ".join(out.pop('Personal_Details_Address_' + key) for key in address_keys)

        # Remove the nested prefixes
        cleaned_out = {}
        for key, value in out.items():
            cleaned_key = key.replace('Personal_Details_', '').replace('Employment_Details_', '').replace('Working_Hours_and_Shifts_', '')
            cleaned_out[cleaned_key] = value

        # Inserting person number
        cleaned_out['Person_Number'] = counter

        return cleaned_out

    @app.route('/processHrInfoUK', methods=['POST'])
    def process_hr_information():
        data = request.json
        if not data:
            return jsonify({"error": "Invalid data"}), 400

        db = get_mongo_connection()
        message = insert_data(db, data)
        return jsonify({"message": message}), 200


    @app.route('/applyForLeave', methods=['POST'])
    def submit_leave_application():
        data = request.json
        if not data:
            return jsonify({"error": "Invalid data"}), 400

        db = get_mongo_connection()
        if db is None:
            return jsonify({"error": "Could not connect to database"}), 500

        # Convert date strings to date objects
        try:
            if "Start_Date" in data:
                data["Start_Date"] = datetime.strptime(data["Start_Date"], "%Y-%m-%d").strftime("%Y-%m-%d")
            if "End_Date" in data:
                data["End_Date"] = datetime.strptime(data["End_Date"], "%Y-%m-%d").strftime("%Y-%m-%d")
        except ValueError as e:
            logging.error(f"Date conversion error: {e}")
            return jsonify({"error": "Invalid date format"}), 400

        # Insert data into the Leave_Applications collection
        try:
            collection = db["Leave_Applications"]
            collection.insert_one(data)
            logging.info("Leave application submitted successfully")
            return jsonify({"message": "Leave application submitted successfully"}), 200
        except errors.PyMongoError as e:
            logging.error(f"Error inserting data: {e}")
            return jsonify({"error": f"Error inserting data: {e}"}), 500
        

    @app.route('/LeaveBalances/edit', methods=['POST'])
    def modify_leave_balance():
        data = request.json
        if not data:
            return jsonify({"error": "Invalid data"}), 400

        db = get_mongo_connection()
        if db is None:
            return jsonify({"error": "Could not connect to database"}), 500

        employee_name = data.get("Employee_Name")
        modifications = data.get("Modifications")

        if not employee_name or not modifications:
            return jsonify({"error": "Missing Employee_Name or Modifications"}), 400

        collection = db["Leave_Balances"]

        for modification in modifications:
            leave_type = modification.get("Leave_Type")
            change = modification.get("Change")

            if not leave_type or change is None:
                return jsonify({"error": "Missing Leave_Type or Change in modifications"}), 400

            try:
                # Check if the leave type exists for the employee
                record = collection.find_one({"Employee_Name": employee_name, "Leave_Type": leave_type})

                if record:
                    # Update the existing leave balance
                    new_balance = record["Leave_Balance"] + change
                    collection.update_one({"_id": record["_id"]}, {"$set": {"Leave_Balance": new_balance}})
                    logging.info(f"Updated {leave_type} for {employee_name}, new balance: {new_balance}")
                else:
                    # Insert a new record for the leave type
                    new_record = {
                        "Employee_Name": employee_name,
                        "Leave_Type": leave_type,
                        "Leave_Balance": change
                    }
                    collection.insert_one(new_record)
                    logging.info(f"Inserted new {leave_type} for {employee_name} with balance: {change}")

            except errors.PyMongoError as e:
                logging.error(f"Error modifying data: {e}")
                return jsonify({"error": f"Error modifying data: {e}"}), 500

        return jsonify({"message": "Leave balances updated successfully"}), 200     
    


    # @app.route('/LeaveBalances/view', methods=['GET'])  # Changed to GET
    # def get_leave_balance():
    #     data = request.json
    #     if not data or "Employee_Name" not in data:
    #         return jsonify({"error": "Missing Employee_Name in request body"}), 400

    #     employee_name = data["Employee_Name"]

    #     db = get_mongo_connection()
    #     if db is None:
    #         return jsonify({"error": "Could not connect to database"}), 500

    #     collection = db["Leave_Balances"]

    #     try:
    #         records = collection.find({"Employee_Name": employee_name})
    #         leave_balances = []
    #         for record in records:
    #             leave_balances.append({
    #                 "Leave_Type": record["Leave_Type"],
    #                 "Leave_Balance": record["Leave_Balance"]
    #             })
    #         if not leave_balances:
    #             return jsonify({"error": "No records found for the specified employee"}), 404
    #         return jsonify({"employee_name": employee_name, "leave_balances": leave_balances}), 200
    #     except errors.PyMongoError as e:
    #         logging.error(f"Error retrieving data: {e}")
    #         return jsonify({"error": f"Error retrieving data: {e}"}), 500

    @app.route('/LeaveBalances/view', methods=['POST'])  # Changed to GET
    def get_leave_balance():
        data = request.json
        if not data or "Employee_Name" not in data:
            return jsonify({"error": "Missing Employee_Name in request body"}), 400

        employee_name = data["Employee_Name"]

        db = get_mongo_connection()
        if db is None:
            return jsonify({"error": "Could not connect to database"}), 500

        employees_collection = db["EmployeeDetails_UK"]
        leave_accruals_collection = db["Leave_Balances"]

        try:
            # Find the employee's person number using their name
            employee_record = employees_collection.find_one({"First_Name": employee_name.split()[0], "Last_Name": employee_name.split()[1]})
            if not employee_record:
                return jsonify({"error": "No employee found with the specified name"}), 404

            person_number = employee_record["Person_Number"]

            # Find leave balances for the employee using their person number
            records = leave_accruals_collection.find({"person_number": person_number})
            leave_balances = []
            for record in records:
                leave_balances.append({
                    "Leave_Type": record["leave_type"],
                    "Leave_Balance": record["total_accrued_leave"]
                })

            if not leave_balances:
                return jsonify({"error": "No leave balances found for the specified employee"}), 404

            return jsonify({"employee_name": employee_name, "leave_balances": leave_balances}), 200
        except errors.PyMongoError as e:
            logging.error(f"Error retrieving data: {e}")
            return jsonify({"error": f"Error retrieving data: {e}"}), 500