import pandas as pd
from pymongo import MongoClient
from datetime import datetime, timedelta
import openai

# Define the MongoDB connection and database
def get_mongo_connection():
    return MongoClient("mongodb://localhost:27017/")

# Function to convert date to ISO format string
def to_iso_date(date):
    return date.isoformat()

# Function to convert ISO format string to datetime.date
def from_iso_date(date_str):
    return datetime.fromisoformat(date_str).date()

# Function to generate reassignment dates using OpenAI
def generate_reassignment_dates(rule2, rule3, completion_date_str):
    openai.api_key = ''

    # Generate due_date using OpenAI
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": f"Given the rule: '{rule2}' and the completion date: '{completion_date_str}', calculate the due date. Provide the date in ISO format."}
        ],
        max_tokens=50
    )
    due_date_str = response.choices[0].message['content'].strip()

    # Generate auto_assign_date using OpenAI
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": f"Given the rule: '{rule3}' and the due date: '{due_date_str}', calculate the auto-assign date. Provide the date in ISO format."}
        ],
        max_tokens=50
    )
    auto_assign_date_str = response.choices[0].message['content'].strip()

    return from_iso_date(due_date_str), from_iso_date(auto_assign_date_str)

# Function to check and renew course assignments
def check_and_renew_courses(db_name, rules_collection_name, assignments_collection_name):
    # Connect to MongoDB
    db = get_mongo_connection()[db_name]
    rules_collection = db[rules_collection_name]
    assignments_collection = db[assignments_collection_name]

    # Fetch all course assignments
    assignments = assignments_collection.find()

    for assignment in assignments:
        person = assignment['Person']
        course_name = assignment['Course_Name']
        completion_date = from_iso_date(assignment['Completion_Date'])
        completion_date_str = to_iso_date(completion_date)

        # Fetch the course rules from the rules collection
        course_rule = rules_collection.find_one({"Course_Name": course_name})

        if course_rule:
            # Extract the rules
            rule2 = course_rule.get('Rule2', '')
            rule3 = course_rule.get('Rule3', '')

            # Generate reassignment dates using OpenAI
            due_date, auto_assign_date = generate_reassignment_dates(rule2, rule3, completion_date_str)

            # Check if today is the auto-assign date
            today = datetime.now().date()
            if today >= auto_assign_date:
                # Reassign the course
                new_date_assignment = today
                new_due_date = new_date_assignment + timedelta(days=90)
                new_completion_date = None  # Not yet completed

                # Insert the new assignment
                new_assignment = {
                    "Course_Name": course_name,
                    "Person": person,
                    "Date_Assignment": to_iso_date(new_date_assignment),
                    "Due_Date": to_iso_date(new_due_date),
                    "Completion_Date": new_completion_date
                }
                assignments_collection.insert_one(new_assignment)
                print(f"Reassigned course '{course_name}' to {person} with new due date {new_due_date}")

# Example usage
db_name = 'company2'
rules_collection_name = 'CourseRules'
assignments_collection_name = 'CourseAssignments'
check_and_renew_courses(db_name, rules_collection_name, assignments_collection_name)
