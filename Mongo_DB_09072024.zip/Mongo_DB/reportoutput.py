import sys
from flask import Blueprint, request, send_file, jsonify
from io import BytesIO
import pandas as pd
import csv
import json
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib import colors
import os
######$$$$$$$$

# Create a blueprint named 'reportoutput'
reportoutput = Blueprint('reportoutput', __name__)

# Sample JSON data (moved inside the route for demonstration)
data_json = '''
[
  {"EmployeeID": "E001", "Name": "John Doe", "Position": "Software Engineer", "Department": "Engineering", "Email": "john.doe@example.com"},
  {"EmployeeID": "E002", "Name": "Jane Smith", "Position": "Product Manager", "Department": "Product", "Email": "jane.smith@example.com"},
  {"EmployeeID": "E003", "Name": "Alice Johnson", "Position": "UX Designer", "Department": "Design", "Email": "alice.johnson@example.com"}
]
'''

@reportoutput.route('/generate-html', methods=['POST'])
def generate_html():
    payload = request.json  # Get JSON payload
    data = payload['data']  # Extract data
    report_name = payload['reportName']  # Extract report name
    html_content = generate_html_function(data, report_name)
    return html_content

@reportoutput.route('/generate-csv', methods=['POST'])
def generate_csv():
    payload = request.json
    data = payload['data']
    report_name = payload['reportName']
    file_path = generate_csv_function(data, report_name)
    return send_file(file_path, as_attachment=True, download_name=f"{report_name.replace(' ', '_')}.csv")



@reportoutput.route('/generate-text', methods=['POST'])
def generate_text():
    payload = request.json
    data = payload['data']
    report_name = payload['reportName']
    text_content = generate_text_report(data, report_name)
    return text_content

@reportoutput.route('/generate-excel', methods=['POST'])
def generate_excel():
    payload = request.json
    data = payload['data']
    report_name = payload['reportName']
    excel_file_path = generate_excel_function(data, report_name)
    # Correct usage of send_file with the right argument for filename
    return send_file(excel_file_path, as_attachment=True, download_name=f"{report_name.replace(' ', '_')}.xlsx")

@reportoutput.route('/generate-pdf', methods=['POST'])
def generate_pdf():
    payload = request.json
    data = payload['data']
    report_name = payload['reportName']
    pdf_file_path = generate_pdf_with_table(data, report_name)
    return send_file(pdf_file_path, as_attachment=True, download_name=f"{report_name.replace(' ', '_')}.pdf")


def generate_html_function(data, report_name):
    html = f'<html>\n<head><title>{report_name}</title></head>\n<body>\n<table border="1">\n'
    html += '<tr>' + ''.join(f'<th>{key}</th>' for key in data[0].keys()) + '</tr>\n'
    for item in data:
        html += '<tr>' + ''.join(f'<td>{value}</td>' for value in item.values()) + '</tr>\n'
    html += '</table>\n</body>\n</html>'
    return html

def generate_csv_function(data, report_name):
    # Specify the directory to save the file (you can adjust this path)
    directory = os.path.join(os.getcwd(), 'files')
    os.makedirs(directory, exist_ok=True)

    # Sanitize the filename
    csv_filename = f"{report_name.replace(' ', '_')}.csv"
    csv_output = os.path.join(directory, csv_filename)

    # Write data to a CSV file
    with open(csv_output, 'w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=data[0].keys())
        writer.writeheader()
        writer.writerows(data)

    return csv_output

def generate_excel_function(data, report_name):
    # Setup the directory to save the file
    directory = os.path.join(os.getcwd(), 'files')
    os.makedirs(directory, exist_ok=True)  # Ensure the directory exists

    # Create a valid file name by replacing spaces with underscores
    excel_filename = f"{report_name.replace(' ', '_')}.xlsx"
    excel_path = os.path.join(directory, excel_filename)

    # Convert data to a DataFrame and save as Excel
    df = pd.DataFrame(data)
    df.to_excel(excel_path, index=False)  # Save the DataFrame to an Excel file

    return excel_path  # Return the full path to the Excel file




def generate_text_report(data, report_name):
    text_report = f"Report Name: {report_name}\n\n"

    for record in data:
        record_lines = [f"{key}: {value}" for key, value in record.items()]
        text_report += '\n'.join(record_lines) + "\n\n"
    
    return text_report.rstrip()  # Remove the trailing newline character for cleanliness

def generate_pdf_with_table(data, report_name):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    data_for_table = [list(data[0].keys())] + [list(d.values()) for d in data]

    table = Table(data_for_table)
    style = TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.gray),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ])
    table.setStyle(style)
    doc.build([table])
    buffer.seek(0)
    return buffer

