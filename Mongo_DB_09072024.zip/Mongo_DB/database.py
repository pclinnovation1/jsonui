# database.py
import sqlite3
import logging

logger = logging.getLogger(__name__)

def get_database_connection():
    try:
        conn = sqlite3.connect('hrms.db')
        conn = sqlite3.connect('UK_PCL_TEST.db')
        return conn
    except Exception as e:
        logger.exception("Database connection failed")
        return None

def create_employee_details_table():
    conn = get_database_connection()
    if conn is not None:
        try:
            cursor = conn.cursor()
            cursor.execute('''CREATE TABLE IF NOT EXISTS EmployeeDetails (
                                name TEXT NOT NULL,
                                email TEXT UNIQUE NOT NULL,
                                taxable_ytd REAL NOT NULL,
                                ni_ytd REAL NOT NULL,
                                p45_code TEXT,
                                salary REAL NOT NULL,
                                bank_account_number TEXT NOT NULL,
                                bank_sort_code TEXT NOT NULL,
                                department TEXT NOT NULL
                            )''')
            conn.commit()
            logger.info("EmployeeDetails table created or verified")
        except Exception as e:
            logger.exception("Failed to create or verify EmployeeDetails table")
        finally:
            conn.close()

def insert_employee_details(employee_details):
    conn = get_database_connection()
    if conn is not None:
        try:
            cursor = conn.cursor()
            cursor.execute('''INSERT INTO EmployeeDetails (name, email, taxable_ytd, ni_ytd, p45_code, salary, bank_account_number, bank_sort_code, department)
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''', 
                              (employee_details.get("name", ""), employee_details.get("email", ""), 
                               employee_details.get("taxable_ytd", 0), employee_details.get("ni_ytd", 0), 
                               employee_details.get("p45_code", ""), employee_details.get("salary", 0), 
                               employee_details.get("bank_account_number", ""), employee_details.get("bank_sort_code", ""), 
                               employee_details.get("department", "")))
            conn.commit()
            logger.info("Employee details inserted successfully")
        except Exception as e:
            logger.exception("Failed to insert employee details")
        finally:
            conn.close()

def create_contact_details_table():
    conn = get_database_connection()
    if conn is not None:
        try:
            cursor = conn.cursor()
            cursor.execute('''CREATE TABLE IF NOT EXISTS ContactDetails (
                                name TEXT NOT NULL,
                                email TEXT UNIQUE NOT NULL,
                                message TEXT NOT NULL
                            )''')
            conn.commit()
            logger.info("ContactDetails table created or verified")
        except Exception as e:
            logger.exception("Failed to create or verify ContactDetails table")
        finally:
            conn.close()

def insert_contact_details(name, email, message):
    conn = get_database_connection()
    if conn is not None:
        try:
            cursor = conn.cursor()
            cursor.execute('''INSERT INTO ContactDetails (name, email, message)
                              VALUES (?, ?, ?)''', (name, email, message))
            conn.commit()
            logger.info("Contact details inserted successfully")
        except sqlite3.IntegrityError:
            logger.error("Failed to insert contact details: Duplicate email")
        except Exception as e:
            logger.exception("Failed to insert contact details")
        finally:
            conn.close()

            
def fetch_gross_to_net_report():
    try:
        conn = get_database_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT Employee_Number, Employee_Name, Gross_pay, Net_pay, Cost_to_employer FROM UK_PAYROLL_CAL")
        report_data = cursor.fetchall()
        conn.close()
        return report_data
    except Exception as e:
        print(f"Error fetching report data: {e}")
        return None