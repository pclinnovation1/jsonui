import unittest
from Leave_acc_3 import calculate_leave_accrual, calculate_additional_leave_rate, calculate_seniority_level, get_unionized_leave_accrual
from datetime import datetime

class TestLeaveAccrual(unittest.TestCase):
    def test_full_time_regular_shift_no_seniority_no_union(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "full-time"
        leave_type = "annual_leave"
        gender = "male"
        fte = 1.0
        additional_leave_rate = calculate_additional_leave_rate("1-5", "day")
        
        expected_output = 7.5  # 2.5 days per month for 3 months

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_part_time_night_shift_6_10_years_no_union(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "part-time"
        leave_type = "annual_leave"
        gender = "male"
        fte = 0.5
        additional_leave_rate = calculate_additional_leave_rate("6-10", "night")

        expected_output = (2.5 * 0.5 + 0.75) * 3  # Prorated accrual for part-time, plus additional leave rates

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_contractor_rotating_shift_10_plus_years_union(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "contractor"
        leave_type = "annual_leave"
        gender = "male"
        fte = 1.0
        additional_leave_rate = calculate_additional_leave_rate("10+", "rotating")
        print("additional_leave_rate1:", additional_leave_rate)
        additional_leave_rate += get_unionized_leave_accrual(employee_type, fte)
        print("additional_leave_rate2:",additional_leave_rate)

        expected_output = (0.5 + 0.5 + 0.25) * 3  # Accrual rate for contractors plus additional leave rates

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_female_maternity_leave_full_time_regular_shift(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "full-time"
        leave_type = "maternity_leave"
        gender = "female"
        fte = 1.0
        additional_leave_rate = calculate_additional_leave_rate("1-5", "day")

        expected_output = 4.5  # 1.5 days per month for 3 months

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_male_paternity_leave_full_time_regular_shift_union(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "full-time"
        leave_type = "paternity_leave"
        gender = "male"
        fte = 1.0
        additional_leave_rate = calculate_additional_leave_rate("6-10", "day")
        additional_leave_rate += get_unionized_leave_accrual(employee_type, fte)

        expected_output = (1.0 + 0.25 + 3.0) * 3  # Accrual rate for full-time employees plus additional leave rates

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_part_time_study_leave_day_shift_less_than_1_year(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "part-time"
        leave_type = "study_leave"
        gender = "male"
        fte = 0.5
        additional_leave_rate = calculate_additional_leave_rate("1-5", "day")

        expected_output = (2.5 * 0.5 + 0.5) * 3  # Prorated accrual for part-time, plus additional leave rates

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_full_time_annual_leave_regular_shift_10_plus_years(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "full-time"
        leave_type = "annual_leave"
        gender = "male"
        fte = 1.0
        additional_leave_rate = calculate_additional_leave_rate("10+", "day")

        expected_output = (2.5 + 0.25) * 3  # Accrual rate for full-time employees plus additional leave rates

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_contractor_sick_leave_night_shift_less_than_1_year(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "contractor"
        leave_type = "sick_leave"
        gender = "male"
        fte = 1.0
        additional_leave_rate = calculate_additional_leave_rate("1-5", "night")

        expected_output = (0.5 + 0.75) * 3  # Accrual rate for contractors plus additional leave rates

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_full_time_adoption_leave_rotating_shift_6_10_years(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "full-time"
        leave_type = "adoption_leave"
        gender = "male"
        fte = 1.0
        additional_leave_rate = calculate_additional_leave_rate("6-10", "rotating")

        expected_output = (1.5 + 0.5) * 3  # Accrual rate for full-time employees plus additional leave rates

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

    def test_part_time_compassionate_leave_regular_shift_10_plus_years_union(self):
        start_date = "2024-04-01"
        end_date = "2024-06-01"
        employee_type = "part-time"
        leave_type = "compassionate_leave"
        gender = "male"
        fte = 0.5
        additional_leave_rate = calculate_additional_leave_rate("10+", "day")
        additional_leave_rate += get_unionized_leave_accrual(employee_type, fte)

        expected_output = (1.5 * 0.5 + 0.25 + 0.25) * 3  # Prorated accrual for part-time, plus additional leave rates

        result = calculate_leave_accrual(start_date, end_date, employee_type, leave_type, gender, fte, additional_leave_rate)
        self.assertEqual(result["total_accrued_leave"], expected_output)

if __name__ == "__main__":
    unittest.main()
