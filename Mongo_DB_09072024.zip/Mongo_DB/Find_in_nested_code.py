from pymongo import MongoClient, errors

try:
    # Connect to MongoDB
    client = MongoClient("mongodb://localhost:27017/")
    print("Connected to MongoDB successfully!")

    # Access the database (create it if it doesn't exist)
    db = client.company

    # Access the collection (create it if it doesn't exist)
    employee_collection = db.employees

    # Query to find details of the employee associated with "Project E"
    query = {"projects.name": "Project E"}
    query_1 = {"address.zip": "62701"}
    project_e_employee = employee_collection.find_one(query)
    address_zip_employee = employee_collection.find_one(query_1)

    # Check if the document exists and print the details
    if project_e_employee:
        print("Employee associated with 'Project E':")
        print(project_e_employee)
    else:
        print("No employee found with 'Project E'.")

    if address_zip_employee:
        print("Employee associated with 'Address Zip':")
        print(address_zip_employee)
    else:
        print("No employee found with 'Address Zip'.")        

except errors.ConnectionFailure as e:
    print(f"Could not connect to MongoDB: {e}")

except errors.PyMongoError as e:
    print(f"An error occurred with PyMongo: {e}")

except Exception as e:
    print(f"An unexpected error occurred: {e}")
