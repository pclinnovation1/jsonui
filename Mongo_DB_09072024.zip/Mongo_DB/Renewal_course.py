from flask import Flask, request, jsonify
from pymongo import MongoClient, errors
import pymongo
from datetime import datetime, timedelta
import logging

app = Flask(__name__)

# MongoDB connection setup
def get_mongo_connection():
    client = MongoClient("mongodb://localhost:27017/")  # Update this with your MongoDB connection string
    db = client["company2"]
    return db

# Configuration for leave accrual
leave_accrual_config = {
    "leave_types": {
        "annual_leave": {
            "accrual_rates": {
                "full-time": 2.0,
                "part-time": 1.0
            },
            "applicable_gender": "all"
        }
    }
}

# Reassignment cycle for mandatory learning
reassignment_cycle = {
    "GDPR": 1,  # January
    "Modern Slavery": 3,  # March
    "Health & Safety Essentials": 4,  # April
    "Cyber Security": 5,  # May
    "Safeguarding Children": 6,  # June
    "Fire Safety": 9,  # September
    "Diversity & Inclusion": 10,  # October
    "Safeguarding Adults": 11  # November
}

def assign_courses(employee):
    db = get_mongo_connection()
    courses_collection = db["Mandatory_Learning_Courses"]
    hire_date = datetime.strptime(employee["Hire_Date"], "%Y-%m-%d")
    due_date = hire_date + timedelta(days=45)

    courses = ["GDPR", "Modern Slavery", "Health & Safety Essentials", "Cyber Security",
               "Safeguarding Children", "Fire Safety", "Diversity & Inclusion", "Safeguarding Adults"]

    for course in courses:
        courses_collection.insert_one({
            "Person_Number": employee["Person_Number"],
            "Course_Name": course,
            "Assigned_Date": hire_date.strftime("%Y-%m-%d"),
            "Due_Date": due_date.strftime("%Y-%m-%d"),
            "Status": "Assigned"
        })

    return "Courses assigned successfully."


def get_last_day_of_month(year, month):
    if month == 12:
        return datetime(year, 12, 31)
    return datetime(year, month + 1, 1) - timedelta(days=1)

def reassign_courses(employee_name):
    db = get_mongo_connection()
    courses_collection = db["Mandatory_Learning_Courses"]
    employees_collection = db["EmployeeDetails_UK"]
    
    # Set specific date for "today" to the first day of the current month
    today = datetime(datetime.now().year, datetime.now().month, 1)
    # today = datetime(2025, 2, 15)

    # Find the employee by name
    name_parts = employee_name.split()
    if len(name_parts) < 2:
        return "Invalid Employee_Name. Please provide both first and last names."
    first_name = name_parts[0]
    last_name = name_parts[1]
    
    employee = employees_collection.find_one({"First_Name": first_name, "Last_Name": last_name})
    if not employee:
        return "Employee not found"

    person_number = employee["Person_Number"]
    reassigned_courses = []
    completed_this_year = []

    for course, month_index in reassignment_cycle.items():
        reassignment_date = today.replace(month=month_index, day=1)
        due_date = get_last_day_of_month(reassignment_date.year, reassignment_date.month)

        # Only process the reassignment if the specific date matches the course's reassignment month
        if today.month == month_index:
            # Check if the course was completed in the previous year
            print("Enter for Last Month")
            last_course = courses_collection.find_one({
                "Person_Number": person_number,
                "Course_Name": course
            }, sort=[("Due_Date", pymongo.DESCENDING)])

            print(last_course)

            # Check if the course was assigned in the current year
            assigned_this_year = courses_collection.find_one({
                "Person_Number": person_number,
                "Course_Name": course,
                "Assigned_Date": {"$gte": datetime(today.year, 1, 1)}
            })

            if last_course and not assigned_this_year:
                courses_collection.insert_one({
                    "Person_Number": person_number,
                    "Course_Name": course,
                    "Assigned_Date": reassignment_date.strftime("%Y-%m-%d"),
                    "Due_Date": due_date.strftime("%Y-%m-%d"),
                    "Status": "Assigned"
                })
                reassigned_courses.append(course)
            else:
                completed_this_year.append(course)

    if reassigned_courses:
        return f"The following courses have been reassigned to you: {', '.join(reassigned_courses)}"
    else:
        return "All mandatory courses were completed this year. They will be reassigned next year."


@app.route('/hireEmployee', methods=['POST'])
def hire_employee():
    data = request.json
    if not data:
        return jsonify({"error": "Invalid data"}), 400

    db = get_mongo_connection()
    employees_collection = db["EmployeeDetails_UK"]

    try:
        employee_id = employees_collection.insert_one(data).inserted_id
        employee = employees_collection.find_one({"_id": employee_id})
        assign_courses(employee)
        return jsonify({"message": "Employee hired and courses assigned successfully."}), 200
    except errors.PyMongoError as e:
        logging.error(f"Error inserting data: {e}")
        return jsonify({"error": f"Error inserting data: {e}"}), 500

@app.route('/reassignCourses', methods=['POST'])
def reassign_courses_endpoint():
    data = request.json
    if not data or "Employee_Name" not in data:
        return jsonify({"error": "Missing Employee_Name in request body"}), 400

    employee_name = data["Employee_Name"]
    
    try:
        message = reassign_courses(employee_name)
        return jsonify({"message": message}), 200
    except errors.PyMongoError as e:
        logging.error(f"Error during reassignment: {e}")
        return jsonify({"error": f"Error during reassignment: {e}"}), 500

@app.route('/viewCourses', methods=['POST'])
def view_courses():
    data = request.json
    if not data or "Employee_Name" not in data:
        return jsonify({"error": "Missing Employee_Name in request body"}), 400

    employee_name = data["Employee_Name"]

    db = get_mongo_connection()
    employees_collection = db["EmployeeDetails_UK"]
    courses_collection = db["Mandatory_Learning_Courses"]

    try:
        # Find the employee's person number using their name
        employee_record = employees_collection.find_one({"First_Name": employee_name.split()[0], "Last_Name": employee_name.split()[1]})
        if not employee_record:
            return jsonify({"error": "No employee found with the specified name"}), 404

        person_number = employee_record["Person_Number"]

        # Find courses for the employee using their person number
        records = courses_collection.find({"Person_Number": person_number})
        courses = []
        for record in records:
            courses.append({
                "Course_Name": record["Course_Name"],
                "Assigned_Date": record["Assigned_Date"],
                "Due_Date": record["Due_Date"],
                "Status": record["Status"]
            })

        if not courses:
            return jsonify({"error": "No courses found for the specified employee"}), 404

        return jsonify({"employee_name": employee_name, "courses": courses}), 200
    except errors.PyMongoError as e:
        logging.error(f"Error retrieving data: {e}")
        return jsonify({"error": f"Error retrieving data: {e}"}), 500

if __name__ == "__main__":
    app.run(debug=True)
