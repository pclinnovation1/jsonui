from pymongo import MongoClient, errors

def get_next_sequence_value(sequence_name):
    """Get the next sequence value for a given sequence name."""
    return db.counters.find_one_and_update(
        {"_id": sequence_name},
        {"$inc": {"sequence_value": 1}},
        return_document=True
    )["sequence_value"]

try:
    # Connect to MongoDB
    client = MongoClient("mongodb://localhost:27017/")
    print("Connected to MongoDB successfully!")

    # Access the database (create it if it doesn't exist)
    db = client.company

    # Create a counter collection if it doesn't exist
    if not db.counters.find_one({"_id": "application_id"}):
        # Initialize the counter with the highest Application_ID + 1 from the initial records
        initial_application_ids = [1, 2, 4, 7, 8, 9, 11, 12, 13, 14, 15, 16]
        max_application_id = max(initial_application_ids)
        db.counters.insert_one({"_id": "application_id", "sequence_value": max_application_id})

    # Access the collection (create it if it doesn't exist)
    leave_applications_collection = db.Leave_Applications

    # Sample leave application documents
    leave_applications = [
        {"Application_ID": 1, "Employee_ID": 123, "Leave_Type_ID": 3, "Start_Date": "2024-06-01", "End_Date": "2024-06-05", "Duration": 5, "Reason_for_Absence": "Vacation", "Status": "Pending", "Manager_ID": 456},
        {"Application_ID": 2, "Employee_ID": 124, "Leave_Type_ID": 1, "Start_Date": "2024-06-01", "End_Date": "2024-06-05", "Duration": 5, "Reason_for_Absence": "Maternity Leave", "Status": "Pending", "Manager_ID": 456, "Expected_Date_of_Childbirth_Adoption": "2024-08-01", "Planned_Start_Date": "2024-06-01", "Planned_End_Date": "2024-09-01", "Will_not_Return_to_Work": False},
        {"Application_ID": 4, "Employee_ID": 125, "Leave_Type_ID": 3, "Start_Date": "2024-06-01", "End_Date": "2024-06-05", "Duration": 5, "Reason_for_Absence": "Maternity Leave", "Status": "Pending", "Manager_ID": 456},
        {"Application_ID": 7, "Employee_ID": 12349, "Leave_Type_ID": 1, "Start_Date": "2024-06-01", "End_Date": "2024-06-05", "Duration": 5, "Reason_for_Absence": "Vacation", "Status": "Pending", "Manager_ID": 12346},
        {"Application_ID": 8, "Employee_ID": 12349, "Leave_Type_ID": 2, "Start_Date": "2024-06-01", "End_Date": "2024-06-05", "Duration": 5, "Reason_for_Absence": "Vacation", "Status": "Pending", "Manager_ID": 12346},
        {"Application_ID": 9, "Employee_ID": 12348, "Leave_Type_ID": 7, "Start_Date": "2024-06-01", "End_Date": "2024-06-05", "Duration": 5, "Reason_for_Absence": "Vacation", "Status": "Pending", "Manager_ID": 12346, "Expected_Date_of_Childbirth_Adoption": "2024-08-01", "Planned_Start_Date": "2024-06-01", "Planned_End_Date": "2024-09-01", "Will_not_Return_to_Work": False},
        {"Application_ID": 11, "Employee_ID": 12348, "Leave_Type_ID": 1, "Start_Date": "2024-12-01", "End_Date": "2024-12-10", "Duration": 10, "Reason_for_Absence": "Vacation", "Status": "Pending", "Manager_ID": 12346},
        {"Application_ID": 12, "Employee_ID": 12349, "Leave_Type_ID": 2, "Start_Date": "2024-05-01", "End_Date": "2024-05-05", "Duration": 5, "Reason_for_Absence": "Sickness", "Status": "Pending", "Manager_ID": 12346},
        {"Application_ID": 13, "Employee_ID": 12346, "Leave_Type_ID": 2, "Start_Date": "2024-05-01", "End_Date": "2024-05-05", "Duration": 5, "Reason_for_Absence": "Sickness", "Status": "Pending", "Manager_ID": 12346},
        {"Application_ID": 14, "Employee_ID": 12346, "Leave_Type_ID": 2, "Start_Date": "2024-05-01", "End_Date": "2024-05-05", "Duration": 5, "Reason_for_Absence": "Sickness", "Status": "Pending", "Manager_ID": 12346},
        {"Application_ID": 15, "Employee_ID": 12346, "Leave_Type_ID": 1, "Start_Date": "2024-05-27", "End_Date": "2024-05-30", "Duration": 5, "Reason_for_Absence": "Sickness", "Status": "Pending", "Manager_ID": 12346},
        {"Application_ID": 16, "Employee_ID": 12346, "Leave_Type_ID": 1, "Start_Date": "2024-05-22", "End_Date": "2024-05-27", "Duration": 5, "Reason_for_Absence": "Sickness", "Status": "Pending", "Manager_ID": 12346}
    ]

    # Insert the initial documents into the collection
    result = leave_applications_collection.insert_many(leave_applications)
    print(f"Inserted document IDs: {result.inserted_ids}")

    # Function to insert a new leave application with auto-incremented Application_ID
    def insert_new_leave_application(leave_application):
        leave_application["Application_ID"] = get_next_sequence_value("application_id")
        result = leave_applications_collection.insert_one(leave_application)
        print(f"Inserted document ID: {result.inserted_id}")

    # Sample new leave application document to be inserted
    new_leave_application = {
        "Employee_ID": 12351,
        "Leave_Type_ID": 3,
        "Start_Date": "2024-07-01",
        "End_Date": "2024-07-10",
        "Duration": 10,
        "Reason_for_Absence": "Personal",
        "Status": "Pending",
        "Manager_ID": 12346
    }

    # Insert the new leave application
    insert_new_leave_application(new_leave_application)

    # Fetch and display the documents to verify insertion
    for leave_application in leave_applications_collection.find():
        print(leave_application)

except errors.ConnectionFailure as e:
    print(f"Could not connect to MongoDB: {e}")

except errors.PyMongoError as e:
    print(f"An error occurred with PyMongo: {e}")

except Exception as e:
    print(f"An unexpected error occurred: {e}")
