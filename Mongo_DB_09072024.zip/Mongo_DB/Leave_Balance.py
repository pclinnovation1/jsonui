from pymongo import MongoClient, errors

def get_next_sequence_value(sequence_name):
    """Get the next sequence value for a given sequence name."""
    return db.counters.find_one_and_update(
        {"_id": sequence_name},
        {"$inc": {"sequence_value": 1}},
        return_document=True
    )["sequence_value"]

try:
    # Connect to MongoDB
    client = MongoClient("mongodb://localhost:27017/")
    print("Connected to MongoDB successfully!")

    # Access the database (create it if it doesn't exist)
    db = client.company

    # Create a counter collection if it doesn't exist
    if not db.counters.find_one({"_id": "balance_id"}):
        # Initialize the counter with the highest Balance_ID + 1 from the initial records
        initial_balance_ids = [11, 12, 13, 14, 15, 16, 17]
        max_balance_id = max(initial_balance_ids)
        db.counters.insert_one({"_id": "balance_id", "sequence_value": max_balance_id})

    # Access the collection (create it if it doesn't exist)
    leave_balances_collection = db.Leave_Balances

    # Sample leave balance documents
    leave_balances = [
        {"Balance_ID": 11, "Employee_ID": 12345, "Leave_Type_ID": 1, "Current_Balance": 10},
        {"Balance_ID": 12, "Employee_ID": 12346, "Leave_Type_ID": 2, "Current_Balance": 5},
        {"Balance_ID": 13, "Employee_ID": 12347, "Leave_Type_ID": 3, "Current_Balance": 15},
        {"Balance_ID": 14, "Employee_ID": 12348, "Leave_Type_ID": 4, "Current_Balance": 7},
        {"Balance_ID": 15, "Employee_ID": 12349, "Leave_Type_ID": 5, "Current_Balance": 10},
        {"Balance_ID": 16, "Employee_ID": 12345, "Leave_Type_ID": 2, "Current_Balance": 10},
        {"Balance_ID": 17, "Employee_ID": 12345, "Leave_Type_ID": 5, "Current_Balance": 15}
    ]

    # Insert the initial documents into the collection
    result = leave_balances_collection.insert_many(leave_balances)
    print(f"Inserted document IDs: {result.inserted_ids}")

    # Function to insert a new leave balance with auto-incremented Balance_ID
    def insert_new_leave_balance(leave_balance):
        leave_balance["Balance_ID"] = get_next_sequence_value("balance_id")
        result = leave_balances_collection.insert_one(leave_balance)
        print(f"Inserted document ID: {result.inserted_id}")

    # Sample new leave balance document to be inserted
    new_leave_balance = {
        "Employee_ID": 12351,
        "Leave_Type_ID": 3,
        "Current_Balance": 20
    }

    # Insert the new leave balance
    insert_new_leave_balance(new_leave_balance)

    # Fetch and display the documents to verify insertion
    for leave_balance in leave_balances_collection.find():
        print(leave_balance)

except errors.ConnectionFailure as e:
    print(f"Could not connect to MongoDB: {e}")

except errors.PyMongoError as e:
    print(f"An error occurred with PyMongo: {e}")

except Exception as e:
    print(f"An unexpected error occurred: {e}")
